// Minimal pass-through Service Worker for mobile home-screen installability (PWA).
// Never caches /api/* routes or live IPTV streams (HLS / MPEG-TS).
self.addEventListener('install', () => {
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil(self.clients.claim());
});

self.addEventListener('fetch', (event) => {
  const req = event.request;
  if (req.method !== 'GET') return;

  const url = new URL(req.url);
  // Always bypass API endpoints, stream proxies, and cross-origin media streams
  if (url.origin !== self.location.origin || url.pathname.startsWith('/api/')) {
    return;
  }

  // Pass through directly to network with graceful fallback so live app state stays fresh
  event.respondWith(fetch(req));
});
