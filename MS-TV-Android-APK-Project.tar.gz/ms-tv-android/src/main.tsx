import { createRoot } from 'react-dom/client';
import App from './App.tsx';
import { initApkRuntimeConfig } from './api.ts';
import './index.css';

initApkRuntimeConfig().finally(() => {
  createRoot(document.getElementById('root')!).render(<App />);
});
