/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useState, useMemo, useCallback, useRef } from 'react';
import {
  Home,
  Tv,
  Trophy,
  Film,
  Clapperboard,
  Baby,
  Music2,
  BookOpen,
  Star,
  Clock,
  Settings,
  Search,
  Bell,
  User,
  Crown,
  ChevronRight,
  ChevronLeft,
  Layers,
  Plus,
  Edit3,
  ListVideo,
  LogOut,
  X,
  FolderPlus,
  LayoutGrid,
  ArrowUp,
  ArrowDown,
  Calendar,
  Shield,
  Users,
  Smartphone,
  Download,
  Wrench,
  Power,
} from 'lucide-react';
import {
  api,
  clearViewerSession,
  getAdminToken,
  getSessionLabel,
  getViewerToken,
  setAdminToken,
  setViewerSession,
} from './api';
import type {
  CategorySummary,
  Channel,
  CustomPlaylist,
  HeroSlide,
  NavSection,
  PublicStatusResponse,
  SecurityPolicyConfig,
} from './types';
import { BrandMark } from './components/BrandMark';
import { ChannelLogo } from './components/ChannelLogo';
import { CategoryLogo } from './components/CategoryLogo';
import { FastPlayer } from './components/FastPlayer';
import { LoginScreen } from './components/LoginScreen';
import { HeroBanner } from './components/HeroBanner';
import { CategoryCards } from './components/CategoryCards';
import { ChannelEditModal } from './components/ChannelEditModal';
import { CustomListModal } from './components/CustomListModal';
import { AdminCodeModal } from './components/AdminCodeModal';
import { AdminPanelModal, type AdminTab } from './components/AdminPanelModal';
import {
  SecurityShieldOverlay,
  useClientSecurityMonitor,
  type SecurityBlockState,
} from './components/SecurityShieldOverlay';
import {
  MaintenanceOverlay,
  DEFAULT_MAINTENANCE_TEXT,
} from './components/MaintenanceOverlay';
import {
  auth,
  loadEncryptedVaultFromFirestore,
  saveEncryptedVaultToFirestore,
  subscribeToFirebaseAdmin,
} from './firebase';
import { useMobileInstall } from './hooks/useMobileInstall';

const ARABIC_DAYS = ['الأحد', 'الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'];
const ARABIC_MONTHS = [
  'يناير',
  'فبراير',
  'مارس',
  'أبريل',
  'مايو',
  'يونيو',
  'يوليو',
  'أغسطس',
  'سبتمبر',
  'أكتوبر',
  'نوفمبر',
  'ديسمبر',
];

const POSTER_THEMES = [
  'from-[#450A0A] via-[#7F1D1D] to-[#090D16]',
  'from-[#422006] via-[#78350F] to-[#090D16]',
  'from-[#2E1065] via-[#4C1D95] to-[#090D16]',
  'from-[#064E3B] via-[#065F46] to-[#090D16]',
  'from-[#172554] via-[#1E40AF] to-[#090D16]',
];

function formatExpiryDateLabel(iso: string | null): string | null {
  if (!iso) return null;
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return null;
  const yyyy = d.getFullYear();
  const mm = String(d.getMonth() + 1).padStart(2, '0');
  const dd = String(d.getDate()).padStart(2, '0');
  return `${yyyy}/${mm}/${dd}`;
}

export default function App() {
  const [booting, setBooting] = useState(true);
  const [publicStatus, setPublicStatus] = useState<PublicStatusResponse | null>(null);
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(Boolean(getViewerToken()));
  const [isAdminUnlocked, setIsAdminUnlocked] = useState<boolean>(Boolean(getAdminToken()));
  const [sessionLabel, setSessionLabel] = useState<string>(getSessionLabel());
  const [sessionError, setSessionError] = useState<string | null>(null);

  // Catalog & Subscription Security state
  const [channels, setChannels] = useState<Channel[]>([]);
  const [streamSessionToken, setStreamSessionToken] = useState<string | null>(null);
  const [categories, setCategories] = useState<CategorySummary[]>([]);
  const [heroSlides, setHeroSlides] = useState<HeroSlide[]>([]);
  const [customLists, setCustomLists] = useState<CustomPlaylist[]>([]);
  const [favorites, setFavorites] = useState<string[]>([]);
  const [history, setHistory] = useState<string[]>([]);
  const [durationDays, setDurationDays] = useState<number>(365);
  const [expiresAt, setExpiresAt] = useState<string | null>(null);
  const [maxDevices, setMaxDevices] = useState<number>(1);
  const [connectedDevicesCount, setConnectedDevicesCount] = useState<number>(1);
  const [securityPolicy, setSecurityPolicy] = useState<SecurityPolicyConfig>({
    blockSniffers: true,
    blockVpn: true,
    blockDevTools: true,
    strictStreamBinding: true,
  });
  const [securityBlock, setSecurityBlock] = useState<SecurityBlockState | null>(null);
  const [maintenanceState, setMaintenanceState] = useState<{
    active: boolean;
    message: string;
  }>({
    active: false,
    message: DEFAULT_MAINTENANCE_TEXT,
  });
  const [togglingMaintenanceBanner, setTogglingMaintenanceBanner] = useState(false);

  // Navigation & Mobile Responsive UI state
  const [activeNav, setActiveNav] = useState<NavSection>('home');
  const [selectedM3uGroup, setSelectedM3uGroup] = useState<string | null>(null);
  const [m3uGroupSearch, setM3uGroupSearch] = useState('');
  const [inCategorySearch, setInCategorySearch] = useState('');
  const [visibleChannelCount, setVisibleChannelCount] = useState(300);
  const [selectedCustomListId, setSelectedCustomListId] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [mobileSearchOpen, setMobileSearchOpen] = useState(false);
  const [mobileMoreSheetOpen, setMobileMoreSheetOpen] = useState(false);

  // Direct Playback State
  const [playingChannel, setPlayingChannel] = useState<Channel | null>(null);
  const [isPlayerOpen, setIsPlayerOpen] = useState(false);

  // Modals & Popovers
  const [showAdminGate, setShowAdminGate] = useState(false);
  const [showAdminPanel, setShowAdminPanel] = useState(false);
  const [adminInitialTab, setAdminInitialTab] = useState<AdminTab>('m3u');
  const [editingChannel, setEditingChannel] = useState<Channel | null>(null);
  const [customListModalTarget, setCustomListModalTarget] = useState<CustomPlaylist | 'NEW' | null>(
    null
  );
  const [showBellMenu, setShowBellMenu] = useState(false);
  const [showProfileMenu, setShowProfileMenu] = useState(false);
  const [showIosInstallGuide, setShowIosInstallGuide] = useState(false);
  const [toast, setToast] = useState<string | null>(null);
  const [reorderingCategory, setReorderingCategory] = useState<string | null>(null);
  const { canInstall, promptInstall } = useMobileInstall();

  // Independent scroll container refs (keeps outer shell 100% locked while lists scroll)
  const homeScrollRef = useRef<HTMLDivElement | null>(null);
  const categoriesScrollRef = useRef<HTMLDivElement | null>(null);
  const channelsScrollRef = useRef<HTMLDivElement | null>(null);

  // Silent secret gesture for owner (5 quick taps on brand logo or Ctrl+Shift+A — zero visible UI for users!)
  const secretTapCountRef = useRef(0);
  const secretTapTimerRef = useRef<number | null>(null);
  const autoCloudRestoreCheckedRef = useRef(false);

  // Live Clock
  const [nowDate, setNowDate] = useState<Date>(() => new Date());
  useEffect(() => {
    const timer = setInterval(() => setNowDate(new Date()), 15000);
    return () => clearInterval(timer);
  }, []);

  const openAdminModalOnTab = useCallback((tab: AdminTab = 'm3u') => {
    setAdminInitialTab(tab);
    setShowAdminPanel(true);
  }, []);

  const handleMobileInstallClick = useCallback(async () => {
    setShowProfileMenu(false);
    setMobileMoreSheetOpen(false);
    const outcome = await promptInstall();
    if (outcome === 'accepted') {
      setToast('تم تثبيت تطبيق MS TV على هاتفك بنجاح.');
    } else if (outcome === 'ios-guide') {
      setShowIosInstallGuide(true);
    }
  }, [promptInstall]);

  const handleSecurityBlock = useCallback(
    (block: SecurityBlockState) => {
      if (isAdminUnlocked && getAdminToken()) return;
      setIsPlayerOpen(false);
      setSecurityBlock(block);
    },
    [isAdminUnlocked]
  );

  const handleMaintenanceActivated = useCallback(
    (message?: string) => {
      setMaintenanceState({
        active: true,
        message: message?.trim() || DEFAULT_MAINTENANCE_TEXT,
      });
      if (!isAdminUnlocked || !getAdminToken()) {
        setIsPlayerOpen(false);
        setPlayingChannel(null);
      }
    },
    [isAdminUnlocked]
  );

  useClientSecurityMonitor({
    policy: securityPolicy,
    isAdminUnlocked,
    onBlock: handleSecurityBlock,
  });

  // Silent owner shortcut (Ctrl+Shift+A)
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.shiftKey && (e.key === 'A' || e.key === 'a')) {
        e.preventDefault();
        if (isAdminUnlocked && getAdminToken()) {
          openAdminModalOnTab('m3u');
        } else {
          setShowAdminGate(true);
        }
      }
    };
    window.addEventListener('keydown', onKey, true);
    return () => window.removeEventListener('keydown', onKey, true);
  }, [isAdminUnlocked, openAdminModalOnTab]);

  const showToast = useCallback((msg: string) => {
    setToast(msg);
    setTimeout(() => {
      setToast((prev) => (prev === msg ? null : prev));
    }, 3200);
  }, []);

  const syncCloudVaultQuietly = useCallback(() => {
    if (!isAdminUnlocked || !getAdminToken()) return;
    if (!auth.currentUser || !auth.currentUser.emailVerified) return;
    api
      .exportCloudSnapshot()
      .then((snap) => saveEncryptedVaultToFirestore(snap))
      .catch(() => {});
  }, [isAdminUnlocked]);

  const loadCatalog = useCallback(
    async (options?: { boot?: boolean }) => {
      try {
        const data = await api.getCatalog(options);
        setChannels(data.channels);
        setStreamSessionToken(data.streamSessionToken || null);
      setCategories(data.categories);
      setHeroSlides(data.heroSlides || []);
      setCustomLists(data.customLists);
      setFavorites(data.favorites);
      setHistory(data.history);
      setDurationDays(typeof data.durationDays === 'number' ? data.durationDays : 365);
      setExpiresAt(data.expiresAt ?? null);
      if (typeof data.maxDevices === 'number') {
        setMaxDevices(data.maxDevices);
      }
      if (typeof data.connectedDevicesCount === 'number') {
        setConnectedDevicesCount(data.connectedDevicesCount);
      }
        if (data.securityPolicy) {
          setSecurityPolicy(data.securityPolicy);
        }
        if (typeof data.maintenanceMode === 'boolean') {
          setMaintenanceState({
            active: data.maintenanceMode,
            message: data.maintenanceMessage || DEFAULT_MAINTENANCE_TEXT,
          });
        }

        setSelectedM3uGroup((prev) => {
          if (!prev || prev === '__ALL__') return prev;
          return data.categories.some((c) => c.name === prev) ? prev : null;
        });

        setPlayingChannel((prev) => {
          if (!prev) return null;
          return data.channels.find((c) => c.id === prev.id) || null;
        });
      } catch (err: any) {
        if (err?.code === 'MAINTENANCE_MODE') {
          handleMaintenanceActivated(err.message);
          throw err;
        }
        if (err?.code === 'VPN_BLOCKED' || err?.code === 'SNIFFER_BLOCKED') {
          handleSecurityBlock({ code: err.code, message: err.message });
          throw err;
        }
        if (err?.status === 401 || err?.code === 'DEVICE_LIMIT_REACHED') {
          clearViewerSession();
          setStreamSessionToken(null);
          setIsAuthenticated(false);
          setIsAdminUnlocked(false);
          setPlayingChannel(null);
          setIsPlayerOpen(false);
          setSessionError(err?.message || 'انتهت صلاحية الاشتراك. يرجى التواصل مع الإدارة للتجديد.');
        }
        throw err;
      }
    },
    [handleSecurityBlock, handleMaintenanceActivated]
  );

  const handleCatalogChanged = useCallback(async () => {
    const pub = await api.getPublicStatus().catch(() => null);
    if (pub) {
      setPublicStatus(pub);
      if (pub.securityPolicy) setSecurityPolicy(pub.securityPolicy);
      setMaintenanceState({
        active: Boolean(pub.maintenanceMode),
        message: pub.maintenanceMessage || DEFAULT_MAINTENANCE_TEXT,
      });
    }
    await loadCatalog().catch(() => {});
    syncCloudVaultQuietly();
  }, [loadCatalog, syncCloudVaultQuietly]);

  useEffect(() => {
    let mounted = true;
    (async () => {
      try {
        const hasToken = Boolean(getViewerToken());
        const pub = await api.getPublicStatus();

        if (mounted) {
          setPublicStatus(pub);
          if (pub.securityPolicy) setSecurityPolicy(pub.securityPolicy);
          setMaintenanceState({
            active: Boolean(pub.maintenanceMode),
            message: pub.maintenanceMessage || DEFAULT_MAINTENANCE_TEXT,
          });
        }

        if (hasToken) {
          if (!pub.maintenanceMode || Boolean(getAdminToken())) {
            await loadCatalog({ boot: true });
          }
          if (mounted) {
            setIsAuthenticated(true);
          }
        }
      } catch (err: any) {
        if (mounted && err?.code === 'MAINTENANCE_MODE') {
          handleMaintenanceActivated(err.message);
        } else if (mounted && (err?.code === 'VPN_BLOCKED' || err?.code === 'SNIFFER_BLOCKED')) {
          handleSecurityBlock({ code: err.code, message: err.message });
        } else if (err?.status === 401 || err?.code === 'DEVICE_LIMIT_REACHED') {
          clearViewerSession();
          if (mounted) {
            setIsAuthenticated(false);
            setIsAdminUnlocked(false);
            if (err?.message) {
              setSessionError(err.message);
            }
          }
        }
      } finally {
        if (mounted) setBooting(false);
      }
    })();
    return () => {
      mounted = false;
    };
  }, [loadCatalog, handleSecurityBlock, handleMaintenanceActivated]);

  // Lightweight live maintenance status check so active non-admin viewers immediately see the maintenance screen when enabled
  useEffect(() => {
    if (booting || isAdminUnlocked || maintenanceState.active) return;
    const timer = window.setInterval(async () => {
      try {
        const pub = await api.getPublicStatus();
        setPublicStatus(pub);
        if (pub.maintenanceMode) {
          handleMaintenanceActivated(pub.maintenanceMessage);
        }
      } catch {
        // ignore transient network errors
      }
    }, 35000);
    return () => window.clearInterval(timer);
  }, [booting, isAdminUnlocked, maintenanceState.active, handleMaintenanceActivated]);

  // Self-healing catalog loader: if boot encountered a transient network drop while channels exist on server,
  // automatically reload in the background so the user never has to manually refresh the page!
  const catalogRetryCountRef = useRef(0);
  useEffect(() => {
    if (
      booting ||
      !isAuthenticated ||
      channels.length > 0 ||
      sessionError ||
      securityBlock ||
      (maintenanceState.active && !isAdminUnlocked)
    ) {
      if (channels.length > 0) {
        catalogRetryCountRef.current = 0;
      }
      return;
    }
    if (catalogRetryCountRef.current >= 4) return;
    const timer = window.setTimeout(() => {
      catalogRetryCountRef.current += 1;
      loadCatalog({ boot: true }).catch(() => {});
    }, 1000 * (catalogRetryCountRef.current + 1));
    return () => window.clearTimeout(timer);
  }, [
    booting,
    isAuthenticated,
    channels.length,
    sessionError,
    securityBlock,
    maintenanceState.active,
    isAdminUnlocked,
    loadCatalog,
  ]);

  // Automatic Cloud Vault recovery if server started fresh and Admin has Google Cloud Vault active
  useEffect(() => {
    if (!isAuthenticated || !isAdminUnlocked || !publicStatus) return;
    if (publicStatus.hasRealSources || autoCloudRestoreCheckedRef.current) return;

    const unsub = subscribeToFirebaseAdmin((user) => {
      if (!user || !user.emailVerified || autoCloudRestoreCheckedRef.current) return;
      autoCloudRestoreCheckedRef.current = true;
      loadEncryptedVaultFromFirestore()
        .then(async (vault) => {
          if (vault && vault.chunks.length > 0 && vault.totalSources > 0) {
            const res = await api.importCloudSnapshot(vault.chunks);
            await loadCatalog();
            const pub = await api.getPublicStatus().catch(() => null);
            if (pub) setPublicStatus(pub);
            showToast(`تم استرجاع ${res.restoredChannels} قناة تلقائياً من الحفظ السحابي.`);
          }
        })
        .catch(() => {});
    });

    return () => unsub();
  }, [isAuthenticated, isAdminUnlocked, publicStatus, loadCatalog, showToast]);

  const handleLoginSuccess = async (res: {
    token: string;
    adminToken?: string;
    label: string;
    durationDays: number;
    expiresAt?: string | null;
    maxDevices?: number;
    connectedDevicesCount?: number;
    isAdminUnlocked: boolean;
  }) => {
    setSessionError(null);
    setViewerSession(res.token, res.label);
    setSessionLabel(res.label);
    setDurationDays(res.durationDays);
    if (res.expiresAt !== undefined) {
      setExpiresAt(res.expiresAt);
    }
    if (typeof res.maxDevices === 'number') {
      setMaxDevices(res.maxDevices);
    }
    if (typeof res.connectedDevicesCount === 'number') {
      setConnectedDevicesCount(res.connectedDevicesCount);
    }
    if (res.adminToken) {
      setAdminToken(res.adminToken);
      setIsAdminUnlocked(true);
      setSecurityBlock(null);
    } else {
      setAdminToken(null);
      setIsAdminUnlocked(false);
    }
    setIsAuthenticated(true);
    await loadCatalog();
    if (res.isAdminUnlocked) {
      openAdminModalOnTab('m3u');
    }
  };

  const handleLogout = async () => {
    clearViewerSession();
    setStreamSessionToken(null);
    setIsAuthenticated(false);
    setIsAdminUnlocked(false);
    setPlayingChannel(null);
    setIsPlayerOpen(false);
    setShowProfileMenu(false);
    setMobileMoreSheetOpen(false);
    setSessionError(null);
    const pub = await api.getPublicStatus().catch(() => null);
    if (pub) {
      setPublicStatus(pub);
      if (pub.securityPolicy) setSecurityPolicy(pub.securityPolicy);
      setMaintenanceState({
        active: Boolean(pub.maintenanceMode),
        message: pub.maintenanceMessage || DEFAULT_MAINTENANCE_TEXT,
      });
    }
  };

  const resetActiveScrollTop = () => {
    requestAnimationFrame(() => {
      if (homeScrollRef.current) homeScrollRef.current.scrollTop = 0;
      if (channelsScrollRef.current) channelsScrollRef.current.scrollTop = 0;
    });
  };

  const handleBrandClick = () => {
    selectSidebarNav('home');
    secretTapCountRef.current += 1;
    if (secretTapTimerRef.current) window.clearTimeout(secretTapTimerRef.current);
    if (secretTapCountRef.current >= 5) {
      secretTapCountRef.current = 0;
      if (isAdminUnlocked && getAdminToken()) {
        openAdminModalOnTab('m3u');
      } else {
        setShowAdminGate(true);
      }
      return;
    }
    secretTapTimerRef.current = window.setTimeout(() => {
      secretTapCountRef.current = 0;
    }, 1400);
  };

  const handlePlayChannel = useCallback((ch: Channel) => {
    setPlayingChannel(ch);
    setIsPlayerOpen(true);
    api.recordChannelView(ch.id).catch(() => {});
    setHistory((prev) => [ch.id, ...prev.filter((id) => id !== ch.id)].slice(0, 40));
  }, []);

  const handleToggleFavorite = useCallback(
    async (channelId: string) => {
      try {
        const res = await api.toggleFavorite(channelId);
        setFavorites(res.favorites);
      } catch {
        showToast('تعذر تحديث قائمة المفضلة.');
      }
    },
    [showToast]
  );

  const handleAdminUnlock = async (code: string) => {
    if (!isAuthenticated) {
      const loginRes = await api.loginWithCode(code);
      if (!loginRes.isAdminUnlocked) {
        throw new Error('كود المدير السري غير صحيح.');
      }
      setShowAdminGate(false);
      setSecurityBlock(null);
      await handleLoginSuccess(loginRes);
      openAdminModalOnTab('protection');
      return;
    }

    const res = await api.verifyAdminCode(code);
    setAdminToken(res.adminToken);
    setIsAdminUnlocked(true);
    setSecurityBlock(null);
    setShowAdminGate(false);
    await loadCatalog().catch(() => {});
    openAdminModalOnTab(maintenanceState.active ? 'protection' : 'm3u');
  };

  const handleQuickDisableMaintenance = async () => {
    setTogglingMaintenanceBanner(true);
    try {
      const res = await api.updateMaintenance({ maintenanceMode: false });
      setMaintenanceState({
        active: res.maintenanceMode,
        message: res.maintenanceMessage || DEFAULT_MAINTENANCE_TEXT,
      });
      await handleCatalogChanged();
      showToast('تم إيقاف وضع الصيانة وإعادة تشغيل التطبيق لجميع المستخدمين.');
    } catch {
      showToast('تعذر إيقاف وضع الصيانة حالياً.');
    } finally {
      setTogglingMaintenanceBanner(false);
    }
  };

  const handleSaveChannelEdit = async (
    channelId: string,
    updates: { name: string; group: string; logo: string; featured: boolean }
  ) => {
    await api.updateChannel(channelId, updates);
    await handleCatalogChanged();
    showToast('تم حفظ تعديل القناة بنجاح.');
  };

  const handleDeleteChannel = async (channelId: string) => {
    await api.deleteChannel(channelId);
    await handleCatalogChanged();
    showToast('تم إخفاء القناة بنجاح.');
  };

  const handleMoveCategoryInline = async (
    categoryName: string,
    direction: 'up' | 'down',
    e: React.MouseEvent
  ) => {
    e.stopPropagation();
    if (!isAdminUnlocked || reorderingCategory) return;

    const currentIdx = categories.findIndex((c) => c.name === categoryName);
    if (currentIdx === -1) return;
    const swapIdx = direction === 'up' ? currentIdx - 1 : currentIdx + 1;
    if (swapIdx < 0 || swapIdx >= categories.length) return;

    const previous = categories;
    const next = [...categories];
    const [item] = next.splice(currentIdx, 1);
    next.splice(swapIdx, 0, item);
    setCategories(next);
    setReorderingCategory(categoryName);

    try {
      const res = await api.moveCategory(categoryName, direction);
      setCategories(res.categories);
      syncCloudVaultQuietly();
    } catch {
      setCategories(previous);
      showToast('تعذر تحريك القسم حالياً.');
    } finally {
      setReorderingCategory(null);
    }
  };

  const handleSaveCustomList = async (payload: {
    id?: string;
    name: string;
    color: string;
    channelIds: string[];
    isGlobal: boolean;
  }) => {
    if (payload.id) {
      await api.updateCustomList(payload.id, {
        name: payload.name,
        color: payload.color,
        channelIds: payload.channelIds,
      });
      showToast('تم تحديث القائمة الخاصة بنجاح.');
    } else {
      const res = await api.createCustomList({
        name: payload.name,
        color: payload.color,
        channelIds: payload.channelIds,
        isGlobal: payload.isGlobal,
      });
      setSelectedCustomListId(res.list.id);
      setActiveNav('custom_list');
      showToast('تم إنشاء القائمة الخاصة للقنوات بنجاح.');
    }
    await handleCatalogChanged();
  };

  const handleDeleteCustomList = async (listId: string) => {
    await api.deleteCustomList(listId);
    if (selectedCustomListId === listId) {
      setSelectedCustomListId(null);
      setActiveNav('home');
    }
    await handleCatalogChanged();
    showToast('تم حذف القائمة الخاصة.');
  };

  const featuredChannels = useMemo(() => {
    const list = channels.filter((c) => c.featured);
    return list.length > 0 ? list : channels.slice(0, 10);
  }, [channels]);

  const recentlyAddedItems = useMemo(() => {
    const vodOrRecent = channels.filter(
      (c) => c.contentType === 'movie' || c.contentType === 'series'
    );
    if (vodOrRecent.length >= 6) return vodOrRecent.slice(0, 6);
    return [...vodOrRecent, ...channels.filter((c) => !vodOrRecent.includes(c))].slice(0, 6);
  }, [channels]);

  const filteredM3uCategories = useMemo(() => {
    const q = m3uGroupSearch.trim().toLowerCase();
    if (!q) return categories;
    return categories.filter((cat) => cat.name.toLowerCase().includes(q));
  }, [categories, m3uGroupSearch]);

  const sectionChannels = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    const base = channels;

    if (q) {
      return base.filter(
        (c) => c.name.toLowerCase().includes(q) || c.group.toLowerCase().includes(q)
      );
    }

    const filterInCat = (list: Channel[]) => {
      const iq = inCategorySearch.trim().toLowerCase();
      if (!iq) return list;
      return list.filter(
        (c) => c.name.toLowerCase().includes(iq) || c.group.toLowerCase().includes(iq)
      );
    };

    switch (activeNav) {
      case 'm3u_group':
      case 'live_tv': {
        if (!selectedM3uGroup) return [];
        const groupList =
          selectedM3uGroup === '__ALL__'
            ? base
            : base.filter((c) => c.group === selectedM3uGroup);
        return filterInCat(groupList);
      }
      case 'custom_list': {
        const list = customLists.find((l) => l.id === selectedCustomListId);
        if (!list) return [];
        const idSet = new Set(list.channelIds);
        return filterInCat(base.filter((c) => idSet.has(c.id)));
      }
      case 'sports':
        return filterInCat(
          base.filter((c) =>
            ['رياض', 'sport', 'bein', 'ssc', 'كورة', 'كرة'].some((kw) =>
              `${c.group} ${c.name}`.toLowerCase().includes(kw)
            )
          )
        );
      case 'movies':
        return filterInCat(
          base.filter(
            (c) =>
              c.contentType === 'movie' ||
              ['أفلام', 'افلام', 'movie', 'vod', 'cinema', 'سينما'].some((kw) =>
                c.group.toLowerCase().includes(kw)
              )
          )
        );
      case 'series':
        return filterInCat(
          base.filter(
            (c) =>
              c.contentType === 'series' ||
              ['مسلسل', 'series', 'دراما', 'drama'].some((kw) =>
                c.group.toLowerCase().includes(kw)
              )
          )
        );
      case 'kids':
        return filterInCat(
          base.filter((c) =>
            ['أطفال', 'اطفال', 'kid', 'cartoon', 'كرتون', 'spacetoon'].some((kw) =>
              `${c.group} ${c.name}`.toLowerCase().includes(kw)
            )
          )
        );
      case 'entertainment':
        return filterInCat(
          base.filter((c) =>
            ['ترفيه', 'منوعات', 'entertainment', 'mbc', 'osn', 'trt', 'music'].some((kw) =>
              `${c.group} ${c.name}`.toLowerCase().includes(kw)
            )
          )
        );
      case 'documentary':
        return filterInCat(
          base.filter((c) =>
            ['وثائق', 'doc', 'nat', 'geo', 'nasa', 'discovery', 'علوم'].some((kw) =>
              `${c.group} ${c.name}`.toLowerCase().includes(kw)
            )
          )
        );
      case 'favorites': {
        const favSet = new Set(favorites);
        return filterInCat(base.filter((c) => favSet.has(c.id)));
      }
      case 'history': {
        const map = new Map<string, Channel>(base.map((c) => [c.id, c]));
        return filterInCat(
          history.map((id) => map.get(id)).filter((c): c is Channel => Boolean(c))
        );
      }
      default:
        return filterInCat(base);
    }
  }, [
    channels,
    searchQuery,
    inCategorySearch,
    activeNav,
    selectedM3uGroup,
    selectedCustomListId,
    customLists,
    favorites,
    history,
  ]);

  const timeFormatted = `${String(nowDate.getHours()).padStart(2, '0')}:${String(
    nowDate.getMinutes()
  ).padStart(2, '0')}`;
  const dateFormatted = `${ARABIC_DAYS[nowDate.getDay()]} ${nowDate.getDate()} ${
    ARABIC_MONTHS[nowDate.getMonth()]
  } ${nowDate.getFullYear()}`;
  const formattedExpiry = formatExpiryDateLabel(expiresAt);

  if (booting) {
    return (
      <div className="h-dvh bg-[#060B16] flex flex-col items-center justify-center gap-4">
        <BrandMark size="lg" />
        <div className="w-8 h-8 border-2 border-blue-500 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (maintenanceState.active && !isAdminUnlocked) {
    return (
      <>
        <MaintenanceOverlay
          message={maintenanceState.message}
          telegramUrl={publicStatus?.telegramUrl}
          onCleared={async (pub) => {
            setPublicStatus(pub);
            if (pub.securityPolicy) setSecurityPolicy(pub.securityPolicy);
            setMaintenanceState({
              active: false,
              message: pub.maintenanceMessage || DEFAULT_MAINTENANCE_TEXT,
            });
            if (getViewerToken()) {
              await loadCatalog({ boot: true }).catch(() => {});
              setIsAuthenticated(true);
            }
          }}
          onOpenAdminGate={() => setShowAdminGate(true)}
        />
        {securityBlock && (
          <SecurityShieldOverlay
            block={securityBlock}
            onCleared={async (pol) => {
              setSecurityPolicy(pol);
              setSecurityBlock(null);
              const pub = await api.getPublicStatus().catch(() => null);
              if (pub) setPublicStatus(pub);
            }}
            onOpenAdminGate={() => setShowAdminGate(true)}
          />
        )}
        {showAdminGate && (
          <AdminCodeModal
            onClose={() => setShowAdminGate(false)}
            onUnlock={handleAdminUnlock}
          />
        )}
      </>
    );
  }

  if (!isAuthenticated) {
    return (
      <>
        <LoginScreen
          publicStatus={publicStatus}
          initialError={sessionError}
          loginAction={api.loginWithCode}
          onLoginSuccess={handleLoginSuccess}
          onSecurityBlock={handleSecurityBlock}
          onMaintenanceMode={handleMaintenanceActivated}
        />
        {securityBlock && !isAdminUnlocked && (
          <SecurityShieldOverlay
            block={securityBlock}
            onCleared={async (pol) => {
              setSecurityPolicy(pol);
              setSecurityBlock(null);
              const pub = await api.getPublicStatus().catch(() => null);
              if (pub) setPublicStatus(pub);
            }}
            onOpenAdminGate={() => setShowAdminGate(true)}
          />
        )}
        {showAdminGate && (
          <AdminCodeModal
            onClose={() => setShowAdminGate(false)}
            onUnlock={handleAdminUnlock}
          />
        )}
      </>
    );
  }

  const sidebarItems: Array<{ id: NavSection; label: string; icon: React.ReactNode }> = [
    { id: 'home', label: 'الرئيسية', icon: <Home className="w-5 h-5" /> },
    { id: 'live_tv', label: 'القنوات التلفزيونية', icon: <Tv className="w-5 h-5" /> },
    { id: 'sports', label: 'الرياضة', icon: <Trophy className="w-5 h-5" /> },
    { id: 'movies', label: 'الأفلام', icon: <Film className="w-5 h-5" /> },
    { id: 'series', label: 'المسلسلات', icon: <Clapperboard className="w-5 h-5" /> },
    { id: 'kids', label: 'أطفال', icon: <Baby className="w-5 h-5" /> },
    { id: 'entertainment', label: 'الترفيه', icon: <Music2 className="w-5 h-5" /> },
    { id: 'documentary', label: 'الوثائقية', icon: <BookOpen className="w-5 h-5" /> },
    { id: 'favorites', label: 'المفضلة', icon: <Star className="w-5 h-5" /> },
    { id: 'history', label: 'أخر المشاهدة', icon: <Clock className="w-5 h-5" /> },
    { id: 'settings', label: 'الإعدادات', icon: <Settings className="w-5 h-5" /> },
  ];

  const getSectionHeading = (): string => {
    if (searchQuery.trim()) return `نتائج البحث عن "${searchQuery}"`;
    if ((activeNav === 'm3u_group' || activeNav === 'live_tv') && selectedM3uGroup) {
      return selectedM3uGroup === '__ALL__' ? 'كل القنوات' : selectedM3uGroup;
    }
    if (activeNav === 'custom_list') {
      return customLists.find((l) => l.id === selectedCustomListId)?.name || 'قائمة خاصة';
    }
    return sidebarItems.find((i) => i.id === activeNav)?.label || 'القنوات';
  };

  const selectSidebarNav = (nav: NavSection) => {
    setActiveNav(nav);
    setSelectedM3uGroup(null);
    setM3uGroupSearch('');
    setInCategorySearch('');
    setVisibleChannelCount(300);
    setSearchQuery('');
    setMobileSearchOpen(false);
    setMobileMoreSheetOpen(false);
    resetActiveScrollTop();
    requestAnimationFrame(() => {
      if (categoriesScrollRef.current) categoriesScrollRef.current.scrollTop = 0;
    });
  };

  const selectExactM3uGroup = (groupName: string) => {
    setSelectedM3uGroup(groupName);
    setActiveNav('m3u_group');
    setInCategorySearch('');
    setVisibleChannelCount(300);
    setSearchQuery('');
    setMobileSearchOpen(false);
    setMobileMoreSheetOpen(false);
    requestAnimationFrame(() => {
      if (channelsScrollRef.current) channelsScrollRef.current.scrollTop = 0;
    });
  };

  const returnToM3uCategories = () => {
    setSelectedM3uGroup(null);
    setActiveNav('live_tv');
    setInCategorySearch('');
    setVisibleChannelCount(300);
  };

  const renderDesktopSidebar = () => (
    <div className="flex flex-col h-full min-h-0 justify-between gap-3">
      {/* Scrollable Navigation + Custom Lists inside Fixed Sidebar */}
      <div className="flex-1 min-h-0 overflow-y-auto overscroll-contain space-y-1 pr-1">
        {sidebarItems.map((item) => {
          const isActive =
            !searchQuery.trim() &&
            (activeNav === item.id || (item.id === 'live_tv' && activeNav === 'm3u_group'));
          return (
            <button
              key={item.id}
              type="button"
              onClick={() => selectSidebarNav(item.id)}
              className={`w-full px-4 py-2.5 rounded-xl flex items-center gap-3.5 text-sm font-bold transition-all cursor-pointer whitespace-nowrap ${
                isActive
                  ? 'bg-gradient-to-r from-[#0D63F3] to-[#1D74FF] text-white shadow-[0_4px_16px_rgba(13,99,243,0.38)]'
                  : 'text-slate-300 hover:text-white hover:bg-white/5'
              }`}
              dir="ltr"
            >
              <span className={isActive ? 'text-white' : 'text-slate-400'}>{item.icon}</span>
              <span className="truncate" dir="rtl">
                {item.label}
              </span>
            </button>
          );
        })}

        {/* Custom Channel Lists Section */}
        <div className="pt-3 mt-3 border-t border-[#1B2947]">
          <div className="flex items-center justify-between px-3 mb-2" dir="rtl">
            <span className="text-[11px] font-bold text-slate-400">القوائم الخاصة</span>
            <button
              type="button"
              onClick={() => setCustomListModalTarget('NEW')}
              className="text-[11px] font-bold text-blue-400 hover:text-blue-300 flex items-center gap-0.5 cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>إنشاء</span>
            </button>
          </div>

          <div className="space-y-1">
            {customLists.map((lst) => {
              const isSelected =
                activeNav === 'custom_list' && selectedCustomListId === lst.id && !searchQuery;
              return (
                <button
                  key={lst.id}
                  type="button"
                  onClick={() => {
                    setSelectedCustomListId(lst.id);
                    setActiveNav('custom_list');
                    setInCategorySearch('');
                    setSearchQuery('');
                    resetActiveScrollTop();
                  }}
                  className={`w-full px-3.5 py-2 rounded-xl flex items-center justify-between gap-2 text-xs font-semibold transition-colors cursor-pointer ${
                    isSelected
                      ? 'bg-blue-600/25 text-white border border-blue-500/40'
                      : 'text-slate-300 hover:bg-white/5'
                  }`}
                  dir="rtl"
                >
                  <div className="flex items-center gap-2 min-w-0">
                    <ListVideo className="w-4 h-4 shrink-0 text-blue-400" />
                    <span className="truncate">{lst.name}</span>
                  </div>
                  <span className="text-[11px] text-slate-400 font-mono tabular-nums shrink-0">
                    {lst.channelIds.length}
                  </span>
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Pinned Bottom Area: Admin Button (ONLY when Admin is Logged In) + Subscription Card */}
      <div className="shrink-0 space-y-2.5 pt-2 border-t border-[#142038]">
        {isAdminUnlocked && (
          <div className="space-y-1.5" dir="rtl">
            <button
              type="button"
              onClick={() => openAdminModalOnTab('m3u')}
              className="w-full bg-[#0B1222] hover:bg-[#111D38] border border-purple-500/40 rounded-2xl p-3 flex items-center gap-2.5 transition-all cursor-pointer"
            >
              <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-[#3B0764] to-[#1E1B4B] border border-purple-500/35 flex items-center justify-center shrink-0">
                <Crown className="w-4 h-4 text-purple-300" />
              </div>
              <div className="text-right min-w-0">
                <div className="text-xs font-extrabold text-white truncate">لوحة إدارة المصادر</div>
                <div className="text-[10px] text-purple-300 truncate">وضع المدير مفعل</div>
              </div>
            </button>

            <button
              type="button"
              onClick={() => openAdminModalOnTab('protection')}
              className="w-full px-3 py-2 rounded-xl bg-emerald-500/10 hover:bg-emerald-500/20 border border-emerald-500/30 text-emerald-300 text-xs font-bold flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
            >
              <Shield className="w-3.5 h-3.5" />
              <span>الحماية والـ VPN</span>
            </button>
          </div>
        )}

        <div className="rounded-2xl bg-[#091120] border border-[#1B2947] p-3.5 space-y-2" dir="rtl">
          <div className="flex items-center justify-between">
            <div className="min-w-0">
              <div className="text-[11px] text-slate-400 truncate">{sessionLabel}</div>
              <div className="text-xs font-bold text-emerald-400 mt-0.5">متصل ومحمي</div>
            </div>
            <span
              className="w-2.5 h-2.5 rounded-full bg-emerald-400 shadow-[0_0_10px_#34D399] shrink-0"
              aria-hidden="true"
            />
          </div>
          <div className="border-t border-[#1B2947] pt-2 space-y-1">
            <div className="flex items-center justify-between">
              <span className="text-[11px] text-slate-400">سعة الاشتراك</span>
              <span className="text-[11px] font-bold text-slate-200 font-mono tabular-nums">
                {isAdminUnlocked
                  ? 'غير محدود (مدير)'
                  : maxDevices <= 1
                    ? 'شخص واحد (1/1)'
                    : `${connectedDevicesCount}/${maxDevices} أشخاص`}
              </span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-[11px] text-slate-400">المدة المتبقية</span>
              <span className="text-xs font-bold text-slate-200 font-mono tabular-nums">
                {durationDays} يوم
              </span>
            </div>
            {formattedExpiry && (
              <div className="flex items-center justify-between">
                <span className="text-[11px] text-slate-400">تاريخ الانتهاء</span>
                <span className="text-[11px] font-bold text-cyan-300 font-mono tabular-nums">
                  {formattedExpiry}
                </span>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );

  return (
    <div
      onContextMenu={(e) => {
        if (!isAdminUnlocked) e.preventDefault();
      }}
      className="h-dvh max-h-dvh overflow-hidden bg-[#060B16] text-slate-100 flex flex-col"
      dir="ltr"
    >
      {/* Toast Notification */}
      {toast && (
        <div
          className="fixed bottom-[calc(4.5rem+env(safe-area-inset-bottom,0px))] lg:bottom-6 left-1/2 -translate-x-1/2 z-[90] max-w-[92vw] px-4 sm:px-5 py-2.5 rounded-xl bg-[#1268FB] text-white text-xs font-bold shadow-xl border border-blue-400/30 text-center truncate"
          dir="rtl"
        >
          {toast}
        </div>
      )}

      {/* Click-away backdrop for header popovers on touch screens */}
      {(showProfileMenu || showBellMenu) && (
        <div
          onClick={() => {
            setShowProfileMenu(false);
            setShowBellMenu(false);
          }}
          className="fixed inset-0 z-20"
          aria-hidden="true"
        />
      )}

      {/* =====================================================================
          ADMIN MAINTENANCE ACTIVE TOP STRIP (Visible ONLY to Admin while App is Paused)
         ===================================================================== */}
      {maintenanceState.active && isAdminUnlocked && (
        <div
          className="shrink-0 z-30 px-3 sm:px-6 py-2 bg-amber-500/15 border-b border-amber-400/35 flex flex-wrap items-center justify-between gap-2 text-xs"
          dir="rtl"
        >
          <div className="flex items-center gap-2 text-amber-200 font-bold min-w-0">
            <Wrench className="w-4 h-4 text-amber-400 shrink-0" />
            <span className="truncate">
              وضع الصيانة مفعّل حالياً للمستخدمين («{maintenanceState.message}») — أنت تتصفح كمدير
            </span>
          </div>
          <div className="flex items-center gap-2 shrink-0 mr-auto sm:mr-0">
            <button
              type="button"
              onClick={() => openAdminModalOnTab('protection')}
              className="min-h-[32px] px-2.5 py-1 rounded-lg bg-white/10 hover:bg-white/15 text-white text-[11px] font-bold cursor-pointer"
            >
              إعدادات الصيانة
            </button>
            <button
              type="button"
              disabled={togglingMaintenanceBanner}
              onClick={handleQuickDisableMaintenance}
              className="min-h-[32px] px-3 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white text-[11px] font-extrabold flex items-center gap-1 cursor-pointer"
            >
              <Power className="w-3.5 h-3.5" />
              <span>
                {togglingMaintenanceBanner ? 'جاري التشغيل...' : 'تشغيل التطبيق للمستخدمين'}
              </span>
            </button>
          </div>
        </div>
      )}

      {/* =====================================================================
          100% LOCKED TOP HEADER BAR (52px on Mobile, 72px on Desktop — shrink-0)
         ===================================================================== */}
      <header className="shrink-0 z-30 pt-safe px-safe bg-[#060B16] border-b border-[#142038]">
        <div className="h-[52px] lg:h-[72px] px-3 sm:px-5 lg:px-6 flex items-center justify-between gap-2.5 sm:gap-3">
          {mobileSearchOpen ? (
            /* Mobile Full-Width Search Mode */
            <div className="flex items-center gap-2 w-full lg:hidden" dir="rtl">
              <div className="relative flex-1">
                <Search className="w-4 h-4 text-slate-400 absolute right-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                <input
                  type="text"
                  autoFocus
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="ابحث عن قناة أو فيلم أو مسلسل..."
                  className="w-full min-h-[40px] pr-10 pl-9 py-2 rounded-full bg-[#111B2E] border border-blue-500/60 text-xs text-white placeholder-slate-400 focus:outline-none"
                />
                {searchQuery && (
                  <button
                    type="button"
                    onClick={() => setSearchQuery('')}
                    className="absolute left-2 top-1/2 -translate-y-1/2 min-h-[34px] min-w-[34px] flex items-center justify-center text-slate-400 hover:text-white"
                    aria-label="مسح البحث"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>
              <button
                type="button"
                onClick={() => {
                  setSearchQuery('');
                  setMobileSearchOpen(false);
                }}
                className="min-h-[44px] px-3.5 rounded-xl bg-white/5 text-xs font-semibold text-slate-300 shrink-0"
              >
                إلغاء
              </button>
            </div>
          ) : (
            <>
              {/* Left: Brand Logo (Silent 5-tap secret owner gesture) */}
              <button
                type="button"
                onClick={handleBrandClick}
                className="min-h-[44px] cursor-pointer focus:outline-none shrink-0 flex items-center"
                aria-label="MS TV"
              >
                <div className="sm:hidden">
                  <BrandMark size="sm" />
                </div>
                <div className="hidden sm:block">
                  <BrandMark size="md" />
                </div>
              </button>

              {/* Center: Desktop/Tablet Search Input */}
              <div className="hidden lg:block flex-1 max-w-2xl mx-4">
                <div className="relative flex items-center">
                  <Search className="w-4 h-4 text-slate-400 absolute left-4 pointer-events-none" />
                  <input
                    type="text"
                    dir="rtl"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="ابحث عن قناة أو فيلم أو مسلسل ..."
                    className="w-full pl-11 pr-4 py-2.5 rounded-full bg-[#111B2E] border border-[#1E2E4F] focus:border-blue-500 text-sm text-white placeholder-slate-400 focus:outline-none transition-colors"
                  />
                  {searchQuery && (
                    <button
                      type="button"
                      onClick={() => setSearchQuery('')}
                      className="absolute right-3.5 text-slate-400 hover:text-white"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  )}
                </div>
              </div>

              {/* Right: Mobile Search Trigger + Profile + Desktop Clock */}
              <div className="flex items-center gap-1.5 sm:gap-3.5 shrink-0">
                <button
                  type="button"
                  onClick={() => setMobileSearchOpen(true)}
                  className="lg:hidden min-h-[44px] min-w-[44px] rounded-full bg-[#101A30] border border-[#1E2E4F] flex items-center justify-center text-slate-200 active:scale-95 transition-transform"
                  aria-label="بحث"
                >
                  <Search className="w-4 h-4" />
                </button>

                {isAdminUnlocked && (
                  <div className="flex items-center gap-1.5" dir="rtl">
                    <button
                      type="button"
                      onClick={() => openAdminModalOnTab('protection')}
                      className="min-h-[44px] min-w-[44px] sm:min-h-[40px] sm:min-w-0 px-3 rounded-xl bg-emerald-600/20 hover:bg-emerald-600/30 border border-emerald-500/40 text-emerald-300 text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer"
                      title="الحماية والـ VPN"
                    >
                      <Shield className="w-3.5 h-3.5" />
                      <span className="hidden md:inline">الحماية</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => openAdminModalOnTab('m3u')}
                      className="min-h-[44px] min-w-[44px] sm:min-h-[40px] sm:min-w-0 px-3 rounded-xl bg-purple-600/20 hover:bg-purple-600/30 border border-purple-500/40 text-purple-300 text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer"
                    >
                      <Crown className="w-3.5 h-3.5" />
                      <span className="hidden sm:inline">لوحة المدير</span>
                    </button>
                  </div>
                )}

              {/* Desktop Bell Popover */}
              <div className="hidden sm:block relative">
                <button
                  type="button"
                  onClick={() => {
                    setShowBellMenu((v) => !v);
                    setShowProfileMenu(false);
                  }}
                  className="w-9 h-9 rounded-full bg-[#101A30] hover:bg-[#162442] border border-[#1E2E4F] flex items-center justify-center text-slate-200 transition-colors cursor-pointer"
                  title="ملخص القنوات"
                >
                  <Bell className="w-4 h-4" />
                </button>
                {showBellMenu && (
                  <div
                    className="absolute right-0 mt-2 w-64 rounded-2xl bg-[#0B1222] border border-[#1E325C] shadow-2xl p-4 z-40 space-y-2 text-xs"
                    dir="rtl"
                  >
                    <div className="font-bold text-white flex items-center justify-between">
                      <span>ملخص البث</span>
                      <button
                        type="button"
                        onClick={() => setShowBellMenu(false)}
                        className="text-slate-400 hover:text-white"
                      >
                        <X className="w-3.5 h-3.5" />
                      </button>
                    </div>
                    <div className="text-slate-300">
                      القنوات المتاحة:{' '}
                      <strong className="text-white font-mono tabular-nums">{channels.length}</strong>
                    </div>
                    <div className="text-slate-300">
                      الأقسام:{' '}
                      <strong className="text-white font-mono tabular-nums">
                        {categories.length + (channels.length > 0 ? 1 : 0)}
                      </strong>
                    </div>
                    {formattedExpiry && (
                      <div className="text-slate-300 pt-1 border-t border-[#1B2947]">
                        صالح حتى:{' '}
                        <strong className="text-cyan-300 font-mono tabular-nums">
                          {formattedExpiry}
                        </strong>
                      </div>
                    )}
                  </div>
                )}
              </div>

              {/* User Session Menu (Zero Admin links unless isAdminUnlocked!) */}
              <div className="relative">
                <button
                  type="button"
                  onClick={() => {
                    setShowProfileMenu((v) => !v);
                    setShowBellMenu(false);
                  }}
                  className="min-h-[44px] min-w-[44px] sm:min-h-[38px] sm:min-w-[38px] rounded-full flex items-center justify-center cursor-pointer"
                  title="الحساب"
                >
                  <span className="w-9 h-9 rounded-full bg-slate-200 text-[#0B1222] hover:bg-white flex items-center justify-center transition-colors">
                    <User className="w-4 h-4" />
                  </span>
                </button>
                {showProfileMenu && (
                  <div
                    className="absolute right-0 mt-2 w-64 max-w-[88vw] rounded-2xl bg-[#0B1222] border border-[#1E325C] shadow-2xl p-3.5 z-40 space-y-1.5 text-xs"
                    dir="rtl"
                  >
                    <div className="pb-2.5 border-b border-[#1B2947] space-y-1">
                      <div className="font-bold text-white truncate">{sessionLabel}</div>
                      <div className="text-[11px] text-emerald-400">
                        متصل · متبقي {durationDays} يوم
                      </div>
                      {formattedExpiry && (
                        <div className="text-[11px] text-slate-400 flex items-center gap-1">
                          <Calendar className="w-3 h-3 text-cyan-400" />
                          <span>ينتهي في:</span>
                          <span className="font-mono text-cyan-300">{formattedExpiry}</span>
                        </div>
                      )}
                    </div>

                    <button
                      type="button"
                      onClick={() => {
                        setShowProfileMenu(false);
                        setCustomListModalTarget('NEW');
                      }}
                      className="w-full min-h-[44px] px-3 py-2 rounded-xl hover:bg-white/5 text-slate-200 flex items-center gap-2 cursor-pointer"
                    >
                      <FolderPlus className="w-4 h-4 text-blue-400" />
                      <span>إنشاء قائمة خاصة للقنوات</span>
                    </button>

                    {canInstall && (
                      <button
                        type="button"
                        onClick={handleMobileInstallClick}
                        className="w-full min-h-[44px] px-3 py-2 rounded-xl hover:bg-white/5 text-cyan-300 flex items-center gap-2 cursor-pointer"
                      >
                        <Download className="w-4 h-4 text-cyan-400" />
                        <span>تثبيت التطبيق على الهاتف</span>
                      </button>
                    )}

                    {isAdminUnlocked && (
                      <button
                        type="button"
                        onClick={() => {
                          setShowProfileMenu(false);
                          openAdminModalOnTab('m3u');
                        }}
                        className="w-full min-h-[44px] px-3 py-2 rounded-xl hover:bg-white/5 text-purple-300 flex items-center gap-2 cursor-pointer"
                      >
                        <Crown className="w-4 h-4 text-purple-400" />
                        <span>لوحة إدارة المصادر</span>
                      </button>
                    )}

                    <button
                      type="button"
                      onClick={handleLogout}
                      className="w-full min-h-[44px] px-3 py-2 rounded-xl hover:bg-red-500/15 text-red-400 flex items-center gap-2 cursor-pointer"
                    >
                      <LogOut className="w-4 h-4" />
                      <span>تسجيل الخروج</span>
                    </button>
                  </div>
                )}
              </div>

              <div className="hidden md:block h-7 w-px bg-[#1B2947]" />

              <div className="hidden md:flex flex-col items-end leading-tight">
                <span className="font-mono tabular-nums text-lg font-bold text-white tracking-tight">
                  {timeFormatted}
                </span>
                <span className="text-[11px] text-slate-400 whitespace-nowrap" dir="rtl">
                  {dateFormatted}
                </span>
              </div>
            </div>
          </>
        )}
        </div>
      </header>

      {/* =====================================================================
          LOCKED VIEWPORT WORKSPACE (Sidebar & Section Headers stay 100% fixed;
          ONLY inner list containers scroll!)
         ===================================================================== */}
      <div className="flex-1 min-h-0 grid grid-cols-1 lg:grid-cols-[245px_minmax(0,1fr)] gap-3 lg:gap-6 px-3 sm:px-5 lg:px-6 pt-2.5 pb-1 lg:py-4 px-safe max-w-[1680px] w-full mx-auto overflow-hidden">
        {/* Desktop Left Sidebar — 100% Fixed in Frame */}
        <aside className="hidden lg:block h-full min-h-0 overflow-hidden">
          {renderDesktopSidebar()}
        </aside>

        {/* Main Viewport — Flex Column so Headers/Search stay fixed while Lists scroll */}
        <main className="h-full min-h-0 min-w-0 flex flex-col overflow-hidden">
          {activeNav === 'home' && !searchQuery.trim() ? (
            <div
              ref={homeScrollRef}
              className="flex-1 min-h-0 overflow-y-auto overscroll-contain space-y-3 sm:space-y-4 pb-4 sm:pl-1"
            >
              <HeroBanner
                heroSlides={heroSlides}
                channels={channels}
                featuredChannels={featuredChannels}
                isAdminUnlocked={isAdminUnlocked}
                onWatchChannel={handlePlayChannel}
                onOpenCategory={selectExactM3uGroup}
                onManageSlides={() => openAdminModalOnTab('hero')}
              />

              <CategoryCards
                channels={channels}
                categories={categories}
                onSelectSection={selectSidebarNav}
              />

              {/* Section: أحدث الإضافات */}
              <section className="space-y-2">
                <div className="flex items-center justify-between" dir="rtl">
                  <h2 className="text-xs sm:text-base font-extrabold text-white">أحدث الإضافات</h2>
                  <button
                    type="button"
                    onClick={() => selectSidebarNav('live_tv')}
                    className="min-h-[32px] px-2 text-[11px] sm:text-xs font-bold text-blue-400 hover:text-blue-300 cursor-pointer flex items-center"
                  >
                    عرض الكل
                  </button>
                </div>

                <div
                  className="flex sm:grid sm:grid-cols-4 md:grid-cols-5 lg:grid-cols-6 gap-2 sm:gap-2.5 overflow-x-auto sm:overflow-visible no-scrollbar snap-x snap-mandatory pb-1"
                  dir="rtl"
                >
                  {recentlyAddedItems.map((item, idx) => {
                    const theme = POSTER_THEMES[idx % POSTER_THEMES.length];
                    return (
                      <div
                        key={item.id}
                        onClick={() => handlePlayChannel(item)}
                        className={`snap-start shrink-0 w-[112px] sm:w-auto h-[142px] sm:h-[156px] lg:h-[168px] group relative rounded-xl overflow-hidden border border-[#1E2E4F] hover:border-blue-500/70 bg-gradient-to-b ${theme} flex flex-col justify-between p-2 sm:p-2.5 cursor-pointer active:scale-[0.98] transition-transform duration-150 select-none`}
                      >
                        {item.logo ? (
                          <img
                            src={item.logo}
                            alt={item.name}
                            referrerPolicy="no-referrer"
                            loading="lazy"
                            draggable={false}
                            onError={(e) => {
                              (e.currentTarget as HTMLImageElement).classList.add('hidden');
                            }}
                            className="absolute inset-0 w-full h-full object-cover opacity-75 group-hover:scale-105 transition-transform duration-300"
                          />
                        ) : (
                          <div className="absolute inset-0 flex items-center justify-center opacity-25 pointer-events-none">
                            <Film className="w-10 h-10 text-white" />
                          </div>
                        )}

                        <div className="absolute inset-0 bg-gradient-to-t from-[#040812] via-[#040812]/55 to-transparent" />

                        <div className="relative z-10 flex items-center justify-between">
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              handleToggleFavorite(item.id);
                            }}
                            className="w-7 h-7 rounded-lg bg-black/55 hover:bg-black/80 flex items-center justify-center text-slate-200"
                            title="المفضلة"
                          >
                            <Star
                              className={`w-3.5 h-3.5 ${
                                favorites.includes(item.id)
                                  ? 'fill-amber-400 text-amber-400'
                                  : ''
                              }`}
                            />
                          </button>

                          {isAdminUnlocked && (
                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                setEditingChannel(item);
                              }}
                              className="w-7 h-7 rounded-lg bg-black/55 hover:bg-blue-600 text-white flex items-center justify-center"
                              title="تعديل"
                            >
                              <Edit3 className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </div>

                        <div className="relative z-10 text-center space-y-0.5 pt-3">
                          <h3 className="text-[11px] sm:text-xs font-extrabold text-white line-clamp-2 leading-snug">
                            {item.name}
                          </h3>
                          <div className="flex items-center justify-between pt-0.5">
                            <span className="text-[9.5px] sm:text-[10px] text-slate-300 truncate max-w-[70%]">
                              {item.year || item.group}
                            </span>
                            <span className="font-display text-[9px] font-bold bg-white/90 text-slate-900 px-1 py-0.5 rounded">
                              HD
                            </span>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </section>

              {/* Section: القنوات المميزة */}
              <section className="space-y-2">
                <div className="flex items-center justify-between" dir="rtl">
                  <h2 className="text-xs sm:text-base font-extrabold text-white">القنوات المميزة</h2>
                  <button
                    type="button"
                    onClick={() => selectSidebarNav('live_tv')}
                    className="min-h-[32px] px-2 text-[11px] sm:text-xs font-bold text-blue-400 hover:text-blue-300 cursor-pointer flex items-center"
                  >
                    عرض الكل
                  </button>
                </div>

                <div className="grid grid-cols-4 sm:grid-cols-5 md:grid-cols-6 lg:grid-cols-8 xl:grid-cols-10 gap-2 sm:gap-2.5">
                  {featuredChannels.slice(0, 10).map((ch) => (
                    <button
                      key={ch.id}
                      type="button"
                      onClick={() => handlePlayChannel(ch)}
                      className="group relative h-[56px] sm:h-[64px] lg:h-[70px] rounded-xl p-0.5 active:scale-95 transition-transform cursor-pointer"
                      title={`تشغيل ${ch.name}`}
                    >
                      <ChannelLogo
                        name={ch.name}
                        logo={ch.logo}
                        group={ch.group}
                        size="wide"
                      />
                    </button>
                  ))}
                </div>
              </section>
            </div>
          ) : activeNav === 'settings' && !searchQuery.trim() ? (
            /* =================================================================
               SETTINGS & CUSTOM LISTS VIEW (Header fixed, content scrollable)
               ================================================================= */
            <div className="h-full min-h-0 flex flex-col gap-3 overflow-hidden" dir="rtl">
              <div className="shrink-0 bg-[#0B1222] border border-[#1E325C] rounded-2xl p-3.5 sm:p-4 flex items-center gap-3">
                <button
                  type="button"
                  onClick={() => selectSidebarNav('home')}
                  className="min-h-[40px] px-3.5 rounded-xl bg-[#1268FB] hover:bg-[#2575FC] text-white text-xs font-extrabold flex items-center gap-1.5 cursor-pointer shrink-0"
                >
                  <ChevronRight className="w-4 h-4" />
                  <span>رجوع للرئيسية</span>
                </button>
                <h1 className="text-base sm:text-lg font-extrabold text-white truncate">
                  الإعدادات والقوائم الخاصة
                </h1>
              </div>

              <div className="flex-1 min-h-0 overflow-y-auto overscroll-contain pb-4 pl-1">
                <div className="bg-[#0B1222] border border-[#1B2947] rounded-2xl p-4 sm:p-6 space-y-4">
                  <div className="p-4 rounded-2xl bg-[#060B16] border border-[#1B2947] flex flex-wrap items-center justify-between gap-3">
                    <div>
                      <div className="text-sm font-bold text-white">القوائم الخاصة للقنوات</div>
                      <div className="text-xs text-slate-400 mt-0.5">
                        أنشئ قوائم مخصصة ورتب قنواتك المفضلة بأسماء وألوان من اختيارك
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={() => setCustomListModalTarget('NEW')}
                      className="min-h-[44px] px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer"
                    >
                      <Plus className="w-4 h-4" />
                      <span>إنشاء قائمة خاصة</span>
                    </button>
                  </div>

                  {canInstall && (
                    <div className="p-4 rounded-2xl bg-[#060B16] border border-cyan-500/30 flex flex-wrap items-center justify-between gap-3">
                      <div>
                        <div className="text-sm font-bold text-white flex items-center gap-2">
                          <Smartphone className="w-4 h-4 text-cyan-400" />
                          <span>تثبيت تطبيق MS TV على الهاتف</span>
                        </div>
                        <div className="text-xs text-slate-400 mt-0.5">
                          أضف التطبيق إلى الشاشة الرئيسية لتشغيله بملء الشاشة مباشرة بدون شريط المتصفح
                        </div>
                      </div>
                      <button
                        type="button"
                        onClick={handleMobileInstallClick}
                        className="min-h-[44px] px-4 py-2.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer"
                      >
                        <Download className="w-4 h-4" />
                        <span>تثبيت التطبيق الآن</span>
                      </button>
                    </div>
                  )}

                  <div className="p-4 rounded-2xl bg-[#060B16] border border-[#1B2947] flex flex-wrap items-center justify-between gap-3">
                    <div className="space-y-1">
                      <div className="text-sm font-bold text-white">حالة الاشتراك</div>
                      <div className="text-xs text-slate-400">
                        {sessionLabel} · متبقي <strong className="text-white">{durationDays}</strong> يوم
                      </div>
                      <div className="text-xs text-slate-300 flex items-center gap-1.5">
                        <Users className="w-3.5 h-3.5 text-blue-400" />
                        <span>سعة الاشتراك:</span>
                        <span className="font-mono tabular-nums font-bold text-white">
                          {isAdminUnlocked
                            ? 'غير محدود (المدير)'
                            : maxDevices <= 1
                              ? 'شخص واحد فقط (جهاز واحد)'
                              : `${connectedDevicesCount} من أصل ${maxDevices} أشخاص`}
                        </span>
                      </div>
                      {formattedExpiry && (
                        <div className="text-xs text-cyan-300 flex items-center gap-1.5">
                          <Calendar className="w-3.5 h-3.5" />
                          <span>تاريخ انتهاء الاشتراك:</span>
                          <span className="font-mono font-bold">{formattedExpiry}</span>
                        </div>
                      )}
                    </div>
                    <span className="text-xs font-bold text-emerald-400">متصل ونشط</span>
                  </div>

                  {/* Shown ONLY if logged in as Admin */}
                  {isAdminUnlocked && (
                    <div className="p-4 rounded-2xl bg-purple-500/10 border border-purple-500/30 flex flex-wrap items-center justify-between gap-3">
                      <div>
                        <div className="text-sm font-bold text-white flex items-center gap-2">
                          <Crown className="w-4 h-4 text-purple-400" />
                          <span>لوحة التحكم والحماية القوية والاشتراكات</span>
                        </div>
                        <div className="text-xs text-slate-300 mt-0.5">
                          تفعيل وإطفاء منع HttpCanary والـ VPN · إنشاء اشتراك لشخص واحد أو عدة أشخاص
                        </div>
                      </div>
                      <div className="flex flex-wrap items-center gap-2">
                        <button
                          type="button"
                          onClick={() => openAdminModalOnTab('protection')}
                          className="min-h-[44px] px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer"
                        >
                          <Shield className="w-4 h-4" />
                          <span>الحماية والـ VPN</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => openAdminModalOnTab('m3u')}
                          className="min-h-[44px] px-4 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-bold cursor-pointer"
                        >
                          فتح لوحة المدير
                        </button>
                      </div>
                    </div>
                  )}

                  <div className="pt-2 flex justify-end">
                    <button
                      type="button"
                      onClick={handleLogout}
                      className="min-h-[44px] px-5 py-2.5 rounded-xl bg-red-500/15 hover:bg-red-500/25 text-red-300 text-xs font-bold flex items-center gap-2 cursor-pointer"
                    >
                      <LogOut className="w-4 h-4" />
                      <span>تسجيل الخروج</span>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ) : (activeNav === 'live_tv' || activeNav === 'm3u_group') && !searchQuery.trim() ? (
            /* =================================================================
               VERTICAL M3U CATEGORIES DIRECTORY -> CHANNELS OF SELECTED CATEGORY
               EVERYTHING AT THE TOP & SIDES IS 100% LOCKED (shrink-0 / h-full);
               ONLY THE INNER CATEGORIES OR CHANNELS LIST SCROLLS!
               ================================================================= */
            !selectedM3uGroup ? (
              /* STEP 1: Vertical List of Exact M3U Categories (with "كل القنوات" pinned first) */
              <div className="h-full min-h-0 flex flex-col gap-3 overflow-hidden" dir="rtl">
                {/* 100% Locked Top Control & Search Block (NEVER moves on scroll!) */}
                <div className="shrink-0 space-y-2.5">
                  <div className="bg-[#0B1222] border border-[#1E325C] rounded-2xl p-3 sm:p-4 flex flex-wrap items-center justify-between gap-2.5">
                    <div className="flex items-center gap-2.5 min-w-0">
                      <button
                        type="button"
                        onClick={() => selectSidebarNav('home')}
                        className="min-h-[40px] px-3.5 rounded-xl bg-[#1268FB] hover:bg-[#2575FC] text-white text-xs font-extrabold flex items-center gap-1.5 cursor-pointer shrink-0 shadow-[0_4px_14px_rgba(18,104,251,0.35)] active:scale-95 transition-all"
                        title="العودة للرئيسية"
                      >
                        <ChevronRight className="w-4 h-4" />
                        <span>رجوع للرئيسية</span>
                      </button>
                      <div className="min-w-0">
                        <h1 className="text-sm sm:text-lg font-extrabold text-white truncate">
                          أقسام القنوات
                        </h1>
                        <p className="text-[11px] text-slate-400">
                          <span className="font-mono tabular-nums text-white font-bold">
                            {categories.length + (channels.length > 0 ? 1 : 0)}
                          </span>{' '}
                          قسم ·{' '}
                          <span className="font-mono tabular-nums text-white font-bold">
                            {channels.length}
                          </span>{' '}
                          قناة
                        </p>
                      </div>
                    </div>

                    {isAdminUnlocked && (
                      <div className="flex flex-wrap items-center gap-2">
                        <button
                          type="button"
                          onClick={() => openAdminModalOnTab('categories')}
                          className="min-h-[38px] px-3 py-1.5 rounded-xl bg-purple-600/20 hover:bg-purple-600/35 border border-purple-500/40 text-purple-200 text-xs font-bold flex items-center gap-1.5 cursor-pointer"
                        >
                          <Layers className="w-3.5 h-3.5" />
                          <span>الأقسام وشعاراتها</span>
                        </button>
                      </div>
                    )}
                  </div>

                  {/* Pinned Search Input for M3U Categories — stays fixed at top while scrolling! */}
                  {(categories.length > 0 || channels.length > 0) && (
                    <div className="relative">
                      <Search className="w-4 h-4 text-slate-400 absolute right-4 top-1/2 -translate-y-1/2 pointer-events-none" />
                      <input
                        type="text"
                        value={m3uGroupSearch}
                        onChange={(e) => setM3uGroupSearch(e.target.value)}
                        placeholder="ابحث عن قسم داخل الباقة..."
                        className="w-full min-h-[42px] pr-11 pl-10 py-2 rounded-2xl bg-[#0B1222] border border-[#1B2947] focus:border-blue-500 text-xs sm:text-sm text-white placeholder-slate-400 focus:outline-none transition-colors"
                      />
                      {m3uGroupSearch && (
                        <button
                          type="button"
                          onClick={() => setM3uGroupSearch('')}
                          className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white cursor-pointer"
                        >
                          <X className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                  )}
                </div>

                {/* Independently Scrollable Categories List */}
                <div
                  ref={categoriesScrollRef}
                  className="flex-1 min-h-0 overflow-y-auto overscroll-contain sm:pl-1 pb-3"
                >
                  {(() => {
                    const normalizedGroupQuery = m3uGroupSearch.trim().toLowerCase();
                    const showPinnedAllChannels =
                      channels.length > 0 &&
                      (!normalizedGroupQuery ||
                        'كل القنوات جميع القنوات all channels'.includes(normalizedGroupQuery));

                    if (!showPinnedAllChannels && filteredM3uCategories.length === 0) {
                      return (
                        <div className="bg-[#0B1222] border border-[#1B2947] rounded-2xl p-10 text-center space-y-2.5">
                          <Layers className="w-9 h-9 text-slate-500 mx-auto" />
                          <p className="text-sm font-bold text-slate-200">
                            لا توجد أقسام مطابقة لبحثك
                          </p>
                        </div>
                      );
                    }

                    return (
                      <div className="flex flex-col gap-2.5">
                        {/* Pinned First Section: كل القنوات */}
                        {showPinnedAllChannels && (
                          <div
                            onClick={() => selectExactM3uGroup('__ALL__')}
                            role="button"
                            tabIndex={0}
                            onKeyDown={(e) => {
                              if (e.key === 'Enter' || e.key === ' ') {
                                e.preventDefault();
                                selectExactM3uGroup('__ALL__');
                              }
                            }}
                            className="group w-full min-h-[64px] px-4 py-3 rounded-2xl bg-[#0D1830] hover:bg-[#122243] border border-blue-500/45 hover:border-blue-400 active:scale-[0.996] transition-all cursor-pointer flex items-center justify-between gap-3 text-right select-none"
                          >
                            <div className="flex items-center gap-3.5 min-w-0 flex-1">
                              <CategoryLogo name="كل القنوات" isAll size="md" />
                              <div className="min-w-0 flex-1">
                                <div className="text-sm sm:text-base font-bold text-white truncate">
                                  كل القنوات
                                </div>
                                <div className="text-[11px] text-slate-300 mt-0.5">
                                  جميع القنوات المتاحة · مثبت أول قسم
                                </div>
                              </div>
                            </div>

                            <div className="flex items-center gap-2 shrink-0">
                              <span className="text-xs sm:text-sm text-slate-200 font-mono tabular-nums">
                                {channels.length}{' '}
                                <span className="font-sans text-slate-400 text-xs">قناة</span>
                              </span>
                              <ChevronLeft className="w-4 h-4 text-blue-400 group-hover:-translate-x-0.5 transition-all" />
                            </div>
                          </div>
                        )}

                        {filteredM3uCategories.map((cat, idx) => {
                          const canMoveInline = isAdminUnlocked && !m3uGroupSearch.trim();
                          return (
                            <div
                              key={cat.name}
                              onClick={() => selectExactM3uGroup(cat.name)}
                              role="button"
                              tabIndex={0}
                              onKeyDown={(e) => {
                                if (e.key === 'Enter' || e.key === ' ') {
                                  e.preventDefault();
                                  selectExactM3uGroup(cat.name);
                                }
                              }}
                              className="group w-full min-h-[64px] px-4 py-3 rounded-2xl bg-[#0B1222] hover:bg-[#101C36] border border-[#1B2947] hover:border-blue-500/60 active:scale-[0.996] transition-all cursor-pointer flex items-center justify-between gap-3 text-right select-none"
                            >
                              <div className="flex items-center gap-3.5 min-w-0 flex-1">
                                <CategoryLogo name={cat.name} logo={cat.logo} size="md" />
                                <div className="min-w-0 flex-1">
                                  <div className="text-sm sm:text-base font-bold text-white truncate">
                                    {cat.name}
                                  </div>
                                  <div className="text-[11px] text-slate-400 mt-0.5">
                                    اضغط لعرض قنوات القسم
                                  </div>
                                </div>
                              </div>

                              <div className="flex items-center gap-2 shrink-0">
                                {/* Admin-only quick Up/Down category reorder buttons (hidden for users) */}
                                {canMoveInline && (
                                  <div className="flex items-center gap-1 ml-1">
                                    <button
                                      type="button"
                                      disabled={idx === 0 || reorderingCategory === cat.name}
                                      onClick={(e) => handleMoveCategoryInline(cat.name, 'up', e)}
                                      className="min-h-[44px] min-w-[44px] sm:min-h-[38px] sm:min-w-[38px] rounded-xl bg-white/5 hover:bg-purple-600/40 disabled:opacity-25 border border-white/10 text-slate-200 flex items-center justify-center cursor-pointer transition-colors"
                                      title="تحريك القسم للأعلى"
                                    >
                                      <ArrowUp className="w-3.5 h-3.5" />
                                    </button>
                                    <button
                                      type="button"
                                      disabled={
                                        idx === filteredM3uCategories.length - 1 ||
                                        reorderingCategory === cat.name
                                      }
                                      onClick={(e) => handleMoveCategoryInline(cat.name, 'down', e)}
                                      className="min-h-[44px] min-w-[44px] sm:min-h-[38px] sm:min-w-[38px] rounded-xl bg-white/5 hover:bg-purple-600/40 disabled:opacity-25 border border-white/10 text-slate-200 flex items-center justify-center cursor-pointer transition-colors"
                                      title="تحريك القسم للأسفل"
                                    >
                                      <ArrowDown className="w-3.5 h-3.5" />
                                    </button>
                                  </div>
                                )}

                                <span className="text-xs sm:text-sm text-slate-300 font-mono tabular-nums">
                                  {cat.count}{' '}
                                  <span className="font-sans text-slate-400 text-xs">قناة</span>
                                </span>
                                <ChevronLeft className="w-4 h-4 text-slate-400 group-hover:text-blue-400 group-hover:-translate-x-0.5 transition-all" />
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    );
                  })()}
                </div>
              </div>
            ) : (
              /* STEP 2: Channels of Selected Category — Top Bar & Side Categories 100% Locked! */
              <div className="h-full min-h-0 flex flex-col gap-3 overflow-hidden" dir="rtl">
                {/* 100% Locked Back Button + Category Title + In-Category Search */}
                <div className="shrink-0 bg-[#0B1222] border border-[#1E325C] rounded-2xl p-3 sm:p-4 flex flex-wrap items-center justify-between gap-2.5">
                  <div className="flex items-center gap-2.5 min-w-0">
                    <button
                      type="button"
                      onClick={returnToM3uCategories}
                      className="min-h-[42px] px-3.5 sm:px-4 rounded-xl bg-[#1268FB] hover:bg-[#2575FC] text-white text-xs font-extrabold flex items-center gap-1.5 cursor-pointer shrink-0 shadow-[0_4px_14px_rgba(18,104,251,0.4)] active:scale-95 transition-all"
                      title="العودة لأقسام القنوات"
                    >
                      <ChevronRight className="w-4 h-4" />
                      <span>رجوع للأقسام</span>
                    </button>
                    <CategoryLogo
                      name={selectedM3uGroup === '__ALL__' ? 'كل القنوات' : selectedM3uGroup}
                      logo={categories.find((c) => c.name === selectedM3uGroup)?.logo}
                      isAll={selectedM3uGroup === '__ALL__'}
                      size="sm"
                    />
                    <div className="min-w-0">
                      <h1 className="text-sm sm:text-lg font-extrabold text-white truncate">
                        {getSectionHeading()}
                      </h1>
                      <p className="text-[11px] text-slate-400">
                        الإجمالي:{' '}
                        <span className="font-mono tabular-nums text-white font-bold">
                          {sectionChannels.length}
                        </span>{' '}
                        قناة
                      </p>
                    </div>
                  </div>

                  {/* Pinned Search inside the selected category */}
                  <div className="relative w-full sm:w-64">
                    <Search className="w-3.5 h-3.5 text-slate-400 absolute right-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                    <input
                      type="text"
                      value={inCategorySearch}
                      onChange={(e) => {
                        setInCategorySearch(e.target.value);
                        setVisibleChannelCount(300);
                        if (channelsScrollRef.current) channelsScrollRef.current.scrollTop = 0;
                      }}
                      placeholder="ابحث داخل هذا القسم..."
                      className="w-full min-h-[42px] sm:min-h-[38px] pr-9 pl-9 py-1.5 rounded-xl bg-[#060B16] border border-[#1E2E4F] focus:border-blue-500 text-xs text-white placeholder-slate-400 focus:outline-none"
                    />
                    {inCategorySearch && (
                      <button
                        type="button"
                        onClick={() => setInCategorySearch('')}
                        className="absolute left-1.5 top-1/2 -translate-y-1/2 min-h-[36px] min-w-[36px] flex items-center justify-center text-slate-400 hover:text-white cursor-pointer"
                        aria-label="مسح البحث"
                      >
                        <X className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                </div>

                {/* Locked Split Area: Side Categories Column (independent scroll) + Channels Grid (independent scroll) */}
                <div className="flex-1 min-h-0 grid grid-cols-1 xl:grid-cols-[265px_minmax(0,1fr)] gap-4 overflow-hidden">
                  {/* Vertical M3U Categories Column on Wide Desktop — Fixed Frame */}
                  {(categories.length > 0 || channels.length > 0) && (
                    <div className="hidden xl:flex flex-col h-full min-h-0 bg-[#0B1222] border border-[#1B2947] rounded-2xl p-2.5 overflow-hidden">
                      <div className="shrink-0 space-y-1 pb-2 mb-1.5 border-b border-[#1B2947]">
                        <div className="px-2.5 py-1.5 text-xs font-extrabold text-slate-300 flex items-center justify-between">
                          <span>أقسام القنوات</span>
                          <span className="font-mono tabular-nums text-[11px] text-slate-400">
                            {categories.length + (channels.length > 0 ? 1 : 0)}
                          </span>
                        </div>
                        {channels.length > 0 && (
                          <button
                            type="button"
                            onClick={() => selectExactM3uGroup('__ALL__')}
                            className={`w-full px-2.5 py-2 rounded-xl flex items-center justify-between gap-2 text-xs font-bold transition-colors cursor-pointer text-right ${
                              selectedM3uGroup === '__ALL__'
                                ? 'bg-[#1268FB] text-white'
                                : 'text-slate-300 hover:bg-white/5'
                            }`}
                          >
                            <div className="flex items-center gap-2 min-w-0">
                              <CategoryLogo name="كل القنوات" isAll size="xs" />
                              <span className="truncate">كل القنوات</span>
                            </div>
                            <span className="font-mono tabular-nums text-[11px] opacity-80 shrink-0">
                              {channels.length}
                            </span>
                          </button>
                        )}
                      </div>

                      <div className="flex-1 min-h-0 overflow-y-auto overscroll-contain space-y-1 pl-1">
                        {categories.map((cat, idx) => {
                          const active = selectedM3uGroup === cat.name;
                          return (
                            <div
                              key={cat.name}
                              onClick={() => selectExactM3uGroup(cat.name)}
                              role="button"
                              tabIndex={0}
                              onKeyDown={(e) => {
                                if (e.key === 'Enter' || e.key === ' ') {
                                  e.preventDefault();
                                  selectExactM3uGroup(cat.name);
                                }
                              }}
                              className={`w-full px-2.5 py-2 rounded-xl flex items-center justify-between gap-2 text-xs font-bold transition-colors cursor-pointer text-right select-none ${
                                active
                                  ? 'bg-[#1268FB] text-white'
                                  : 'text-slate-300 hover:bg-white/5'
                              }`}
                            >
                              <div className="flex items-center gap-2 min-w-0 flex-1">
                                <CategoryLogo name={cat.name} logo={cat.logo} size="xs" />
                                <span className="truncate">{cat.name}</span>
                              </div>
                              <div className="flex items-center gap-1 shrink-0">
                                {isAdminUnlocked && (
                                  <>
                                    <button
                                      type="button"
                                      disabled={idx === 0 || reorderingCategory === cat.name}
                                      onClick={(e) => handleMoveCategoryInline(cat.name, 'up', e)}
                                      className="w-6 h-6 rounded-lg bg-black/25 hover:bg-black/50 disabled:opacity-25 flex items-center justify-center"
                                      title="للأعلى"
                                    >
                                      <ArrowUp className="w-3 h-3" />
                                    </button>
                                    <button
                                      type="button"
                                      disabled={
                                        idx === categories.length - 1 ||
                                        reorderingCategory === cat.name
                                      }
                                      onClick={(e) => handleMoveCategoryInline(cat.name, 'down', e)}
                                      className="w-6 h-6 rounded-lg bg-black/25 hover:bg-black/50 disabled:opacity-25 flex items-center justify-center"
                                      title="للأسفل"
                                    >
                                      <ArrowDown className="w-3 h-3" />
                                    </button>
                                  </>
                                )}
                                <span className="font-mono tabular-nums text-[11px] opacity-80 min-w-[24px] text-left">
                                  {cat.count}
                                </span>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  )}

                  {/* Selected Category Channels List — Independently Scrollable */}
                  <div
                    ref={channelsScrollRef}
                    className="h-full min-h-0 overflow-y-auto overscroll-contain sm:pl-1 pb-3"
                  >
                    {sectionChannels.length === 0 ? (
                      <div className="bg-[#0B1222] border border-[#1B2947] rounded-2xl p-10 text-center space-y-2.5">
                        <Tv className="w-9 h-9 text-slate-500 mx-auto" />
                        <p className="text-sm font-bold text-slate-200">
                          لا توجد قنوات مطابقة داخل هذا القسم
                        </p>
                      </div>
                    ) : (
                      <div className="space-y-4">
                        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 2xl:grid-cols-4 gap-2 sm:gap-2.5">
                          {sectionChannels.slice(0, visibleChannelCount).map((ch) => {
                            const isFav = favorites.includes(ch.id);
                            return (
                              <div
                                key={ch.id}
                                onClick={() => handlePlayChannel(ch)}
                                title={ch.name}
                                className="group min-h-[56px] rounded-xl p-2 sm:p-2.5 bg-[#0B1222] hover:bg-[#101C36] border border-[#1B2947] hover:border-blue-500/60 active:scale-[0.99] transition-all cursor-pointer flex items-center justify-between gap-2 select-none"
                              >
                                <div className="flex items-center gap-2.5 min-w-0 flex-1">
                                  <ChannelLogo
                                    name={ch.name}
                                    logo={ch.logo}
                                    group={ch.group}
                                    size="sm"
                                  />
                                  <div className="min-w-0 flex-1">
                                    <div className="text-xs sm:text-[13px] font-bold text-white line-clamp-2 leading-snug break-words">
                                      {ch.name}
                                    </div>
                                    <div className="text-[10.5px] text-slate-400 truncate mt-0.5">
                                      {ch.group}
                                    </div>
                                  </div>
                                </div>

                                <div className="flex items-center gap-0.5 shrink-0">
                                  <button
                                    type="button"
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      handleToggleFavorite(ch.id);
                                    }}
                                    className="min-h-[44px] min-w-[44px] rounded-xl hover:bg-white/10 text-slate-400 hover:text-amber-300 flex items-center justify-center"
                                    title="المفضلة"
                                  >
                                    <Star
                                      className={`w-4 h-4 ${
                                        isFav ? 'fill-amber-400 text-amber-400' : ''
                                      }`}
                                    />
                                  </button>

                                  {isAdminUnlocked && (
                                    <button
                                      type="button"
                                      onClick={(e) => {
                                        e.stopPropagation();
                                        setEditingChannel(ch);
                                      }}
                                      className="min-h-[44px] min-w-[44px] rounded-xl hover:bg-white/10 text-slate-300 hover:text-blue-400 flex items-center justify-center"
                                      title="تعديل القناة"
                                    >
                                      <Edit3 className="w-4 h-4" />
                                    </button>
                                  )}
                                </div>
                              </div>
                            );
                          })}
                        </div>

                        {sectionChannels.length > visibleChannelCount && (
                          <div className="flex justify-center pt-2">
                            <button
                              type="button"
                              onClick={() => setVisibleChannelCount((n) => n + 300)}
                              className="min-h-[44px] px-6 py-2.5 rounded-xl bg-[#0B1222] hover:bg-[#13203B] border border-[#1E2E4F] text-xs font-bold text-blue-400 cursor-pointer"
                            >
                              عرض المزيد من القنوات ({sectionChannels.length - visibleChannelCount} متبقية)
                            </button>
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            )
          ) : (
            /* =================================================================
               OTHER SECTIONS (MOVIES, SERIES, SPORTS, FAVORITES, SEARCH, CUSTOM LIST)
               100% LOCKED TOP HEADER + SEARCH + ACTIONS; ONLY CHANNELS GRID SCROLLS!
               ================================================================= */
            <div className="h-full min-h-0 flex flex-col gap-3 overflow-hidden" dir="rtl">
              <div className="shrink-0 bg-[#0B1222] border border-[#1E325C] rounded-2xl p-3 sm:p-4 flex flex-wrap items-center justify-between gap-2.5">
                <div className="flex items-center gap-2.5 min-w-0">
                  <button
                    type="button"
                    onClick={() => selectSidebarNav('home')}
                    className="min-h-[40px] px-3.5 rounded-xl bg-[#1268FB] hover:bg-[#2575FC] text-white text-xs font-extrabold flex items-center gap-1.5 cursor-pointer shrink-0 shadow-[0_4px_14px_rgba(18,104,251,0.35)] active:scale-95 transition-all"
                    title="العودة للرئيسية"
                  >
                    <ChevronRight className="w-4 h-4" />
                    <span>رجوع للرئيسية</span>
                  </button>
                  <div className="min-w-0">
                    <h1 className="text-sm sm:text-lg font-extrabold text-white truncate">
                      {getSectionHeading()}
                    </h1>
                    <p className="text-[11px] text-slate-400">
                      الإجمالي:{' '}
                      <span className="font-mono tabular-nums text-white font-bold">
                        {sectionChannels.length}
                      </span>{' '}
                      قناة
                    </p>
                  </div>
                </div>

                <div className="flex flex-wrap items-center gap-2 w-full sm:w-auto">
                  {!searchQuery.trim() && (
                    <div className="relative flex-1 sm:w-56">
                      <Search className="w-3.5 h-3.5 text-slate-400 absolute right-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                      <input
                        type="text"
                        value={inCategorySearch}
                        onChange={(e) => {
                          setInCategorySearch(e.target.value);
                          setVisibleChannelCount(300);
                          if (channelsScrollRef.current) channelsScrollRef.current.scrollTop = 0;
                        }}
                        placeholder="ابحث داخل هذه القائمة..."
                        className="w-full min-h-[42px] sm:min-h-[38px] pr-9 pl-9 py-1.5 rounded-xl bg-[#060B16] border border-[#1E2E4F] focus:border-blue-500 text-xs text-white placeholder-slate-400 focus:outline-none"
                      />
                      {inCategorySearch && (
                        <button
                          type="button"
                          onClick={() => setInCategorySearch('')}
                          className="absolute left-1.5 top-1/2 -translate-y-1/2 min-h-[36px] min-w-[36px] flex items-center justify-center text-slate-400 hover:text-white cursor-pointer"
                          aria-label="مسح البحث"
                        >
                          <X className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                  )}

                  {activeNav === 'custom_list' && selectedCustomListId && (
                    <button
                      type="button"
                      onClick={() => {
                        const target = customLists.find((l) => l.id === selectedCustomListId);
                        if (target) setCustomListModalTarget(target);
                      }}
                      className="min-h-[38px] px-3 py-1.5 rounded-xl bg-white/10 hover:bg-white/15 text-xs font-bold text-white flex items-center gap-1.5 cursor-pointer shrink-0"
                    >
                      <Edit3 className="w-3.5 h-3.5" />
                      <span>تعديل القائمة</span>
                    </button>
                  )}
                </div>
              </div>

              {/* Independently Scrollable Channels Grid */}
              <div
                ref={channelsScrollRef}
                className="flex-1 min-h-0 overflow-y-auto overscroll-contain sm:pl-1 pb-3"
              >
                {sectionChannels.length === 0 ? (
                  <div className="bg-[#0B1222] border border-[#1B2947] rounded-2xl p-10 text-center space-y-2.5">
                    <Tv className="w-9 h-9 text-slate-500 mx-auto" />
                    <p className="text-sm font-bold text-slate-200">
                      لا توجد قنوات ضمن هذا القسم حالياً
                    </p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 xl:grid-cols-4 2xl:grid-cols-5 gap-2 sm:gap-2.5">
                      {sectionChannels.slice(0, visibleChannelCount).map((ch) => {
                        const isFav = favorites.includes(ch.id);
                        return (
                          <div
                            key={ch.id}
                            onClick={() => handlePlayChannel(ch)}
                            title={ch.name}
                            className="group min-h-[56px] rounded-xl p-2 sm:p-2.5 bg-[#0B1222] hover:bg-[#101C36] border border-[#1B2947] hover:border-blue-500/60 active:scale-[0.99] transition-all cursor-pointer flex items-center justify-between gap-2 select-none"
                          >
                            <div className="flex items-center gap-2.5 min-w-0 flex-1">
                              <ChannelLogo
                                name={ch.name}
                                logo={ch.logo}
                                group={ch.group}
                                size="sm"
                              />
                              <div className="min-w-0 flex-1">
                                <div className="text-xs sm:text-[13px] font-bold text-white line-clamp-2 leading-snug break-words">
                                  {ch.name}
                                </div>
                                <div className="text-[10.5px] text-slate-400 truncate mt-0.5">
                                  {ch.group}
                                </div>
                              </div>
                            </div>

                            <div className="flex items-center gap-0.5 shrink-0">
                              <button
                                type="button"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleToggleFavorite(ch.id);
                                }}
                                className="min-h-[44px] min-w-[44px] rounded-xl hover:bg-white/10 text-slate-400 hover:text-amber-300 flex items-center justify-center"
                                title="المفضلة"
                              >
                                <Star
                                  className={`w-4 h-4 ${
                                    isFav ? 'fill-amber-400 text-amber-400' : ''
                                  }`}
                                />
                              </button>

                              {isAdminUnlocked && (
                                <button
                                  type="button"
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    setEditingChannel(ch);
                                  }}
                                  className="min-h-[44px] min-w-[44px] rounded-xl hover:bg-white/10 text-slate-300 hover:text-blue-400 flex items-center justify-center"
                                  title="تعديل القناة"
                                >
                                  <Edit3 className="w-4 h-4" />
                                </button>
                              )}
                            </div>
                          </div>
                        );
                      })}
                    </div>

                    {sectionChannels.length > visibleChannelCount && (
                      <div className="flex justify-center pt-2">
                        <button
                          type="button"
                          onClick={() => setVisibleChannelCount((n) => n + 300)}
                          className="min-h-[44px] px-6 py-2.5 rounded-xl bg-[#0B1222] hover:bg-[#13203B] border border-[#1E2E4F] text-xs font-bold text-blue-400 cursor-pointer"
                        >
                          عرض المزيد من القنوات ({sectionChannels.length - visibleChannelCount} متبقية)
                        </button>
                      </div>
                    )}
                  </div>
                )}
              </div>
            </div>
          )}
        </main>
      </div>

      {/* =====================================================================
          100% LOCKED MOBILE BOTTOM TAB BAR (shrink-0, Safe-Area Bottom Aware)
         ===================================================================== */}
      <nav
        className="lg:hidden shrink-0 z-30 pb-safe px-safe bg-[#080F1E]/95 backdrop-blur-md border-t border-[#182644]"
        dir="rtl"
      >
        <div className="h-[56px] grid grid-cols-5 items-stretch px-1">
          {(
            [
              { id: 'home', label: 'الرئيسية', icon: <Home className="w-5 h-5" /> },
              { id: 'live_tv', label: 'القنوات', icon: <Tv className="w-5 h-5" /> },
              { id: 'movies', label: 'الأفلام', icon: <Film className="w-5 h-5" /> },
              { id: 'favorites', label: 'المفضلة', icon: <Star className="w-5 h-5" /> },
            ] as const
          ).map((tab) => {
            const active =
              !mobileMoreSheetOpen &&
              !searchQuery &&
              (activeNav === tab.id || (tab.id === 'live_tv' && activeNav === 'm3u_group'));
            return (
              <button
                key={tab.id}
                type="button"
                onClick={() => selectSidebarNav(tab.id)}
                className={`relative min-h-[48px] flex flex-col items-center justify-center gap-0.5 transition-colors cursor-pointer active:scale-95 ${
                  active ? 'text-[#2982FF]' : 'text-slate-400'
                }`}
              >
                {active && (
                  <span
                    aria-hidden="true"
                    className="absolute top-0 inset-x-4 h-0.5 rounded-b-full bg-[#2982FF]"
                  />
                )}
                {tab.icon}
                <span className="text-[10px] font-bold leading-tight">{tab.label}</span>
              </button>
            );
          })}

          <button
            type="button"
            onClick={() => setMobileMoreSheetOpen((v) => !v)}
            className={`relative min-h-[48px] flex flex-col items-center justify-center gap-0.5 transition-colors cursor-pointer active:scale-95 ${
              mobileMoreSheetOpen ? 'text-[#2982FF]' : 'text-slate-400'
            }`}
          >
            {mobileMoreSheetOpen && (
              <span
                aria-hidden="true"
                className="absolute top-0 inset-x-4 h-0.5 rounded-b-full bg-[#2982FF]"
              />
            )}
            <LayoutGrid className="w-5 h-5" />
            <span className="text-[10px] font-bold leading-tight">الأقسام</span>
          </button>
        </div>
      </nav>

      {/* =====================================================================
          MOBILE BOTTOM SHEET FOR ALL SECTIONS & CUSTOM LISTS
         ===================================================================== */}
      {mobileMoreSheetOpen && (
        <div
          onClick={() => setMobileMoreSheetOpen(false)}
          className="lg:hidden fixed inset-0 z-40 bg-black/65 backdrop-blur-xs flex items-end"
          dir="rtl"
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="w-full max-h-[82dvh] bg-[#0B1222] rounded-t-3xl border-t border-[#1E325C] flex flex-col overflow-hidden shadow-2xl"
          >
            <div className="shrink-0 px-4 pt-3 pb-2.5 border-b border-[#1B2947]">
              <div className="w-10 h-1.5 bg-slate-600 rounded-full mx-auto mb-2" />
              <div className="flex items-center justify-between">
                <span className="text-sm font-extrabold text-white">تصفح الأقسام والقوائم</span>
                <button
                  type="button"
                  onClick={() => setMobileMoreSheetOpen(false)}
                  className="min-h-[44px] min-w-[44px] rounded-xl text-slate-400 flex items-center justify-center"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            <div className="flex-1 min-h-0 overflow-y-auto overscroll-contain p-4 sheet-pb-safe space-y-4">
              {/* Compact Mobile Subscription Summary Card */}
              <div className="rounded-2xl bg-[#060B16] border border-[#1B2947] p-3 flex items-center justify-between gap-3">
                <div className="min-w-0">
                  <div className="text-xs font-bold text-white truncate">{sessionLabel}</div>
                  <div className="text-[11px] text-emerald-400 mt-0.5">
                    متبقي {durationDays} يوم
                    {formattedExpiry ? ` · حتى ${formattedExpiry}` : ''}
                  </div>
                </div>
                <span className="text-[11px] font-bold text-slate-300 bg-white/5 px-2.5 py-1 rounded-lg font-mono tabular-nums shrink-0">
                  {isAdminUnlocked
                    ? 'مدير'
                    : maxDevices <= 1
                      ? '1/1 جهاز'
                      : `${connectedDevicesCount}/${maxDevices} أجهزة`}
                </span>
              </div>

              <div className="grid grid-cols-2 gap-2">
                {sidebarItems.map((item) => (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => selectSidebarNav(item.id)}
                    className={`min-h-[48px] px-3.5 py-2.5 rounded-2xl flex items-center gap-2.5 text-xs font-bold active:scale-[0.98] transition-transform ${
                      activeNav === item.id
                        ? 'bg-blue-600 text-white'
                        : 'bg-[#060B16] border border-[#1B2947] text-slate-200'
                    }`}
                  >
                    {item.icon}
                    <span className="truncate">{item.label}</span>
                  </button>
                ))}
              </div>

              {/* Custom Lists inside Mobile Sheet */}
              <div className="space-y-2 pt-2 border-t border-[#1B2947]">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-300">القوائم الخاصة</span>
                  <button
                    type="button"
                    onClick={() => {
                      setMobileMoreSheetOpen(false);
                      setCustomListModalTarget('NEW');
                    }}
                    className="min-h-[40px] px-2 text-xs font-bold text-blue-400 flex items-center gap-1"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>إنشاء قائمة</span>
                  </button>
                </div>

                <div className="grid grid-cols-1 gap-2">
                  {customLists.map((lst) => (
                    <button
                      key={lst.id}
                      type="button"
                      onClick={() => {
                        setSelectedCustomListId(lst.id);
                        setActiveNav('custom_list');
                        setInCategorySearch('');
                        setMobileMoreSheetOpen(false);
                        resetActiveScrollTop();
                      }}
                      className="min-h-[46px] px-3.5 py-2 rounded-xl bg-[#060B16] border border-[#1B2947] flex items-center justify-between text-xs font-semibold text-white"
                    >
                      <div className="flex items-center gap-2 truncate">
                        <ListVideo className="w-4 h-4 shrink-0 text-blue-400" />
                        <span className="truncate">{lst.name}</span>
                      </div>
                      <span className="font-mono tabular-nums text-slate-400">
                        {lst.channelIds.length}
                      </span>
                    </button>
                  ))}
                </div>
              </div>

              {canInstall && (
                <button
                  type="button"
                  onClick={handleMobileInstallClick}
                  className="w-full min-h-[46px] px-4 py-2.5 rounded-2xl bg-cyan-600/20 border border-cyan-500/40 text-cyan-200 text-xs font-bold flex items-center justify-center gap-2 active:scale-[0.98] transition-transform"
                >
                  <Download className="w-4 h-4 text-cyan-400" />
                  <span>تثبيت التطبيق على الشاشة الرئيسية</span>
                </button>
              )}

              {isAdminUnlocked && (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      setMobileMoreSheetOpen(false);
                      openAdminModalOnTab('m3u');
                    }}
                    className="w-full min-h-[46px] px-4 py-2.5 rounded-2xl bg-purple-600 text-white text-xs font-bold flex items-center justify-center gap-2"
                  >
                    <Crown className="w-4 h-4" />
                    <span>لوحة إدارة المصادر</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setMobileMoreSheetOpen(false);
                      openAdminModalOnTab('protection');
                    }}
                    className="w-full min-h-[46px] px-4 py-2.5 rounded-2xl bg-emerald-600 text-white text-xs font-bold flex items-center justify-center gap-2"
                  >
                    <Shield className="w-4 h-4" />
                    <span>الحماية والـ VPN</span>
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* iOS Safari Add-to-Home-Screen Guided Sheet */}
      {showIosInstallGuide && (
        <div
          onClick={() => setShowIosInstallGuide(false)}
          className="fixed inset-0 z-[85] bg-black/75 backdrop-blur-xs flex items-end sm:items-center justify-center p-0 sm:p-4"
          dir="rtl"
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="w-full sm:max-w-sm bg-[#0B1222] border-t sm:border border-[#1E325C] rounded-t-3xl sm:rounded-2xl p-5 sheet-pb-safe sm:pb-5 space-y-4 shadow-2xl"
          >
            <div className="w-10 h-1.5 bg-slate-600 rounded-full mx-auto sm:hidden" />
            <div className="flex items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <Smartphone className="w-5 h-5 text-cyan-400" />
                <h3 className="text-sm font-extrabold text-white">تثبيت MS TV على آيفون / آيباد</h3>
              </div>
              <button
                type="button"
                onClick={() => setShowIosInstallGuide(false)}
                className="min-h-[40px] min-w-[40px] rounded-xl text-slate-400 hover:text-white flex items-center justify-center"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="p-3.5 rounded-2xl bg-[#060B16] border border-[#1B2947] text-xs text-slate-200 space-y-2 leading-relaxed">
              <div>
                1. اضغط على زر <strong className="text-white">المشاركة (Share)</strong> أسفل متصفح Safari.
              </div>
              <div>
                2. مرّر للأسفل واختر <strong className="text-cyan-300">إضافة إلى الشاشة الرئيسية (Add to Home Screen)</strong>.
              </div>
              <div>
                3. اضغط <strong className="text-white">إضافة</strong> ليفتح التطبيق بملء الشاشة كتطبيق مستقل.
              </div>
            </div>
            <button
              type="button"
              onClick={() => setShowIosInstallGuide(false)}
              className="w-full min-h-[44px] rounded-xl bg-[#1268FB] hover:bg-[#1D74FF] text-white text-xs font-extrabold cursor-pointer"
            >
              حسناً، فهمت
            </button>
          </div>
        </div>
      )}

      {/* =====================================================================
          CLEAN AUTO-HIDING FAST PLAYER WITH ENCRYPTED STREAM TICKETS
         ===================================================================== */}
      <FastPlayer
        channel={playingChannel}
        isOpen={isPlayerOpen}
        streamSessionToken={streamSessionToken}
        allChannels={channels}
        categories={categories}
        favorites={favorites}
        isAdminUnlocked={isAdminUnlocked}
        onClose={() => setIsPlayerOpen(false)}
        onSelectChannel={handlePlayChannel}
        onToggleFavorite={handleToggleFavorite}
        onEditChannel={(ch) => setEditingChannel(ch)}
        onSecurityBlock={handleSecurityBlock}
        onMaintenanceMode={handleMaintenanceActivated}
      />

      {/* =====================================================================
          SECURITY SHIELD OVERLAY (Anti-HttpCanary / Anti-VPN / Anti-DevTools)
         ===================================================================== */}
      {securityBlock && !isAdminUnlocked && (
        <SecurityShieldOverlay
          block={securityBlock}
          onCleared={async (pol) => {
            setSecurityPolicy(pol);
            setSecurityBlock(null);
            await loadCatalog().catch(() => {});
          }}
          onOpenAdminGate={() => setShowAdminGate(true)}
        />
      )}

      {/* =====================================================================
          MODALS (Ordered by stacking priority: AdminPanel -> CustomList -> AdminGate -> ChannelEdit)
         ===================================================================== */}
      {showAdminPanel && isAdminUnlocked && (
        <AdminPanelModal
          initialTab={adminInitialTab}
          channels={channels}
          categories={categories}
          onClose={() => setShowAdminPanel(false)}
          onLockAdmin={() => {
            setAdminToken(null);
            setIsAdminUnlocked(false);
            showToast('تم الخروج من وضع المدير وإخفاء كافة أدوات الإدارة.');
          }}
          onCatalogChanged={handleCatalogChanged}
          onOpenChannelEdit={(ch) => setEditingChannel(ch)}
        />
      )}

      {customListModalTarget && (
        <CustomListModal
          existingList={customListModalTarget === 'NEW' ? null : customListModalTarget}
          channels={channels}
          categories={categories}
          isAdminUnlocked={isAdminUnlocked}
          onClose={() => setCustomListModalTarget(null)}
          onSave={handleSaveCustomList}
          onDelete={handleDeleteCustomList}
        />
      )}

      {showAdminGate && (
        <AdminCodeModal
          onClose={() => setShowAdminGate(false)}
          onUnlock={handleAdminUnlock}
        />
      )}

      {editingChannel && (
        <ChannelEditModal
          channel={editingChannel}
          categories={categories}
          onClose={() => setEditingChannel(null)}
          onSave={handleSaveChannelEdit}
          onDelete={handleDeleteChannel}
        />
      )}
    </div>
  );
}
