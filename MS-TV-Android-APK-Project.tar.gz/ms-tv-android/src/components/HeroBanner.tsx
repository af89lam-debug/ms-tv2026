import React, { useState, useEffect, useMemo, useRef } from 'react';
import {
  Play,
  Image as ImageIcon,
  ChevronLeft,
  ChevronRight,
  ExternalLink,
  Layers,
  Sparkles,
} from 'lucide-react';
import type { Channel, HeroActionType, HeroSlide, HeroThemePreset } from '../types';

export function normalizeSlideExternalUrl(raw?: string): string {
  const cleaned = String(raw || '')
    .replace(/[\u200B-\u200F\u202A-\u202E\u2060-\u206F\uFEFF\u00A0]/g, '')
    .trim();
  if (!cleaned) return '';
  if (/^(javascript|vbscript|data):/i.test(cleaned)) return '';
  if (cleaned.startsWith('@') && cleaned.length > 1) {
    return `https://t.me/${cleaned.slice(1).replace(/^\/+/, '')}`;
  }
  if (/^(t\.me|telegram\.me|wa\.me)\//i.test(cleaned)) {
    return `https://${cleaned}`;
  }
  if (/^(https?:\/\/|tg:\/\/)/i.test(cleaned)) {
    return cleaned;
  }
  if (/^[a-z0-9.-]+\.[a-z]{2,}(\/.*)?$/i.test(cleaned)) {
    return `https://${cleaned}`;
  }
  return cleaned;
}

export function detectIsTelegramSlide(slide: {
  themePreset?: HeroThemePreset;
  externalUrl?: string;
  title?: string;
  badge?: string;
  buttonText?: string;
}): boolean {
  if (slide.themePreset === 'telegram') return true;
  if (/t\.me|telegram|^@|^tg:\/\//i.test(slide.externalUrl || '')) return true;
  const combined = `${slide.title || ''} ${slide.badge || ''} ${slide.buttonText || ''}`;
  return /تليجرام|تلغرام|تيليجرام|تيلغرام|telegram/i.test(combined);
}

export const TelegramPaperPlaneIcon: React.FC<{ className?: string }> = ({
  className = 'w-4 h-4',
}) => (
  <svg
    viewBox="0 0 24 24"
    fill="currentColor"
    className={className}
    aria-hidden="true"
  >
    <path d="M21.94 3.66a1.25 1.25 0 0 0-1.35-.24L2.68 10.67a1.18 1.18 0 0 0 .06 2.21l4.57 1.48 1.77 5.44a1.05 1.05 0 0 0 1.78.38l2.57-2.66 4.77 3.52a1.24 1.24 0 0 0 1.94-.74l2.12-15.46a1.25 1.25 0 0 0-.32-1.18ZM9.14 14.32l8.93-7.61-6.98 8.76-.47 3.24-1.48-4.39Z" />
  </svg>
);

export const HeroPresetBackdrop: React.FC<{ preset: HeroThemePreset }> = ({ preset }) => {
  if (preset === 'telegram') {
    return (
      <svg
        viewBox="0 0 1000 360"
        preserveAspectRatio="xMidYMid slice"
        className="absolute inset-0 w-full h-full pointer-events-none"
        xmlns="http://www.w3.org/2000/svg"
      >
        <defs>
          <linearGradient id="tgBgGrad" x1="1" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#040C1E" />
            <stop offset="48%" stopColor="#07284A" />
            <stop offset="85%" stopColor="#0369A1" />
            <stop offset="100%" stopColor="#229ED9" />
          </linearGradient>
          <radialGradient id="tgCyanOrb" cx="22%" cy="48%" r="48%">
            <stop offset="0%" stopColor="#38BDF8" stopOpacity="0.45" />
            <stop offset="55%" stopColor="#0284C7" stopOpacity="0.16" />
            <stop offset="100%" stopColor="#040C1E" stopOpacity="0" />
          </radialGradient>
          <linearGradient id="tgCircleGrad" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="#38BDF8" />
            <stop offset="100%" stopColor="#0088CC" />
          </linearGradient>
        </defs>

        <rect width="1000" height="360" fill="url(#tgBgGrad)" />
        <rect width="1000" height="360" fill="url(#tgCyanOrb)" />

        <polygon points="0,0 320,0 200,360 0,360" fill="#38BDF8" fillOpacity="0.09" />
        <polygon points="180,0 470,0 330,360 70,360" fill="#0EA5E9" fillOpacity="0.08" />

        {/* Stylized Telegram Emblem positioned on the left (clear of RTL Arabic text on right) */}
        <g transform="translate(115, 58)">
          <circle cx="122" cy="122" r="118" fill="#38BDF8" fillOpacity="0.1" />
          <circle cx="122" cy="122" r="94" fill="#38BDF8" fillOpacity="0.16" />
          <circle cx="122" cy="122" r="72" fill="url(#tgCircleGrad)" />
          <path
            d="M156 88L82 117.5C77.2 119.4 77.3 122.2 81.2 123.4L100.2 129.3L144.1 101.6C146.2 100.3 148.1 101 146.5 102.4L110.9 134.5L109.6 153.8C111.5 153.8 112.4 152.9 113.5 151.8L122.9 142.7L142.4 157.1C146 159.1 148.6 158.1 149.5 153.8L162.2 94C163.5 88.8 160.2 86.4 156 88Z"
            fill="#FFFFFF"
          />
        </g>
      </svg>
    );
  }

  if (preset === 'promo') {
    return (
      <svg
        viewBox="0 0 1000 360"
        preserveAspectRatio="xMidYMid slice"
        className="absolute inset-0 w-full h-full pointer-events-none"
        xmlns="http://www.w3.org/2000/svg"
      >
        <defs>
          <linearGradient id="promoBg" x1="1" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#070B19" />
            <stop offset="50%" stopColor="#1E1B4B" />
            <stop offset="100%" stopColor="#78350F" />
          </linearGradient>
          <radialGradient id="promoGoldGlow" cx="22%" cy="50%" r="45%">
            <stop offset="0%" stopColor="#F59E0B" stopOpacity="0.38" />
            <stop offset="65%" stopColor="#B45309" stopOpacity="0.12" />
            <stop offset="100%" stopColor="#070B19" stopOpacity="0" />
          </radialGradient>
        </defs>
        <rect width="1000" height="360" fill="url(#promoBg)" />
        <rect width="1000" height="360" fill="url(#promoGoldGlow)" />
        <polygon points="0,0 340,0 210,360 0,360" fill="#F59E0B" fillOpacity="0.1" />
        <circle cx="210" cy="180" r="96" fill="#FBBF24" fillOpacity="0.12" />
        <circle cx="210" cy="180" r="64" fill="#F59E0B" fillOpacity="0.2" />
      </svg>
    );
  }

  return (
    <svg
      viewBox="0 0 1000 360"
      preserveAspectRatio="xMidYMid slice"
      className="absolute inset-0 w-full h-full pointer-events-none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <defs>
        <linearGradient id="heroSky" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="#040917" />
          <stop offset="48%" stopColor="#0A1D47" />
          <stop offset="82%" stopColor="#14388C" />
          <stop offset="100%" stopColor="#3B0764" />
        </linearGradient>
        <radialGradient id="stadiumGlowLeft" cx="28%" cy="25%" r="55%">
          <stop offset="0%" stopColor="#38BDF8" stopOpacity="0.42" />
          <stop offset="55%" stopColor="#1D4ED8" stopOpacity="0.18" />
          <stop offset="100%" stopColor="#040917" stopOpacity="0" />
        </radialGradient>
        <radialGradient id="purpleFlare" cx="15%" cy="85%" r="45%">
          <stop offset="0%" stopColor="#A855F7" stopOpacity="0.45" />
          <stop offset="100%" stopColor="#A855F7" stopOpacity="0" />
        </radialGradient>
        <linearGradient id="silverCup" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="#F8FAFC" />
          <stop offset="35%" stopColor="#CBD5E1" />
          <stop offset="70%" stopColor="#64748B" />
          <stop offset="100%" stopColor="#E2E8F0" />
        </linearGradient>
      </defs>

      <rect width="1000" height="360" fill="url(#heroSky)" />
      <rect width="1000" height="360" fill="url(#stadiumGlowLeft)" />
      <rect width="1000" height="360" fill="url(#purpleFlare)" />

      <polygon points="80,0 260,0 160,360 0,360" fill="#2563EB" fillOpacity="0.18" />
      <polygon points="240,0 440,0 320,360 130,360" fill="#38BDF8" fillOpacity="0.12" />

      <g transform="translate(120, 48)">
        <path
          d="M45,65 C2,45 -5,135 52,165"
          stroke="url(#silverCup)"
          strokeWidth="12"
          strokeLinecap="round"
          fill="none"
        />
        <path
          d="M175,65 C218,45 225,135 168,165"
          stroke="url(#silverCup)"
          strokeWidth="12"
          strokeLinecap="round"
          fill="none"
        />
        <ellipse cx="110" cy="48" rx="66" ry="16" fill="#E2E8F0" />
        <ellipse cx="110" cy="48" rx="56" ry="11" fill="#334155" />
        <path
          d="M44,48 C48,155 74,205 110,222 C146,205 172,155 176,48 Z"
          fill="url(#silverCup)"
        />
        <path
          d="M72,62 C75,140 88,182 104,205"
          stroke="#FFFFFF"
          strokeOpacity="0.55"
          strokeWidth="7"
          strokeLinecap="round"
          fill="none"
        />
        <rect x="82" y="220" width="56" height="24" rx="6" fill="#94A3B8" />
        <rect x="64" y="242" width="92" height="18" rx="8" fill="#CBD5E1" />
      </g>
    </svg>
  );
};

interface HeroBannerProps {
  heroSlides: HeroSlide[];
  channels: Channel[];
  featuredChannels: Channel[];
  isAdminUnlocked?: boolean;
  onWatchChannel: (channel: Channel) => void;
  onOpenCategory?: (categoryName: string) => void;
  onManageSlides?: () => void;
}

interface ResolvedSlide {
  id: string;
  title: string;
  subtitle: string;
  badge: string;
  imageUrl: string;
  actionType: HeroActionType;
  buttonText: string;
  externalUrl: string;
  targetCategory: string;
  showLiveBadge: boolean;
  themePreset: HeroThemePreset;
  isTelegram: boolean;
  channel: Channel | null;
}

export const HeroBanner: React.FC<HeroBannerProps> = ({
  heroSlides,
  channels,
  featuredChannels,
  isAdminUnlocked = false,
  onWatchChannel,
  onOpenCategory,
  onManageSlides,
}) => {
  const [activeSlide, setActiveSlide] = useState(0);
  const touchStartRef = useRef<{ x: number; y: number } | null>(null);

  const slides: ResolvedSlide[] = useMemo(() => {
    const channelMap = new Map<string, Channel>(channels.map((c) => [c.id, c]));
    const fallbackChannel =
      featuredChannels.find(
        (c) =>
          c.group.includes('رياض') ||
          c.group.toLowerCase().includes('sport') ||
          c.name.toLowerCase().includes('sport') ||
          c.name.toLowerCase().includes('bein')
      ) ||
      featuredChannels[0] ||
      channels[0] ||
      null;

    if (heroSlides && heroSlides.length > 0) {
      return heroSlides.map((s) => {
        const normalizedExt = normalizeSlideExternalUrl(s.externalUrl);
        const actionType: HeroActionType =
          s.actionType || (normalizedExt ? 'external_url' : 'watch_channel');
        const isTelegram = detectIsTelegramSlide({
          themePreset: s.themePreset,
          externalUrl: normalizedExt,
          title: s.title,
          badge: s.badge,
          buttonText: s.buttonText,
        });
        const themePreset: HeroThemePreset =
          s.themePreset || (isTelegram ? 'telegram' : 'default');
        const showLiveBadge =
          typeof s.showLiveBadge === 'boolean'
            ? s.showLiveBadge
            : actionType === 'watch_channel' && !isTelegram;

        let defaultBtnText = 'مشاهدة الآن';
        if (actionType === 'external_url') {
          defaultBtnText = isTelegram ? 'اشترك الآن' : 'فتح الرابط';
        } else if (actionType === 'category') {
          defaultBtnText = 'تصفح القسم';
        }

        return {
          id: s.id,
          title: s.title || '',
          subtitle: s.subtitle || '',
          badge: s.badge ?? '',
          imageUrl: s.imageUrl || '',
          actionType,
          buttonText: (s.buttonText || '').trim() || defaultBtnText,
          externalUrl: normalizedExt,
          targetCategory: s.targetCategory || '__ALL__',
          showLiveBadge,
          themePreset,
          isTelegram,
          channel: (s.channelId ? channelMap.get(s.channelId) : null) || fallbackChannel,
        };
      });
    }

    return [
      {
        id: 'fallback_1',
        title: 'دوري أبطال أوروبا',
        subtitle: 'مباريات نارية وأقوى الفرق الأوروبية بجودة فائقة وبدون تقطيع',
        badge: fallbackChannel ? fallbackChannel.name : 'بث حي مباشر',
        imageUrl: '',
        actionType: 'watch_channel' as const,
        buttonText: 'مشاهدة الآن',
        externalUrl: '',
        targetCategory: '__ALL__',
        showLiveBadge: true,
        themePreset: 'default' as const,
        isTelegram: false,
        channel: fallbackChannel,
      },
      ...featuredChannels.slice(0, 3).map((ch) => ({
        id: `feat_${ch.id}`,
        title: ch.name,
        subtitle: `شاهد الآن ضمن قسم ${ch.group} بجودة عالية`,
        badge: ch.group,
        imageUrl: '',
        actionType: 'watch_channel' as const,
        buttonText: 'مشاهدة الآن',
        externalUrl: '',
        targetCategory: ch.group,
        showLiveBadge: true,
        themePreset: 'default' as const,
        isTelegram: false,
        channel: ch,
      })),
    ].slice(0, 5);
  }, [heroSlides, channels, featuredChannels]);

  useEffect(() => {
    if (activeSlide >= slides.length) {
      setActiveSlide(0);
    }
  }, [slides.length, activeSlide]);

  useEffect(() => {
    if (slides.length <= 1) return;
    const timer = setInterval(() => {
      setActiveSlide((prev) => (prev + 1) % slides.length);
    }, 6500);
    return () => clearInterval(timer);
  }, [slides.length]);

  const current = slides[activeSlide] || slides[0];
  if (!current) return null;

  const isPureImageSlide =
    Boolean(current.imageUrl) &&
    !current.title &&
    !current.subtitle &&
    !current.badge &&
    !current.showLiveBadge &&
    current.actionType === 'none';

  const handleTouchStart = (e: React.TouchEvent) => {
    const t = e.touches[0];
    if (!t) return;
    touchStartRef.current = { x: t.clientX, y: t.clientY };
  };

  const handleTouchEnd = (e: React.TouchEvent) => {
    if (!touchStartRef.current || slides.length <= 1) return;
    const t = e.changedTouches[0];
    const start = touchStartRef.current;
    touchStartRef.current = null;
    if (!t) return;

    const dx = t.clientX - start.x;
    const dy = t.clientY - start.y;
    if (Math.abs(dx) < 42 || Math.abs(dy) > Math.abs(dx)) return;

    if (dx > 0) {
      setActiveSlide((prev) => (prev + 1) % slides.length);
    } else {
      setActiveSlide((prev) => (prev - 1 + slides.length) % slides.length);
    }
  };

  return (
    <section
      onContextMenu={(e) => e.preventDefault()}
      onTouchStart={handleTouchStart}
      onTouchEnd={handleTouchEnd}
      className="relative rounded-2xl overflow-hidden border border-[#1E325C] bg-[#08132B] min-h-[142px] sm:min-h-[186px] lg:min-h-[216px] flex items-stretch select-none"
    >
      {/* Custom Admin Slide Image OR Theme Preset Backdrop */}
      {current.imageUrl ? (
        <img
          src={current.imageUrl}
          alt={current.title || 'صورة العرض'}
          referrerPolicy="no-referrer"
          draggable={false}
          className="absolute inset-0 w-full h-full object-cover object-center transition-all duration-500"
        />
      ) : (
        <HeroPresetBackdrop preset={current.themePreset} />
      )}

      {/* Adaptive Readability Scrim (lighter when pure image banner, crisp RTL contrast when text/CTA exists) */}
      {isPureImageSlide ? (
        <div className="absolute inset-0 bg-gradient-to-t from-[#040814]/45 via-transparent to-transparent pointer-events-none" />
      ) : (
        <>
          <div className="absolute inset-0 bg-gradient-to-l from-[#040814]/92 via-[#071126]/72 to-[#040814]/25 pointer-events-none" />
          <div className="absolute inset-0 bg-gradient-to-t from-[#040814]/85 via-transparent to-[#040814]/30 pointer-events-none" />
        </>
      )}

      <div className="relative z-10 flex-1 flex flex-col justify-between p-3 sm:p-4 lg:p-5" dir="rtl">
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-1.5 sm:gap-2 min-w-0">
            {current.showLiveBadge ? (
              <span className="inline-flex items-center gap-1.5 bg-[#EF233C] text-white text-[10px] sm:text-xs font-display font-bold px-2.5 py-0.5 sm:px-3 sm:py-1 rounded-md tracking-wider shadow-lg shrink-0">
                <span>▶</span>
                <span>LIVE</span>
              </span>
            ) : current.isTelegram ? (
              <span className="inline-flex items-center gap-1.5 bg-[#229ED9] text-white text-[10px] sm:text-xs font-display font-bold px-2.5 py-0.5 sm:px-3 sm:py-1 rounded-md tracking-wider shadow-lg shrink-0">
                <TelegramPaperPlaneIcon className="w-3.5 h-3.5" />
                <span>TELEGRAM</span>
              </span>
            ) : current.themePreset === 'promo' ? (
              <span className="inline-flex items-center gap-1 bg-amber-500 text-slate-950 text-[10px] sm:text-xs font-display font-extrabold px-2.5 py-0.5 sm:px-3 sm:py-1 rounded-md tracking-wider shadow-lg shrink-0">
                <Sparkles className="w-3.5 h-3.5" />
                <span>VIP</span>
              </span>
            ) : null}

            {current.badge && (
              <span className="text-[11px] sm:text-xs text-blue-100/95 font-bold truncate max-w-[180px] sm:max-w-[240px] px-2 sm:px-2.5 py-0.5 rounded-md bg-black/35 border border-white/10 backdrop-blur-xs">
                {current.badge}
              </span>
            )}
          </div>

          {/* Admin-only quick button to manage Hero Gallery slides (100% hidden for users) */}
          {isAdminUnlocked && onManageSlides && (
            <button
              type="button"
              onClick={onManageSlides}
              className="min-h-[36px] px-2.5 sm:px-3 py-1 rounded-xl bg-black/60 hover:bg-purple-600/80 backdrop-blur-md border border-purple-400/40 text-purple-200 hover:text-white text-[11px] sm:text-xs font-bold flex items-center gap-1.5 cursor-pointer transition-colors shrink-0"
            >
              <ImageIcon className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">إدارة صور المعرض</span>
              <span className="sm:hidden">المعرض</span>
            </button>
          )}
        </div>

        <div className="my-1.5 sm:my-2.5 max-w-xl">
          {current.title && (
            <h1 className="text-base sm:text-xl lg:text-2xl font-extrabold text-white leading-tight line-clamp-2 drop-shadow-md text-balance">
              {current.title}
            </h1>
          )}
          {current.subtitle && (
            <p className="text-[11px] sm:text-xs lg:text-sm text-slate-200 mt-1 font-medium line-clamp-2">
              {current.subtitle}
            </p>
          )}
        </div>

        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            {/* Dynamic CTA Button based on Admin's chosen actionType */}
            {current.actionType === 'external_url' && current.externalUrl ? (
              <a
                href={current.externalUrl}
                target="_blank"
                rel="noopener noreferrer"
                className={`min-h-[38px] sm:min-h-[40px] px-3.5 sm:px-5 py-1.5 rounded-full text-white font-bold text-xs inline-flex items-center gap-1.5 active:scale-95 transition-transform cursor-pointer whitespace-nowrap ${
                  current.isTelegram
                    ? 'bg-gradient-to-r from-[#229ED9] to-[#0088CC] hover:from-[#2AABEE] hover:to-[#0296DE] shadow-[0_6px_22px_rgba(34,158,217,0.45)]'
                    : 'bg-gradient-to-r from-[#0D63F3] to-[#2575FC] hover:from-[#1B70FF] hover:to-[#3B82F6] shadow-[0_6px_22px_rgba(13,99,243,0.45)]'
                }`}
              >
                {current.isTelegram ? (
                  <TelegramPaperPlaneIcon className="w-3.5 h-3.5" />
                ) : (
                  <ExternalLink className="w-3.5 h-3.5" />
                )}
                <span>{current.buttonText}</span>
              </a>
            ) : current.actionType === 'category' ? (
              <button
                type="button"
                onClick={() => onOpenCategory?.(current.targetCategory || '__ALL__')}
                className="min-h-[38px] sm:min-h-[40px] px-3.5 sm:px-5 py-1.5 rounded-full bg-gradient-to-r from-[#0D63F3] to-[#2575FC] hover:from-[#1B70FF] hover:to-[#3B82F6] text-white font-bold text-xs inline-flex items-center gap-1.5 shadow-[0_6px_22px_rgba(13,99,243,0.45)] active:scale-95 transition-transform cursor-pointer whitespace-nowrap"
              >
                <Layers className="w-3.5 h-3.5" />
                <span>{current.buttonText}</span>
              </button>
            ) : current.actionType === 'watch_channel' ? (
              <button
                type="button"
                onClick={() => {
                  if (current.channel) onWatchChannel(current.channel);
                }}
                disabled={!current.channel}
                className="min-h-[38px] sm:min-h-[40px] px-3.5 sm:px-5 py-1.5 rounded-full bg-gradient-to-r from-[#0D63F3] to-[#2575FC] hover:from-[#1B70FF] hover:to-[#3B82F6] disabled:opacity-50 text-white font-bold text-xs inline-flex items-center gap-1.5 shadow-[0_6px_22px_rgba(13,99,243,0.45)] active:scale-95 transition-transform cursor-pointer whitespace-nowrap"
              >
                <Play className="w-3.5 h-3.5 fill-white" />
                <span>{current.buttonText}</span>
              </button>
            ) : null}

            {slides.length > 1 && (
              <div className="hidden sm:flex items-center gap-1.5">
                <button
                  type="button"
                  onClick={() =>
                    setActiveSlide((prev) => (prev - 1 + slides.length) % slides.length)
                  }
                  className="w-9 h-9 rounded-full bg-black/45 hover:bg-black/70 border border-white/15 text-white flex items-center justify-center cursor-pointer"
                  aria-label="الشريحة السابقة"
                >
                  <ChevronRight className="w-4 h-4" />
                </button>
                <button
                  type="button"
                  onClick={() => setActiveSlide((prev) => (prev + 1) % slides.length)}
                  className="w-9 h-9 rounded-full bg-black/45 hover:bg-black/70 border border-white/15 text-white flex items-center justify-center cursor-pointer"
                  aria-label="الشريحة التالية"
                >
                  <ChevronLeft className="w-4 h-4" />
                </button>
              </div>
            )}
          </div>

          <div className="flex items-center gap-1 sm:gap-1.5" dir="ltr">
            {slides.map((s, idx) => (
              <button
                key={s.id}
                type="button"
                aria-label={`شريحة ${idx + 1}`}
                onClick={() => setActiveSlide(idx)}
                className="py-2 px-0.5 flex items-center justify-center cursor-pointer"
              >
                <span
                  className={`block h-2.5 rounded-full transition-all ${
                    idx === activeSlide
                      ? s.isTelegram
                        ? 'w-5 sm:w-6 bg-[#229ED9]'
                        : 'w-5 sm:w-6 bg-[#1D74FF]'
                      : 'w-2.5 bg-white/35 hover:bg-white/60'
                  }`}
                />
              </button>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};
