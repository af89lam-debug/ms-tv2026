import React, { useState } from 'react';
import { Lock, X, ShieldAlert } from 'lucide-react';

interface AdminCodeModalProps {
  onClose: () => void;
  onUnlock: (adminCode: string) => Promise<void>;
}

export const AdminCodeModal: React.FC<AdminCodeModalProps> = ({ onClose, onUnlock }) => {
  const [adminCode, setAdminCode] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!adminCode.trim()) {
      setError('يرجى إدخال الكود السري الخاص بالمدير.');
      return;
    }
    setLoading(true);
    setError(null);
    try {
      await onUnlock(adminCode.trim());
    } catch (err: any) {
      setError(err?.message || 'كود المدير غير صحيح.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div
      onClick={onClose}
      className="fixed inset-0 z-[75] bg-black/80 backdrop-blur-xs flex items-end sm:items-center justify-center p-0 sm:p-4"
      dir="rtl"
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="bg-[#0B1222] border-t sm:border border-purple-500/35 rounded-t-3xl sm:rounded-2xl w-full sm:max-w-md max-h-[92dvh] overflow-y-auto overscroll-contain sheet-pb-safe sm:pb-0 shadow-2xl"
      >
        <div className="w-10 h-1.5 bg-slate-600 rounded-full mx-auto mt-3 sm:hidden" />

        <div className="flex items-center justify-between px-5 py-3.5 sm:py-4 border-b border-[#1B2947]">
          <div className="flex items-center gap-2 min-w-0">
            <Lock className="w-4 h-4 text-purple-400 shrink-0" />
            <h3 className="text-sm sm:text-base font-bold text-white truncate">
              لوحة إدارة المصادر المحمية
            </h3>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="min-h-[44px] min-w-[44px] rounded-xl text-slate-400 hover:text-white hover:bg-white/10 flex items-center justify-center cursor-pointer shrink-0"
            aria-label="إغلاق"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-5 sm:p-6 space-y-4">
          <div className="flex items-start gap-3 p-3.5 rounded-xl bg-purple-500/10 border border-purple-500/25 text-xs text-slate-300">
            <ShieldAlert className="w-5 h-5 text-purple-400 shrink-0 mt-0.5" />
            <p className="leading-relaxed">
              روابط <strong className="text-white">M3U</strong> وبيانات <strong className="text-white">Xtream</strong> مخفية بالكامل عن جميع المستخدمين ولا يمكن عرضها أو تعديلها إلا عبر كود المدير السري.
            </p>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-2">
              كود دخول لوحة الإدارة الخاص بك
            </label>
            <input
              type="password"
              autoFocus
              value={adminCode}
              onChange={(e) => setAdminCode(e.target.value)}
              placeholder="أدخل كود المدير السري..."
              className="w-full min-h-[48px] px-4 py-3 rounded-xl bg-[#060B16] border border-[#1E2E4F] text-center font-mono text-base tracking-[0.25em] placeholder:tracking-normal placeholder:font-sans text-white focus:outline-none focus:border-purple-500"
            />
          </div>

          {error && (
            <div className="p-3 rounded-xl bg-red-500/10 border border-red-500/30 text-xs text-red-300 text-center">
              {error}
            </div>
          )}

          <div className="flex items-center justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="min-h-[44px] px-4 py-2.5 rounded-xl bg-white/5 hover:bg-white/10 text-slate-300 text-xs font-semibold cursor-pointer"
            >
              إلغاء
            </button>
            <button
              type="submit"
              disabled={loading}
              className="min-h-[44px] px-6 py-2.5 rounded-xl bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-500 hover:to-blue-500 disabled:opacity-60 text-white text-xs font-bold cursor-pointer"
            >
              {loading ? 'جاري التحقق...' : 'فتح لوحة الإدارة'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
