import React, { useState } from 'react';
import {
  KeyRound,
  ShieldCheck,
  ArrowLeft,
  Tv,
  Zap,
  Sparkles,
  Download,
  Server,
  Check,
} from 'lucide-react';
import { BrandMark } from './BrandMark';
import { TelegramPaperPlaneIcon, normalizeSlideExternalUrl } from './HeroBanner';
import {
  getApkServerUrl,
  isNativeApkRuntime,
  normalizeServerBaseUrl,
  setApkServerUrl,
} from '../api';
import type { PublicStatusResponse } from '../types';

interface LoginScreenProps {
  publicStatus: PublicStatusResponse | null;
  initialError?: string | null;
  onLoginSuccess: (data: {
    token: string;
    adminToken?: string;
    label: string;
    durationDays: number;
    expiresAt?: string | null;
    maxDevices?: number;
    connectedDevicesCount?: number;
    isAdminUnlocked: boolean;
  }) => void;
  loginAction: (code: string) => Promise<{
    token: string;
    adminToken?: string;
    label: string;
    durationDays: number;
    expiresAt?: string | null;
    maxDevices?: number;
    connectedDevicesCount?: number;
    isAdminUnlocked: boolean;
  }>;
  onSecurityBlock?: (block: {
    code: 'VPN_BLOCKED' | 'SNIFFER_BLOCKED';
    message: string;
  }) => void;
  onMaintenanceMode?: (message: string) => void;
}

export const LoginScreen: React.FC<LoginScreenProps> = ({
  publicStatus,
  initialError = null,
  onLoginSuccess,
  loginAction,
  onSecurityBlock,
  onMaintenanceMode,
}) => {
  const [code, setCode] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(initialError);
  const [telegramNotice, setTelegramNotice] = useState<string | null>(null);
  const isNativeApk = isNativeApkRuntime();
  const [showApkServerBox, setShowApkServerBox] = useState(false);
  const [apkServerDraft, setApkServerDraft] = useState(() =>
    isNativeApk ? getApkServerUrl() : ''
  );
  const [apkServerSaved, setApkServerSaved] = useState(false);

  const telegramHref = normalizeSlideExternalUrl(publicStatus?.telegramUrl);
  const apkDownloadHref = !isNativeApk
    ? normalizeSlideExternalUrl(publicStatus?.apkDownloadUrl)
    : '';

  React.useEffect(() => {
    if (initialError) setError(initialError);
  }, [initialError]);

  const handleSaveNativeServerUrl = () => {
    const cleaned = normalizeServerBaseUrl(apkServerDraft);
    if (!cleaned) {
      setError('يرجى إدخال رابط سيرفر صحيح يبدأ بـ https://');
      return;
    }
    setApkServerUrl(cleaned);
    setApkServerDraft(cleaned);
    setApkServerSaved(true);
    setError(null);
    window.setTimeout(() => setApkServerSaved(false), 2200);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!code.trim()) {
      setError('يرجى إدخال كود التفعيل للمتابعة.');
      return;
    }
    setLoading(true);
    setError(null);
    try {
      const res = await loginAction(code.trim());
      onLoginSuccess(res);
    } catch (err: any) {
      if (err?.code === 'MAINTENANCE_MODE') {
        onMaintenanceMode?.(
          err?.message || 'التطبيق في وضع الصيانة يرجى المحاولة لاحقاً'
        );
        return;
      }
      if (err?.code === 'VPN_BLOCKED' || err?.code === 'SNIFFER_BLOCKED') {
        onSecurityBlock?.({ code: err.code, message: err.message });
      }
      if (isNativeApk && (!err?.status || (err?.status === 403 && !err?.code))) {
        setShowApkServerBox(true);
      }
      setError(err?.message || 'كود التفعيل غير صالح.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div
      onContextMenu={(e) => e.preventDefault()}
      className="h-dvh bg-[#060B16] relative flex flex-col items-center pt-safe pb-safe px-safe overflow-y-auto overflow-x-hidden select-none"
      dir="rtl"
    >
      <div className="pointer-events-none fixed inset-0 opacity-45 bg-[radial-gradient(circle_at_20%_20%,rgba(18,104,251,0.22),transparent_45%),radial-gradient(circle_at_80%_75%,rgba(139,92,246,0.16),transparent_45%)]" />

      <div className="relative z-10 w-full max-w-md my-auto px-4 py-6 sm:py-8">
        <div className="flex justify-center mb-5 sm:mb-8">
          <BrandMark size="lg" />
        </div>

        <div className="bg-[#0B1222] border border-[#1B2947] rounded-3xl p-5 sm:p-7 shadow-2xl">
          <div className="text-center mb-5 sm:mb-6">
            <div className="w-12 h-12 rounded-2xl bg-blue-600/15 border border-blue-500/30 flex items-center justify-center mx-auto mb-3 text-blue-400">
              <KeyRound className="w-6 h-6" />
            </div>
            <h1 className="text-lg sm:text-xl font-bold text-white">تسجيل الدخول بكود التفعيل</h1>
            <p className="text-xs text-slate-400 mt-1.5 leading-relaxed">
              أدخل كود الاشتراك الخاص بك لمشاهدة القنوات المباشرة والأفلام والمسلسلات
            </p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label htmlFor="access-code-input" className="block text-xs font-semibold text-slate-300 mb-2">
                كود الدخول
              </label>
              <input
                id="access-code-input"
                type="password"
                inputMode="text"
                autoComplete="off"
                autoCorrect="off"
                autoCapitalize="off"
                spellCheck={false}
                value={code}
                onChange={(e) => setCode(e.target.value)}
                placeholder="أدخل الكود هنا..."
                className="w-full min-h-[48px] px-4 py-3 rounded-2xl bg-[#060B16] border border-[#1E2E4F] text-white text-center font-mono text-lg tracking-[0.25em] placeholder:tracking-normal placeholder:font-sans placeholder:text-sm placeholder-slate-500 focus:outline-none focus:border-blue-500 transition-colors"
              />
            </div>

            {error && (
              <div className="p-3 rounded-xl bg-red-500/10 border border-red-500/30 text-red-300 text-xs font-medium text-center">
                {error}
              </div>
            )}

            <button
              type="submit"
              disabled={loading}
              className="w-full min-h-[48px] py-3.5 px-6 rounded-2xl bg-gradient-to-r from-[#1268FB] to-[#2563EB] hover:from-[#1D74FF] hover:to-[#3B82F6] disabled:opacity-60 text-white font-bold text-sm flex items-center justify-center gap-2 active:scale-[0.99] transition-all cursor-pointer"
            >
              <span>{loading ? 'جاري التحقق...' : 'تسجيل الدخول'}</span>
              <ArrowLeft className="w-4 h-4" />
            </button>

            {telegramHref ? (
              <a
                href={telegramHref}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full min-h-[46px] py-3 px-5 rounded-2xl bg-[#229ED9]/15 hover:bg-[#229ED9]/25 border border-[#229ED9]/45 hover:border-[#38BDF8]/75 text-[#7DD3FC] hover:text-white font-bold text-xs sm:text-sm flex items-center justify-center gap-2 active:scale-[0.99] transition-all cursor-pointer"
              >
                <TelegramPaperPlaneIcon className="w-4 h-4 shrink-0 text-[#38BDF8]" />
                <span>الحصول على كود عن طريق التليجرام</span>
              </a>
            ) : (
              <button
                type="button"
                onClick={() =>
                  setTelegramNotice((prev) =>
                    prev
                      ? null
                      : publicStatus?.isInitialSetup
                        ? 'يرجى التواصل مع إدارة التطبيق عبر التليجرام للحصول على كود التفعيل. (للمدير: ضع رابط حسابك أو قناتك من لوحة التحكم ← الاشتراكات والأكواد).'
                        : 'يرجى التواصل مع إدارة التطبيق عبر التليجرام للحصول على كود الاشتراك الخاص بك.'
                  )
                }
                className="w-full min-h-[46px] py-3 px-5 rounded-2xl bg-[#229ED9]/15 hover:bg-[#229ED9]/25 border border-[#229ED9]/45 hover:border-[#38BDF8]/75 text-[#7DD3FC] hover:text-white font-bold text-xs sm:text-sm flex items-center justify-center gap-2 active:scale-[0.99] transition-all cursor-pointer"
              >
                <TelegramPaperPlaneIcon className="w-4 h-4 shrink-0 text-[#38BDF8]" />
                <span>الحصول على كود عن طريق التليجرام</span>
              </button>
            )}

            {telegramNotice && !telegramHref && (
              <div className="p-3 rounded-xl bg-[#229ED9]/10 border border-[#229ED9]/30 text-sky-200 text-xs font-medium text-center leading-relaxed">
                {telegramNotice}
              </div>
            )}

            {apkDownloadHref && (
              <a
                href={apkDownloadHref}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full min-h-[46px] py-3 px-5 rounded-2xl bg-emerald-500/15 hover:bg-emerald-500/25 border border-emerald-500/40 hover:border-emerald-400/70 text-emerald-300 hover:text-white font-bold text-xs sm:text-sm flex items-center justify-center gap-2 active:scale-[0.99] transition-all cursor-pointer"
              >
                <Download className="w-4 h-4 shrink-0 text-emerald-400" />
                <span>تحميل تطبيق الأندرويد (APK)</span>
              </a>
            )}
          </form>

          {isNativeApk && (
            <div className="mt-4 pt-3 border-t border-[#1B2947]/80">
              <button
                type="button"
                onClick={() => setShowApkServerBox((prev) => !prev)}
                className="w-full flex items-center justify-center gap-1.5 text-[11px] text-slate-400 hover:text-slate-200 py-1 cursor-pointer"
              >
                <Server className="w-3.5 h-3.5 text-slate-400" />
                <span>إعدادات اتصال الخادم</span>
              </button>

              {showApkServerBox && (
                <div className="mt-2.5 p-3 rounded-2xl bg-[#060B16] border border-[#1E2E4F] space-y-2.5">
                  <label className="block text-[11px] text-slate-300 font-semibold">
                    رابط خادم MS TV
                  </label>
                  <input
                    type="url"
                    dir="ltr"
                    value={apkServerDraft}
                    onChange={(e) => setApkServerDraft(e.target.value)}
                    placeholder="https://..."
                    className="w-full min-h-[40px] px-3 py-2 rounded-xl bg-[#0B1222] border border-[#1E2E4F] text-xs font-mono text-cyan-300 focus:outline-none focus:border-blue-500"
                  />
                  <button
                    type="button"
                    onClick={handleSaveNativeServerUrl}
                    className="w-full min-h-[38px] px-4 py-2 rounded-xl bg-blue-600/25 hover:bg-blue-600/35 border border-blue-500/40 text-blue-200 text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    {apkServerSaved ? (
                      <>
                        <Check className="w-3.5 h-3.5 text-emerald-400" />
                        <span>تم حفظ رابط الخادم</span>
                      </>
                    ) : (
                      <span>حفظ رابط الخادم</span>
                    )}
                  </button>
                </div>
              )}
            </div>
          )}

          <div className="mt-5 sm:mt-6 pt-4 sm:pt-5 border-t border-[#1B2947] grid grid-cols-3 gap-2 text-center text-[11px] text-slate-400">
            <div className="flex flex-col items-center gap-1">
              <Zap className="w-4 h-4 text-cyan-400" />
              <span>تشغيل فوري</span>
            </div>
            <div className="flex flex-col items-center gap-1">
              <Tv className="w-4 h-4 text-blue-400" />
              <span>جودة عالية</span>
            </div>
            <div className="flex flex-col items-center gap-1">
              <Sparkles className="w-4 h-4 text-purple-400" />
              <span>قوائم مخصصة</span>
            </div>
          </div>
        </div>

        {/* Initial owner setup note ONLY before codes are customized */}
        {publicStatus?.isInitialSetup && publicStatus.initialHint && (
          <div className="mt-4 bg-[#0E172C] border border-blue-500/30 rounded-2xl p-4 text-xs text-slate-300 space-y-2">
            <div className="flex items-center gap-2 text-blue-400 font-bold">
              <ShieldCheck className="w-4 h-4 shrink-0" />
              <span>أكواد التجربة الأولية (تختفي تلقائياً فور تغييرها):</span>
            </div>
            <button
              type="button"
              onClick={() => setCode(publicStatus.initialHint!.defaultUserCode)}
              className="w-full min-h-[44px] flex items-center justify-between bg-[#060B16] hover:bg-white/5 rounded-xl px-3.5 py-2 cursor-pointer transition-colors"
            >
              <span>كود المشتركين:</span>
              <span className="font-mono font-bold text-cyan-400">
                {publicStatus.initialHint.defaultUserCode}
              </span>
            </button>
            <button
              type="button"
              onClick={() => setCode(publicStatus.initialHint!.defaultAdminCode)}
              className="w-full min-h-[44px] flex items-center justify-between bg-[#060B16] hover:bg-white/5 rounded-xl px-3.5 py-2 cursor-pointer transition-colors"
            >
              <span>كود المالك الخاص:</span>
              <span className="font-mono font-bold text-purple-400">
                {publicStatus.initialHint.defaultAdminCode}
              </span>
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
