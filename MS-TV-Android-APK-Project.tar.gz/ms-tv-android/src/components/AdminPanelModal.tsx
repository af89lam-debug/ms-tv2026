import React, { useEffect, useState, useMemo, useCallback } from 'react';
import {
  X,
  Link2,
  Server,
  PlusCircle,
  Database,
  FolderCog,
  KeyRound,
  RefreshCw,
  Trash2,
  Eye,
  EyeOff,
  Upload,
  CheckCircle2,
  AlertCircle,
  FileText,
  Search,
  Edit3,
  FolderInput,
  Lock,
  Image as ImageIcon,
  ArrowUp,
  ArrowDown,
  ChevronsUp,
  Calendar,
  Copy,
  Cloud,
  Sparkles,
  PauseCircle,
  PlayCircle,
  Layers,
  ExternalLink,
  Play,
  Shield,
  ShieldAlert,
  ShieldCheck,
  Users,
  User,
  Smartphone,
  RotateCcw,
  WifiOff,
  Wrench,
  Power,
  CheckSquare,
  Square,
  Download,
} from 'lucide-react';
import type { User as FirebaseUser } from 'firebase/auth';
import { api } from '../api';
import type {
  AdminOverviewResponse,
  CategorySummary,
  Channel,
  HeroActionType,
  HeroSlide,
  HeroThemePreset,
  SecurityPolicyConfig,
} from '../types';
import { ChannelLogo } from './ChannelLogo';
import { CategoryLogo } from './CategoryLogo';
import {
  HeroPresetBackdrop,
  TelegramPaperPlaneIcon,
  detectIsTelegramSlide,
  normalizeSlideExternalUrl,
} from './HeroBanner';
import {
  loadEncryptedVaultFromFirestore,
  saveEncryptedVaultToFirestore,
  signInAdminForCloudVault,
  signOutAdminCloudVault,
  subscribeToFirebaseAdmin,
} from '../firebase';

function cleanClientUrl(raw: string): string {
  let cleaned = raw
    .replace(/[\u200B-\u200F\u202A-\u202E\u2060-\u206F\uFEFF\u00A0]/g, '')
    .replace(/&amp;/gi, '&')
    .trim();
  const match = cleaned.match(/https?:\/\/[^\s"'<>]+/i);
  if (match) cleaned = match[0];
  return cleaned.replace(/[.,;،؛"'`]+$/, '').trim();
}

function toDateInputValue(isoOrOffsetDays: string | number): string {
  const date =
    typeof isoOrOffsetDays === 'number'
      ? new Date(Date.now() + isoOrOffsetDays * 86400000)
      : new Date(isoOrOffsetDays);
  if (Number.isNaN(date.getTime())) {
    return new Date(Date.now() + 30 * 86400000).toISOString().slice(0, 10);
  }
  const yyyy = date.getFullYear();
  const mm = String(date.getMonth() + 1).padStart(2, '0');
  const dd = String(date.getDate()).padStart(2, '0');
  return `${yyyy}-${mm}-${dd}`;
}

function dateInputToEndOfDayIso(dateStr: string): string {
  if (!dateStr) {
    return new Date(Date.now() + 30 * 86400000).toISOString();
  }
  const parsed = new Date(`${dateStr}T23:59:59`);
  if (Number.isNaN(parsed.getTime())) {
    return new Date(Date.now() + 30 * 86400000).toISOString();
  }
  return parsed.toISOString();
}

async function compressBannerImageFile(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(new Error('تعذر قراءة ملف الصورة.'));
    reader.onload = () => {
      const img = new window.Image();
      img.onerror = () => reject(new Error('صيغة الصورة غير مدعومة.'));
      img.onload = () => {
        const maxW = 1280;
        const maxH = 680;
        let width = img.width;
        let height = img.height;
        if (width > maxW) {
          height = Math.round((height * maxW) / width);
          width = maxW;
        }
        if (height > maxH) {
          width = Math.round((width * maxH) / height);
          height = maxH;
        }
        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          resolve(String(reader.result || ''));
          return;
        }
        ctx.drawImage(img, 0, 0, width, height);
        resolve(canvas.toDataURL('image/jpeg', 0.84));
      };
      img.src = String(reader.result || '');
    };
    reader.readAsDataURL(file);
  });
}

async function compressCategoryLogoFile(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(new Error('تعذر قراءة ملف الشعار.'));
    reader.onload = () => {
      const img = new window.Image();
      img.onerror = () => reject(new Error('صيغة الشعار غير مدعومة.'));
      img.onload = () => {
        const maxSide = 256;
        let width = img.width || maxSide;
        let height = img.height || maxSide;
        if (width > maxSide || height > maxSide) {
          if (width >= height) {
            height = Math.max(1, Math.round((height * maxSide) / width));
            width = maxSide;
          } else {
            width = Math.max(1, Math.round((width * maxSide) / height));
            height = maxSide;
          }
        }
        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          resolve(String(reader.result || ''));
          return;
        }
        ctx.clearRect(0, 0, width, height);
        ctx.drawImage(img, 0, 0, width, height);
        const webp = canvas.toDataURL('image/webp', 0.9);
        if (webp.startsWith('data:image/webp')) {
          resolve(webp);
        } else {
          resolve(canvas.toDataURL('image/png'));
        }
      };
      img.src = String(reader.result || '');
    };
    reader.readAsDataURL(file);
  });
}

export type AdminTab =
  | 'm3u'
  | 'xtream'
  | 'direct'
  | 'hero'
  | 'categories'
  | 'channels'
  | 'protection'
  | 'security'
  | 'sources'
  | 'apk';

interface AdminPanelModalProps {
  initialTab?: AdminTab;
  channels: Channel[];
  categories: CategorySummary[];
  onClose: () => void;
  onLockAdmin: () => void;
  onCatalogChanged: () => Promise<void>;
  onOpenChannelEdit: (channel: Channel) => void;
}

export const AdminPanelModal: React.FC<AdminPanelModalProps> = ({
  initialTab = 'm3u',
  channels,
  categories,
  onClose,
  onLockAdmin,
  onCatalogChanged,
  onOpenChannelEdit,
}) => {
  const [activeTab, setActiveTab] = useState<AdminTab>(initialTab);
  const [overview, setOverview] = useState<AdminOverviewResponse | null>(null);
  const [loadingOverview, setLoadingOverview] = useState(true);
  const [busy, setBusy] = useState(false);
  const [feedback, setFeedback] = useState<{ type: 'ok' | 'err'; text: string } | null>(null);

  // Firebase Cloud Vault state (optional encrypted cloud backup)
  const [cloudUser, setCloudUser] = useState<FirebaseUser | null>(null);
  const [cloudSyncing, setCloudSyncing] = useState(false);

  // Tab 1: M3U State
  const [m3uName, setM3uName] = useState('');
  const [m3uUrl, setM3uUrl] = useState('');
  const [m3uFileText, setM3uFileText] = useState('');
  const [m3uFileName, setM3uFileName] = useState('');
  const [showRawM3uBox, setShowRawM3uBox] = useState(false);

  // Tab 2: Xtream State
  const [xtName, setXtName] = useState('');
  const [xtHost, setXtHost] = useState('');
  const [xtUser, setXtUser] = useState('');
  const [xtPass, setXtPass] = useState('');
  const [xtIncludeVod, setXtIncludeVod] = useState(true);

  // Tab 3: Direct Link State
  const [dirName, setDirName] = useState('');
  const [dirUrl, setDirUrl] = useState('');
  const [dirGroup, setDirGroup] = useState('');
  const [dirLogo, setDirLogo] = useState('');
  const [dirType, setDirType] = useState<'live' | 'movie' | 'series'>('live');

  // Tab 4: Hero Gallery / Banner Slides Manager
  const [editingSlideId, setEditingSlideId] = useState<string | null>(null);
  const [slideTitle, setSlideTitle] = useState('');
  const [slideSubtitle, setSlideSubtitle] = useState('');
  const [slideBadge, setSlideBadge] = useState('قناتنا الرسمية');
  const [slideImageUrl, setSlideImageUrl] = useState('');
  const [slideActionType, setSlideActionType] = useState<HeroActionType>('external_url');
  const [slideButtonText, setSlideButtonText] = useState('اشترك الآن');
  const [slideExternalUrl, setSlideExternalUrl] = useState('');
  const [slideChannelId, setSlideChannelId] = useState('');
  const [slideChannelFilter, setSlideChannelFilter] = useState('');
  const [slideTargetCategory, setSlideTargetCategory] = useState('__ALL__');
  const [slideShowLiveBadge, setSlideShowLiveBadge] = useState(false);
  const [slideThemePreset, setSlideThemePreset] = useState<HeroThemePreset>('telegram');

  // Tab 5: Category Ordering, Logos, Renaming & Deletion
  const [newSectionName, setNewSectionName] = useState('');
  const [newSectionLogo, setNewSectionLogo] = useState('');
  const [renamingCategory, setRenamingCategory] = useState<string | null>(null);
  const [renameValue, setRenameValue] = useState('');
  const [logoEditingCategory, setLogoEditingCategory] = useState<string | null>(null);
  const [logoDraftValue, setLogoDraftValue] = useState('');
  const [catSearchQuery, setCatSearchQuery] = useState('');
  const [selectedCatNames, setSelectedCatNames] = useState<Set<string>>(new Set());
  const [blockFutureCatSync, setBlockFutureCatSync] = useState(true);
  const [confirmDeleteSingleCat, setConfirmDeleteSingleCat] = useState<string | null>(null);
  const [confirmBulkDeleteCats, setConfirmBulkDeleteCats] = useState(false);
  const [showExcludedCatsPanel, setShowExcludedCatsPanel] = useState(false);

  // Tab 6: Bulk Channel Manager
  const [chSearch, setChSearch] = useState('');
  const [chGroupFilter, setChGroupFilter] = useState('ALL');
  const [selectedChIds, setSelectedChIds] = useState<Set<string>>(new Set());
  const [bulkTargetGroup, setBulkTargetGroup] = useState('');

  // Tab 7: Subscriptions (1-Person or Custom Multi-Person), Telegram Link & Admin Master Code
  const [newAdminCode, setNewAdminCode] = useState('');
  const [showAdminCodePlain, setShowAdminCodePlain] = useState(false);
  const [telegramCodeUrl, setTelegramCodeUrl] = useState('');
  const [subCode, setSubCode] = useState('');
  const [subLabel, setSubLabel] = useState('');
  const [subSeatMode, setSubSeatMode] = useState<'single' | 'multi'>('single');
  const [subMaxDevices, setSubMaxDevices] = useState<number>(3);
  const [subExpiryDate, setSubExpiryDate] = useState(() => toDateInputValue(30));
  const [subNotes, setSubNotes] = useState('');
  const [editingExpiryId, setEditingExpiryId] = useState<string | null>(null);
  const [editingExpiryDate, setEditingExpiryDate] = useState('');
  const [editingMaxDevicesId, setEditingMaxDevicesId] = useState<string | null>(null);
  const [editingMaxDevicesVal, setEditingMaxDevicesVal] = useState<number>(1);
  const [expandedDevicesSubId, setExpandedDevicesSubId] = useState<string | null>(null);
  const [policyBusyField, setPolicyBusyField] = useState<string | null>(null);
  const [maintenanceMessageDraft, setMaintenanceMessageDraft] = useState(
    'التطبيق في وضع الصيانة يرجى المحاولة لاحقاً'
  );
  const [maintenanceBusy, setMaintenanceBusy] = useState(false);

  // Tab 9: Android APK Settings & Export State
  const [apkServerUrlDraft, setApkServerUrlDraft] = useState('');
  const [apkDownloadUrlDraft, setApkDownloadUrlDraft] = useState('');
  const [apkSaving, setApkSaving] = useState(false);
  const [copiedApkServer, setCopiedApkServer] = useState(false);

  // Tab 8: Sources Secret Visibility
  const [revealedIds, setRevealedIds] = useState<Set<string>>(new Set());

  useEffect(() => {
    const unsub = subscribeToFirebaseAdmin((u) => setCloudUser(u));
    return unsub;
  }, []);

  const notify = useCallback((type: 'ok' | 'err', text: string) => {
    setFeedback({ type, text });
  }, []);

  const triggerSilentCloudBackup = useCallback(async () => {
    if (!cloudUser || !cloudUser.emailVerified) return;
    try {
      setCloudSyncing(true);
      const snap = await api.exportCloudSnapshot();
      await saveEncryptedVaultToFirestore(snap);
    } catch {
      // silent background sync
    } finally {
      setCloudSyncing(false);
    }
  }, [cloudUser]);

  const loadOverview = useCallback(async () => {
    setLoadingOverview(true);
    try {
      const data = await api.getAdminOverview();
      setOverview(data);
      setNewAdminCode((prev) => prev || data.adminCode);
      setTelegramCodeUrl(data.telegramCodeUrl || '');
      setApkServerUrlDraft(data.apkServerUrl || data.detectedServerUrl || '');
      setApkDownloadUrlDraft(data.apkDownloadUrl || '');
      if (data.maintenanceMessage) {
        setMaintenanceMessageDraft(data.maintenanceMessage);
      }
    } catch (err: any) {
      notify('err', err?.message || 'تعذر تحميل بيانات الإدارة.');
    } finally {
      setLoadingOverview(false);
    }
  }, [notify]);

  useEffect(() => {
    loadOverview();
  }, [loadOverview]);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setM3uFileName(file.name);
    if (!m3uName) setM3uName(file.name.replace(/\.m3u8?$/i, ''));
    const reader = new FileReader();
    reader.onload = () => {
      setM3uFileText(String(reader.result || ''));
    };
    reader.readAsText(file);
  };

  const handleAddM3u = async (e: React.FormEvent) => {
    e.preventDefault();
    const cleanedUrl = cleanClientUrl(m3uUrl);
    const hasText = Boolean(m3uFileText.trim());

    if (!cleanedUrl && !hasText) {
      notify('err', 'يرجى وضع رابط M3U أو اختيار ملف M3U أو لصق محتواه النصي.');
      return;
    }

    setBusy(true);
    setFeedback(null);
    const sourceLabel = m3uName.trim() || 'باقة M3U الرئيسية';

    try {
      let res;
      if (hasText) {
        res = await api.addM3uSource({
          name: sourceLabel,
          m3uUrl: cleanedUrl || undefined,
          m3uContent: m3uFileText.trim(),
        });
      } else {
        try {
          res = await api.addM3uSource({
            name: sourceLabel,
            m3uUrl: cleanedUrl,
          });
        } catch (serverErr: any) {
          let browserFetchedText = '';
          try {
            const controller = new AbortController();
            const timer = window.setTimeout(() => controller.abort(), 15000);
            const browserRes = await fetch(cleanedUrl, { signal: controller.signal });
            window.clearTimeout(timer);
            if (browserRes.ok) {
              const txt = await browserRes.text();
              if (txt.includes('#EXTM3U') || txt.includes('#EXTINF') || txt.includes('http')) {
                browserFetchedText = txt;
              }
            }
          } catch {
            // Browser CORS blocked; rethrow informative server error
          }

          if (browserFetchedText) {
            res = await api.addM3uSource({
              name: sourceLabel,
              m3uUrl: cleanedUrl,
              m3uContent: browserFetchedText,
            });
          } else {
            throw serverErr;
          }
        }
      }

      setM3uName('');
      setM3uUrl('');
      setM3uFileText('');
      setM3uFileName('');
      setShowRawM3uBox(false);
      await Promise.all([loadOverview(), onCatalogChanged()]);
      await triggerSilentCloudBackup();
      notify(
        'ok',
        `تم حفظ ${res.addedCount} قناة و ${res.groupsCount} قسم بشكل دائم! لن تحتاج لإدخال الرابط مرة أخرى.`
      );
    } catch (err: any) {
      setShowRawM3uBox(true);
      notify('err', err?.message || 'فشل إضافة رابط M3U.');
    } finally {
      setBusy(false);
    }
  };

  const handleAddXtream = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!xtHost.trim() || !xtUser.trim() || !xtPass.trim()) {
      notify('err', 'يرجى إدخال الهوست واسم المستخدم وكلمة المرور لسيرفر Xtream.');
      return;
    }
    setBusy(true);
    setFeedback(null);
    try {
      const res = await api.addXtreamSource({
        name: xtName.trim() || 'اشتراك Xtream Codes',
        host: xtHost.trim(),
        username: xtUser.trim(),
        password: xtPass.trim(),
        includeVod: xtIncludeVod,
      });
      setXtName('');
      setXtHost('');
      setXtUser('');
      setXtPass('');
      await Promise.all([loadOverview(), onCatalogChanged()]);
      await triggerSilentCloudBackup();
      notify(
        'ok',
        `تم ربط وحفظ باقة Xtream بشكل دائم (${res.addedCount} قناة في ${res.groupsCount} قسم)!`
      );
    } catch (err: any) {
      notify('err', err?.message || 'فشل الاتصال بسيرفر Xtream.');
    } finally {
      setBusy(false);
    }
  };

  const handleAddDirect = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!dirName.trim() || !dirUrl.trim()) {
      notify('err', 'اسم القناة ورابط البث المباشر مطلوبان.');
      return;
    }
    setBusy(true);
    setFeedback(null);
    try {
      await api.addDirectChannel({
        name: dirName.trim(),
        streamUrl: dirUrl.trim(),
        group: dirGroup.trim() || 'قنوات مضافة يدوياً',
        logo: dirLogo.trim(),
        contentType: dirType,
      });
      setDirName('');
      setDirUrl('');
      setDirLogo('');
      await Promise.all([loadOverview(), onCatalogChanged()]);
      await triggerSilentCloudBackup();
      notify('ok', 'تمت إضافة القناة وحفظها بشكل دائم (الرابط مشفر ومخفي عن المشتركين).');
    } catch (err: any) {
      notify('err', err?.message || 'تعذر إضافة الرابط.');
    } finally {
      setBusy(false);
    }
  };

  // Hero Slide Handlers
  const handleBannerImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      setBusy(true);
      const dataUrl = await compressBannerImageFile(file);
      setSlideImageUrl(dataUrl);
      notify('ok', 'تم تجهيز صورة المعرض بنجاح، اضغط حفظ لاعتمادها في الواجهة الرئيسية.');
    } catch (err: any) {
      notify('err', err?.message || 'تعذر معالجة الصورة.');
    } finally {
      setBusy(false);
      e.target.value = '';
    }
  };

  const resetSlideForm = () => {
    setEditingSlideId(null);
    setSlideTitle('');
    setSlideSubtitle('');
    setSlideBadge('قناتنا الرسمية');
    setSlideImageUrl('');
    setSlideActionType('external_url');
    setSlideButtonText('اشترك الآن');
    setSlideExternalUrl('');
    setSlideChannelId('');
    setSlideChannelFilter('');
    setSlideTargetCategory('__ALL__');
    setSlideShowLiveBadge(false);
    setSlideThemePreset('telegram');
  };

  const handleSelectSlideActionType = (nextType: HeroActionType) => {
    setSlideActionType(nextType);
    if (nextType === 'external_url') {
      setSlideShowLiveBadge(false);
      if (
        !slideButtonText.trim() ||
        slideButtonText === 'مشاهدة الآن' ||
        slideButtonText === 'تصفح القسم'
      ) {
        setSlideButtonText('اشترك الآن');
      }
    } else if (nextType === 'watch_channel') {
      setSlideShowLiveBadge(true);
      if (
        !slideButtonText.trim() ||
        slideButtonText === 'اشترك الآن' ||
        slideButtonText === 'تصفح القسم'
      ) {
        setSlideButtonText('مشاهدة الآن');
      }
      if (slideThemePreset === 'telegram') {
        setSlideThemePreset('default');
      }
    } else if (nextType === 'category') {
      setSlideShowLiveBadge(false);
      if (
        !slideButtonText.trim() ||
        slideButtonText === 'مشاهدة الآن' ||
        slideButtonText === 'اشترك الآن'
      ) {
        setSlideButtonText('تصفح القسم');
      }
    } else if (nextType === 'none') {
      setSlideShowLiveBadge(false);
    }
  };

  const applyTelegramSlideTemplate = () => {
    setSlideTitle('اشترك في قناتنا على التليجرام');
    setSlideSubtitle('تابع أحدث التحديثات، القنوات الجديدة، وأكواد الاشتراك أولاً بأول');
    setSlideBadge('قناة التليجرام الرسمية');
    setSlideActionType('external_url');
    setSlideButtonText('اشترك الآن');
    setSlideShowLiveBadge(false);
    setSlideThemePreset('telegram');
  };

  const applyLiveMatchSlideTemplate = () => {
    setSlideTitle('أقوى المباريات والبطولات المباشرة');
    setSlideSubtitle('مشاهدة فورية بأعلى جودة واستقرار بدون تقطيع');
    setSlideBadge('بث مباشر HD');
    setSlideActionType('watch_channel');
    setSlideButtonText('مشاهدة الآن');
    setSlideShowLiveBadge(true);
    setSlideThemePreset('default');
  };

  const applyVipPromoSlideTemplate = () => {
    setSlideTitle('اشترك أو جدد اشتراكك الآن');
    setSlideSubtitle('احصل على كود التفعيل الفوري وتمتع بجميع الباقات والقنوات المشفرة');
    setSlideBadge('عروض الاشتراك VIP');
    setSlideActionType('external_url');
    setSlideButtonText('اشترك الآن');
    setSlideShowLiveBadge(false);
    setSlideThemePreset('promo');
  };

  const startEditSlide = (slide: HeroSlide) => {
    const inferredAction: HeroActionType =
      slide.actionType || (slide.externalUrl ? 'external_url' : 'watch_channel');
    const isTg = detectIsTelegramSlide(slide);
    setEditingSlideId(slide.id);
    setSlideTitle(slide.title || '');
    setSlideSubtitle(slide.subtitle || '');
    setSlideBadge(slide.badge ?? '');
    setSlideImageUrl(slide.imageUrl || '');
    setSlideActionType(inferredAction);
    setSlideButtonText(
      slide.buttonText ||
        (inferredAction === 'external_url'
          ? 'اشترك الآن'
          : inferredAction === 'category'
            ? 'تصفح القسم'
            : 'مشاهدة الآن')
    );
    setSlideExternalUrl(slide.externalUrl || '');
    setSlideChannelId(slide.channelId || '');
    setSlideTargetCategory(slide.targetCategory || '__ALL__');
    setSlideShowLiveBadge(
      typeof slide.showLiveBadge === 'boolean'
        ? slide.showLiveBadge
        : inferredAction === 'watch_channel' && !isTg
    );
    setSlideThemePreset(slide.themePreset || (isTg ? 'telegram' : 'default'));
  };

  const handleSaveHeroSlide = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!slideTitle.trim() && !slideImageUrl.trim()) {
      notify('err', 'يرجى كتابة عنوان للشريحة أو رفع صورة للعرض.');
      return;
    }

    const normalizedUrl = normalizeSlideExternalUrl(slideExternalUrl);
    if (slideActionType === 'external_url' && !normalizedUrl) {
      notify(
        'err',
        'يرجى إدخال رابط قناة التليجرام أو الرابط الخارجي (مثال: https://t.me/channel أو @channel).'
      );
      return;
    }

    setBusy(true);
    setFeedback(null);
    const payload = {
      title: slideTitle.trim(),
      subtitle: slideSubtitle.trim(),
      badge: slideBadge.trim(),
      imageUrl: slideImageUrl.trim(),
      actionType: slideActionType,
      buttonText: slideButtonText.trim() || undefined,
      externalUrl: slideActionType === 'external_url' ? normalizedUrl : '',
      channelId: slideActionType === 'watch_channel' ? slideChannelId || '' : '',
      targetCategory: slideActionType === 'category' ? slideTargetCategory || '__ALL__' : '',
      showLiveBadge: slideShowLiveBadge,
      themePreset: slideThemePreset,
    };

    try {
      if (editingSlideId) {
        await api.updateHeroSlide(editingSlideId, payload);
        notify('ok', 'تم حفظ تعديلات شريحة المعرض بنجاح!');
      } else {
        await api.createHeroSlide({
          ...payload,
          active: true,
        });
        notify('ok', 'تمت إضافة شريحة المعرض الجديدة للواجهة الرئيسية بنجاح!');
      }
      resetSlideForm();
      await Promise.all([loadOverview(), onCatalogChanged()]);
      await triggerSilentCloudBackup();
    } catch (err: any) {
      notify('err', err?.message || 'تعذر حفظ شريحة المعرض.');
    } finally {
      setBusy(false);
    }
  };

  const handleMoveHeroSlide = async (id: string, direction: 'up' | 'down') => {
    setBusy(true);
    try {
      await api.moveHeroSlide(id, direction);
      await Promise.all([loadOverview(), onCatalogChanged()]);
      await triggerSilentCloudBackup();
    } catch (err: any) {
      notify('err', err?.message || 'تعذر تغيير ترتيب الشريحة.');
    } finally {
      setBusy(false);
    }
  };

  const handleToggleHeroSlide = async (slide: HeroSlide) => {
    setBusy(true);
    try {
      await api.updateHeroSlide(slide.id, { active: !slide.active });
      await Promise.all([loadOverview(), onCatalogChanged()]);
      await triggerSilentCloudBackup();
    } finally {
      setBusy(false);
    }
  };

  const handleDeleteHeroSlide = async (id: string) => {
    setBusy(true);
    try {
      await api.deleteHeroSlide(id);
      if (editingSlideId === id) resetSlideForm();
      await Promise.all([loadOverview(), onCatalogChanged()]);
      await triggerSilentCloudBackup();
      notify('ok', 'تم حذف شريحة العرض.');
    } catch (err: any) {
      notify('err', err?.message || 'تعذر حذف الشريحة.');
    } finally {
      setBusy(false);
    }
  };

  // Category Reorder & Rename Handlers
  const handleMoveCategory = async (
    name: string,
    direction: 'up' | 'down' | 'top' | 'bottom'
  ) => {
    setBusy(true);
    try {
      await api.moveCategory(name, direction);
      await Promise.all([loadOverview(), onCatalogChanged()]);
      await triggerSilentCloudBackup();
    } catch (err: any) {
      notify('err', err?.message || 'تعذر تحريك القسم.');
    } finally {
      setBusy(false);
    }
  };

  const handleRenameCategorySubmit = async (oldName: string) => {
    const cleanNew = renameValue.trim();
    if (!cleanNew || cleanNew === oldName) {
      setRenamingCategory(null);
      return;
    }
    setBusy(true);
    try {
      await api.renameCategory(oldName, cleanNew);
      setRenamingCategory(null);
      setRenameValue('');
      await Promise.all([loadOverview(), onCatalogChanged()]);
      await triggerSilentCloudBackup();
      notify('ok', `تم تعديل اسم القسم إلى "${cleanNew}".`);
    } catch (err: any) {
      notify('err', err?.message || 'تعذر تغيير اسم القسم.');
    } finally {
      setBusy(false);
    }
  };

  const handleCreateSection = async () => {
    if (!newSectionName.trim()) return;
    setBusy(true);
    try {
      await api.createCategory(newSectionName.trim(), newSectionLogo.trim() || undefined);
      setBulkTargetGroup(newSectionName.trim());
      setNewSectionName('');
      setNewSectionLogo('');
      await Promise.all([loadOverview(), onCatalogChanged()]);
      await triggerSilentCloudBackup();
      notify('ok', 'تم إنشاء القسم الجديد بنجاح.');
    } catch (err: any) {
      notify('err', err?.message || 'فشل إنشاء القسم.');
    } finally {
      setBusy(false);
    }
  };

  const handleNewSectionLogoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      setBusy(true);
      const dataUrl = await compressCategoryLogoFile(file);
      setNewSectionLogo(dataUrl);
      notify('ok', 'تم تجهيز شعار القسم الجديد.');
    } catch (err: any) {
      notify('err', err?.message || 'تعذر قراءة صورة الشعار.');
    } finally {
      setBusy(false);
      e.target.value = '';
    }
  };

  const handleCategoryLogoFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      setBusy(true);
      const dataUrl = await compressCategoryLogoFile(file);
      setLogoDraftValue(dataUrl);
      notify('ok', 'تم تجهيز الشعار بنجاح، اضغط "حفظ الشعار" لاعتماده.');
    } catch (err: any) {
      notify('err', err?.message || 'تعذر قراءة صورة الشعار.');
    } finally {
      setBusy(false);
      e.target.value = '';
    }
  };

  const handleSaveCategoryLogo = async (categoryName: string, logoValue: string) => {
    setBusy(true);
    setFeedback(null);
    try {
      await api.updateCategoryLogo(categoryName, logoValue.trim());
      setLogoEditingCategory(null);
      setLogoDraftValue('');
      await Promise.all([loadOverview(), onCatalogChanged()]);
      await triggerSilentCloudBackup();
      notify(
        'ok',
        logoValue.trim()
          ? `تم حفظ شعار قسم "${categoryName}" بنجاح.`
          : `تمت استعادة الشعار التلقائي لقسم "${categoryName}".`
      );
    } catch (err: any) {
      notify('err', err?.message || 'تعذر حفظ شعار القسم.');
    } finally {
      setBusy(false);
    }
  };

  const handleDeleteCategoriesAction = async (namesToDelete: string[]) => {
    const cleanNames = namesToDelete.map((n) => n.trim()).filter(Boolean);
    if (cleanNames.length === 0) return;
    setBusy(true);
    setFeedback(null);
    try {
      const res = await api.deleteCategories(cleanNames, blockFutureCatSync);
      setSelectedCatNames((prev) => {
        const next = new Set(prev);
        for (const n of cleanNames) next.delete(n);
        return next;
      });
      setConfirmDeleteSingleCat(null);
      setConfirmBulkDeleteCats(false);
      await Promise.all([loadOverview(), onCatalogChanged()]);
      await triggerSilentCloudBackup();
      notify(
        'ok',
        cleanNames.length === 1
          ? `تم حذف قسم "${cleanNames[0]}" مع جميع قنواته (${res.deletedChannelsCount} قناة) بنجاح.`
          : `تم حذف ${res.deletedCategoriesCount} أقسام (${res.deletedChannelsCount} قناة) بنجاح.`
      );
    } catch (err: any) {
      notify('err', err?.message || 'تعذر حذف الأقسام المحددة.');
    } finally {
      setBusy(false);
    }
  };

  const handleRestoreExcludedCategories = async (catsToUnblock: string[]) => {
    setBusy(true);
    setFeedback(null);
    try {
      const res = await api.restoreExcludedCategories(catsToUnblock);
      setOverview((prev) =>
        prev ? { ...prev, excludedCategories: res.excludedCategories } : prev
      );
      await triggerSilentCloudBackup();
      notify(
        'ok',
        catsToUnblock.includes('__ALL__')
          ? 'تم إلغاء حظر جميع الأقسام المحذوفة؛ ستعود تلقائياً عند تحديث المصدر من تبويب المصادر.'
          : `تم إلغاء حظر "${catsToUnblock[0]}"؛ سيعود القسم عند تحديث المصدر القادم.`
      );
    } catch (err: any) {
      notify('err', err?.message || 'تعذر إلغاء حظر القسم.');
    } finally {
      setBusy(false);
    }
  };

  const sampleLogosByGroup = useMemo(() => {
    const map = new Map<string, string[]>();
    for (const ch of channels) {
      const url = (ch.logo || '').trim();
      if (!url) continue;
      let list = map.get(ch.group);
      if (!list) {
        list = [];
        map.set(ch.group, list);
      }
      if (list.length < 8 && !list.includes(url)) {
        list.push(url);
      }
    }
    return map;
  }, [channels]);

  // Bulk Channel Handlers
  const filteredChannels = useMemo(() => {
    return channels.filter((c) => {
      if (chGroupFilter !== 'ALL' && c.group !== chGroupFilter) return false;
      if (chSearch.trim()) {
        const q = chSearch.toLowerCase();
        return c.name.toLowerCase().includes(q) || c.group.toLowerCase().includes(q);
      }
      return true;
    });
  }, [channels, chGroupFilter, chSearch]);

  const handleBulkMove = async () => {
    const target = bulkTargetGroup.trim();
    if (selectedChIds.size === 0 || !target) {
      notify('err', 'يرجى تحديد قناة واحدة على الأقل واختيار أو كتابة اسم القسم الهدف.');
      return;
    }
    setBusy(true);
    try {
      const res = await api.bulkMoveChannels(Array.from(selectedChIds), target);
      setSelectedChIds(new Set());
      await Promise.all([loadOverview(), onCatalogChanged()]);
      await triggerSilentCloudBackup();
      notify('ok', `تم نقل ${res.movedCount} قناة إلى قسم "${res.targetGroup}" بنجاح.`);
    } catch (err: any) {
      notify('err', err?.message || 'فشل نقل القنوات.');
    } finally {
      setBusy(false);
    }
  };

  // Subscription, Device Limit & Security Shield Handlers
  const generateRandomSubscriberCode = () => {
    const digits = Math.floor(100000 + Math.random() * 900000).toString();
    setSubCode(digits);
  };

  const handleCreateSubscription = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!subCode.trim() || subCode.trim().length < 3) {
      notify('err', 'يرجى إدخال كود اشتراك لا يقل عن 3 خانات.');
      return;
    }
    const effectiveMaxDevices =
      subSeatMode === 'single'
        ? 1
        : Math.max(1, Math.min(1000, Math.floor(Number(subMaxDevices) || 2)));

    setBusy(true);
    setFeedback(null);
    try {
      await api.createAccessCode({
        code: subCode.trim(),
        label: subLabel.trim() || (effectiveMaxDevices === 1 ? 'مشترك شخصي' : `اشتراك (${effectiveMaxDevices} أشخاص)`),
        expiresAt: dateInputToEndOfDayIso(subExpiryDate),
        maxDevices: effectiveMaxDevices,
        notes: subNotes.trim() || undefined,
      });
      setSubCode('');
      setSubLabel('');
      setSubNotes('');
      await loadOverview();
      await triggerSilentCloudBackup();
      notify(
        'ok',
        effectiveMaxDevices === 1
          ? 'تم إنشاء اشتراك لشخص واحد فقط (جهاز واحد) بنجاح!'
          : `تم إنشاء اشتراك لـ (${effectiveMaxDevices}) أشخاص / أجهزة بنجاح!`
      );
    } catch (err: any) {
      notify('err', err?.message || 'تعذر إنشاء الاشتراك.');
    } finally {
      setBusy(false);
    }
  };

  const handleUpdateSubscriptionExpiry = async (id: string) => {
    if (!editingExpiryDate) return;
    setBusy(true);
    try {
      await api.updateAccessCode(id, {
        expiresAt: dateInputToEndOfDayIso(editingExpiryDate),
        active: true,
      });
      setEditingExpiryId(null);
      await loadOverview();
      await triggerSilentCloudBackup();
      notify('ok', 'تم تحديث تاريخ انتهاء الاشتراك بنجاح.');
    } catch (err: any) {
      notify('err', err?.message || 'تعذر تحديث تاريخ الانتهاء.');
    } finally {
      setBusy(false);
    }
  };

  const handleUpdateSubscriptionMaxDevices = async (id: string) => {
    const cleanMax = Math.max(1, Math.min(1000, Math.floor(Number(editingMaxDevicesVal) || 1)));
    setBusy(true);
    try {
      await api.updateAccessCode(id, { maxDevices: cleanMax });
      setEditingMaxDevicesId(null);
      await loadOverview();
      await triggerSilentCloudBackup();
      notify(
        'ok',
        cleanMax === 1
          ? 'تم ضبط الاشتراك لشخص واحد فقط (جهاز واحد).'
          : `تم ضبط عدد الأشخاص المسموح لهم إلى (${cleanMax}) أجهزة.`
      );
    } catch (err: any) {
      notify('err', err?.message || 'تعذر تحديث عدد الأجهزة.');
    } finally {
      setBusy(false);
    }
  };

  const handleResetSubscriberDevices = async (id: string, deviceId?: string) => {
    setBusy(true);
    try {
      const res = await api.resetAccessCodeDevices(id, deviceId);
      setOverview((prev) => (prev ? { ...prev, accessCodes: res.accessCodes } : prev));
      await triggerSilentCloudBackup();
      notify(
        'ok',
        deviceId
          ? 'تم فصل الجهاز المحدد من الاشتراك بنجاح.'
          : 'تم تصفير جميع الأجهزة المرتبطة بهذا الاشتراك؛ يمكن للمشترك الدخول من جهازه الجديد.'
      );
    } catch (err: any) {
      notify('err', err?.message || 'تعذر فصل الأجهزة.');
    } finally {
      setBusy(false);
    }
  };

  const handleToggleSubscriptionActive = async (id: string, currentActive: boolean) => {
    setBusy(true);
    try {
      await api.updateAccessCode(id, { active: !currentActive });
      await loadOverview();
      await triggerSilentCloudBackup();
    } catch (err: any) {
      notify('err', err?.message || 'تعذر تغيير حالة الاشتراك.');
    } finally {
      setBusy(false);
    }
  };

  const handleToggleSecurityPolicy = async (
    field: keyof SecurityPolicyConfig,
    nextVal: boolean
  ) => {
    setPolicyBusyField(field);
    setFeedback(null);
    try {
      const res = await api.updateSecurityPolicy({ [field]: nextVal });
      setOverview((prev) =>
        prev
          ? {
              ...prev,
              securityPolicy: res.securityPolicy,
              securityEvents: res.securityEvents,
            }
          : prev
      );
      await onCatalogChanged();
      await triggerSilentCloudBackup();
      notify(
        'ok',
        nextVal ? 'تم تفعيل خيار الحماية وحفظه فوراً.' : 'تم إيقاف خيار الحماية وحفظ الإعداد.'
      );
    } catch (err: any) {
      notify('err', err?.message || 'تعذر تحديث إعدادات الحماية.');
    } finally {
      setPolicyBusyField(null);
    }
  };

  const handleToggleMaintenanceMode = async (nextActive: boolean) => {
    setMaintenanceBusy(true);
    setFeedback(null);
    const msgToSave =
      maintenanceMessageDraft.trim() || 'التطبيق في وضع الصيانة يرجى المحاولة لاحقاً';
    try {
      const res = await api.updateMaintenance({
        maintenanceMode: nextActive,
        maintenanceMessage: msgToSave,
      });
      setOverview((prev) =>
        prev
          ? {
              ...prev,
              maintenanceMode: res.maintenanceMode,
              maintenanceMessage: res.maintenanceMessage,
            }
          : prev
      );
      setMaintenanceMessageDraft(res.maintenanceMessage);
      await onCatalogChanged();
      await triggerSilentCloudBackup();
      notify(
        'ok',
        res.maintenanceMode
          ? 'تم إيقاف التطبيق وتفعيل وضع الصيانة للمستخدمين بنجاح! (حساب المدير مستثنى ويعمل بشكل طبيعي).'
          : 'تم إعادة تشغيل التطبيق وإلغاء وضع الصيانة لجميع المستخدمين بنجاح!'
      );
    } catch (err: any) {
      notify('err', err?.message || 'تعذر تغيير وضع الصيانة.');
    } finally {
      setMaintenanceBusy(false);
    }
  };

  const handleSaveMaintenanceMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    setMaintenanceBusy(true);
    setFeedback(null);
    const msgToSave =
      maintenanceMessageDraft.trim() || 'التطبيق في وضع الصيانة يرجى المحاولة لاحقاً';
    try {
      const res = await api.updateMaintenance({
        maintenanceMessage: msgToSave,
      });
      setOverview((prev) =>
        prev
          ? {
              ...prev,
              maintenanceMode: res.maintenanceMode,
              maintenanceMessage: res.maintenanceMessage,
            }
          : prev
      );
      setMaintenanceMessageDraft(res.maintenanceMessage);
      await onCatalogChanged();
      await triggerSilentCloudBackup();
      notify('ok', 'تم حفظ رسالة وضع الصيانة بنجاح.');
    } catch (err: any) {
      notify('err', err?.message || 'تعذر حفظ رسالة الصيانة.');
    } finally {
      setMaintenanceBusy(false);
    }
  };

  const handleSetAllSecurityPolicy = async (enableAll: boolean) => {
    setPolicyBusyField('ALL');
    setFeedback(null);
    try {
      const res = await api.updateSecurityPolicy({
        blockSniffers: enableAll,
        blockVpn: enableAll,
        strictStreamBinding: enableAll,
        blockDevTools: enableAll,
      });
      setOverview((prev) =>
        prev
          ? {
              ...prev,
              securityPolicy: res.securityPolicy,
              securityEvents: res.securityEvents,
            }
          : prev
      );
      await onCatalogChanged();
      await triggerSilentCloudBackup();
      notify(
        'ok',
        enableAll
          ? 'تم تشغيل الحماية القصوى (حظر HttpCanary + حظر VPN + تشفير البث المرتبط بالجهاز)!'
          : 'تم إيقاف جميع قيود الحماية والـ VPN مؤقتاً.'
      );
    } catch (err: any) {
      notify('err', err?.message || 'تعذر تحديث وضع الحماية.');
    } finally {
      setPolicyBusyField(null);
    }
  };

  const handleClearSecurityEvents = async () => {
    setBusy(true);
    try {
      const res = await api.clearSecurityEvents();
      setOverview((prev) => (prev ? { ...prev, securityEvents: res.securityEvents } : prev));
      notify('ok', 'تم مسح سجل محاولات السحب والحظر.');
    } catch (err: any) {
      notify('err', err?.message || 'تعذر مسح السجل.');
    } finally {
      setBusy(false);
    }
  };

  const handleSaveMasterAdminCode = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setFeedback(null);
    try {
      await api.updateAdminSecurity({
        newAdminCode: newAdminCode.trim(),
        dismissInitialHint: true,
      });
      await Promise.all([loadOverview(), onCatalogChanged()]);
      await triggerSilentCloudBackup();
      notify('ok', 'تم حفظ كود المدير السري الجديد بنجاح!');
    } catch (err: any) {
      notify('err', err?.message || 'تعذر حفظ كود المدير.');
    } finally {
      setBusy(false);
    }
  };

  const handleSaveTelegramCodeUrl = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setFeedback(null);
    try {
      await api.updateAdminSecurity({
        telegramCodeUrl: telegramCodeUrl.trim(),
      });
      await Promise.all([loadOverview(), onCatalogChanged()]);
      await triggerSilentCloudBackup();
      notify(
        'ok',
        telegramCodeUrl.trim()
          ? 'تم حفظ رابط التليجرام لزر "الحصول على كود عن طريق التليجرام" في واجهة الدخول!'
          : 'تم مسح الرابط المخصص (سيتم استخدام رابط التليجرام من المعرض تلقائياً إن وجد).'
      );
    } catch (err: any) {
      notify('err', err?.message || 'تعذر حفظ رابط التليجرام.');
    } finally {
      setBusy(false);
    }
  };

  // Source Refresh / Delete / Cloud Vault Sync
  const handleRefreshSource = async (id: string) => {
    setBusy(true);
    setFeedback(null);
    try {
      const res = await api.refreshSource(id);
      await Promise.all([loadOverview(), onCatalogChanged()]);
      await triggerSilentCloudBackup();
      notify('ok', `تمت مزامنة المصدر بنجاح (${res.addedCount} قناة) مع الاحتفاظ بتعديلاتك.`);
    } catch (err: any) {
      notify('err', err?.message || 'فشل تحديث المصدر.');
    } finally {
      setBusy(false);
    }
  };

  const handleDeleteSource = async (id: string) => {
    setBusy(true);
    setFeedback(null);
    try {
      await api.deleteSource(id);
      await Promise.all([loadOverview(), onCatalogChanged()]);
      await triggerSilentCloudBackup();
      notify('ok', 'تم حذف المصدر وجميع قنواته بنجاح.');
    } catch (err: any) {
      notify('err', err?.message || 'تعذر حذف المصدر.');
    } finally {
      setBusy(false);
    }
  };

  const handleManualCloudBackup = async () => {
    setCloudSyncing(true);
    setFeedback(null);
    try {
      if (!cloudUser) {
        await signInAdminForCloudVault();
      }
      const snap = await api.exportCloudSnapshot();
      const res = await saveEncryptedVaultToFirestore(snap);
      notify(
        'ok',
        `تم الحفظ السحابي المشفر في قاعدة بيانات Firebase (${snap.totalChannels} قناة في ${res.chunkCount} حزمة مشفرة)!`
      );
    } catch (err: any) {
      notify('err', err?.message || 'تعذر إجراء النسخ السحابي.');
    } finally {
      setCloudSyncing(false);
    }
  };

  const handleManualCloudRestore = async () => {
    setCloudSyncing(true);
    setFeedback(null);
    try {
      if (!cloudUser) {
        await signInAdminForCloudVault();
      }
      const vault = await loadEncryptedVaultFromFirestore();
      if (!vault || vault.chunks.length === 0) {
        notify('err', 'لا توجد نسخة احتياطية محفوظة في حسابك السحابي بعد.');
        return;
      }
      const restored = await api.importCloudSnapshot(vault.chunks);
      await Promise.all([loadOverview(), onCatalogChanged()]);
      notify(
        'ok',
        `تمت استعادة ${restored.restoredChannels} قناة من الحفظ السحابي بنجاح!`
      );
    } catch (err: any) {
      notify('err', err?.message || 'تعذر استعادة النسخة السحابية.');
    } finally {
      setCloudSyncing(false);
    }
  };

  const handleSaveApkSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    setApkSaving(true);
    setFeedback(null);
    try {
      const res = await api.updateApkSettings({
        apkServerUrl: apkServerUrlDraft.trim(),
        apkDownloadUrl: apkDownloadUrlDraft.trim(),
      });
      setApkServerUrlDraft(res.apkServerUrl || res.detectedServerUrl || '');
      setApkDownloadUrlDraft(res.apkDownloadUrl || '');
      await Promise.all([loadOverview(), onCatalogChanged()]);
      await triggerSilentCloudBackup();
      notify('ok', 'تم حفظ إعدادات تطبيق الأندرويد (APK) وتحديث ملف الربط بنجاح.');
    } catch (err: any) {
      notify('err', err?.message || 'تعذر حفظ إعدادات تطبيق الأندرويد.');
    } finally {
      setApkSaving(false);
    }
  };

  const handleCopyApkServerUrl = async () => {
    const val = (apkServerUrlDraft || overview?.detectedServerUrl || '').trim();
    if (!val) return;
    try {
      await navigator.clipboard.writeText(val);
      setCopiedApkServer(true);
      window.setTimeout(() => setCopiedApkServer(false), 2000);
    } catch {
      notify('err', 'تعذر نسخ الرابط تلقائياً، يمكنك نسخه يدوياً.');
    }
  };

  const orderedCategories = categories.length > 0 ? categories : overview?.categories || [];
  const filteredOrderedCategories = useMemo(() => {
    const q = catSearchQuery.trim().toLowerCase();
    if (!q) return orderedCategories;
    return orderedCategories.filter((c) => c.name.toLowerCase().includes(q));
  }, [orderedCategories, catSearchQuery]);

  const selectedCategoriesChannelSum = useMemo(() => {
    if (selectedCatNames.size === 0) return 0;
    let sum = 0;
    for (const c of orderedCategories) {
      if (selectedCatNames.has(c.name)) {
        sum += c.count;
      }
    }
    return sum;
  }, [orderedCategories, selectedCatNames]);

  const heroSlides = overview?.heroSlides || [];

  const tabs: Array<{ id: AdminTab; label: string; shortLabel: string; icon: React.ReactNode }> = [
    {
      id: 'm3u',
      label: 'إضافة M3U',
      shortLabel: 'إضافة M3U',
      icon: <Link2 className="w-3.5 h-3.5 shrink-0" />,
    },
    {
      id: 'xtream',
      label: 'إضافة Xtream',
      shortLabel: 'إضافة Xtream',
      icon: <Server className="w-3.5 h-3.5 shrink-0" />,
    },
    {
      id: 'direct',
      label: 'إضافة روابط',
      shortLabel: 'إضافة روابط',
      icon: <PlusCircle className="w-3.5 h-3.5 shrink-0" />,
    },
    {
      id: 'hero',
      label: 'صور المعرض والعروض',
      shortLabel: 'صور المعرض',
      icon: <ImageIcon className="w-3.5 h-3.5 shrink-0" />,
    },
    {
      id: 'categories',
      label: 'الأقسام وشعاراتها',
      shortLabel: 'الأقسام واللوجو',
      icon: <Layers className="w-3.5 h-3.5 shrink-0" />,
    },
    {
      id: 'channels',
      label: 'تعديل ونقل القنوات',
      shortLabel: 'تعديل القنوات',
      icon: <FolderCog className="w-3.5 h-3.5 shrink-0" />,
    },
    {
      id: 'protection',
      label: 'الحماية والـ VPN',
      shortLabel: 'الحماية وVPN',
      icon: <Shield className="w-3.5 h-3.5 shrink-0" />,
    },
    {
      id: 'security',
      label: 'الاشتراكات والأكواد',
      shortLabel: 'الاشتراكات',
      icon: <KeyRound className="w-3.5 h-3.5 shrink-0" />,
    },
    {
      id: 'sources',
      label: `المصادر والحفظ (${overview?.sources.length || 0})`,
      shortLabel: `المصادر (${overview?.sources.length || 0})`,
      icon: <Database className="w-3.5 h-3.5 shrink-0" />,
    },
    {
      id: 'apk',
      label: 'تطبيق الأندرويد (APK)',
      shortLabel: 'تطبيق الأندرويد APK',
      icon: <Smartphone className="w-3.5 h-3.5 shrink-0" />,
    },
  ];

  return (
    <div
      className="fixed inset-0 z-[60] bg-black/80 backdrop-blur-xs flex items-end sm:items-center justify-center p-0 sm:p-3 md:p-5"
      dir="rtl"
    >
      <div className="bg-[#0B1222] border-t sm:border border-[#1E325C] rounded-t-3xl sm:rounded-2xl w-full max-w-6xl h-[94dvh] sm:h-[92vh] pb-safe flex flex-col overflow-hidden shadow-2xl">
        {/* Mobile Drag Handle + Header */}
        <div className="shrink-0 border-b border-[#1B2947] bg-[#080F1E]">
          <div className="w-10 h-1.5 bg-slate-600 rounded-full mx-auto mt-2 sm:hidden" />
          <div className="flex items-center justify-between gap-2 px-3.5 sm:px-5 py-2.5 sm:py-3">
            <div className="min-w-0">
              <h2 className="text-sm sm:text-base font-extrabold text-white truncate">
                لوحة تحكم المدير — MS TV
              </h2>
              <p className="text-[10px] sm:text-xs text-emerald-400 mt-0.5 truncate">
                حماية مشددة ضد سرقة الروابط · حفظ تلقائي دائم للقنوات والاشتراكات
              </p>
            </div>

            <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
              {cloudSyncing && (
                <span className="hidden md:inline text-[11px] text-cyan-300 font-semibold animate-pulse">
                  جاري المزامنة السحابية...
                </span>
              )}
              <button
                type="button"
                onClick={() => {
                  setActiveTab('protection');
                  setFeedback(null);
                }}
                className={`min-h-[38px] px-2.5 sm:px-3 py-1.5 rounded-xl border text-[11px] sm:text-xs font-bold flex items-center gap-1.5 cursor-pointer whitespace-nowrap transition-colors ${
                  overview?.maintenanceMode
                    ? 'bg-amber-500/20 hover:bg-amber-500/30 border-amber-400/50 text-amber-300'
                    : 'bg-white/5 hover:bg-white/10 border-[#1E2E4F] text-slate-200'
                }`}
                title="إيقاف أو تشغيل التطبيق للمستخدمين (وضع الصيانة)"
              >
                <Wrench className="w-3.5 h-3.5 shrink-0" />
                <span className="sm:hidden">
                  {overview?.maintenanceMode ? 'الصيانة: مفعّل' : 'وضع الصيانة'}
                </span>
                <span className="hidden sm:inline">
                  {overview?.maintenanceMode ? 'وضع الصيانة: مفعّل' : 'إيقاف التطبيق / الصيانة'}
                </span>
              </button>
              <button
                type="button"
                onClick={() => {
                  onLockAdmin();
                  onClose();
                }}
                className="min-h-[38px] px-2.5 sm:px-3 py-1.5 rounded-xl bg-purple-500/15 hover:bg-purple-500/25 border border-purple-500/30 text-purple-300 text-[11px] sm:text-xs font-bold flex items-center gap-1.5 cursor-pointer whitespace-nowrap"
              >
                <Lock className="w-3.5 h-3.5" />
                <span className="sm:hidden">إخفاء المدير</span>
                <span className="hidden sm:inline">إخفاء وضع المدير</span>
              </button>
              <button
                type="button"
                onClick={onClose}
                className="min-h-[38px] min-w-[38px] rounded-xl text-slate-400 hover:text-white hover:bg-white/10 flex items-center justify-center cursor-pointer"
                aria-label="إغلاق"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>

        {/* Navigation Tabs — All Sections 100% Visible Simultaneously */}
        <div className="shrink-0 grid grid-cols-3 sm:flex sm:flex-wrap items-center gap-1 sm:gap-1.5 px-2.5 sm:px-5 py-2 border-b border-[#1B2947] bg-[#091020]">
          {tabs.map((t) => (
            <button
              key={t.id}
              type="button"
              onClick={() => {
                setActiveTab(t.id);
                setFeedback(null);
              }}
              className={`${
                t.id === 'apk' ? 'col-span-3 sm:col-span-1' : ''
              } min-h-[36px] px-1.5 sm:px-3 py-1.5 rounded-xl text-[11px] sm:text-xs font-bold flex items-center justify-center sm:justify-start gap-1 sm:gap-1.5 transition-colors cursor-pointer ${
                activeTab === t.id
                  ? 'bg-[#1268FB] text-white shadow-[0_3px_12px_rgba(18,104,251,0.35)]'
                  : t.id === 'apk'
                    ? 'bg-emerald-500/12 hover:bg-emerald-500/20 border border-emerald-500/30 text-emerald-300'
                    : 'bg-white/5 hover:bg-white/10 text-slate-300'
              }`}
            >
              {t.icon}
              <span className="sm:hidden truncate">{t.shortLabel}</span>
              <span className="hidden sm:inline whitespace-nowrap">{t.label}</span>
            </button>
          ))}
        </div>

        {/* Feedback Banner */}
        {feedback && (
          <div
            className={`shrink-0 mx-4 sm:mx-6 mt-3 p-3 rounded-xl border text-xs font-semibold flex items-center justify-between gap-2 ${
              feedback.type === 'ok'
                ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300'
                : 'bg-red-500/10 border-red-500/30 text-red-300'
            }`}
          >
            <div className="flex items-center gap-2 min-w-0">
              {feedback.type === 'ok' ? (
                <CheckCircle2 className="w-4 h-4 shrink-0" />
              ) : (
                <AlertCircle className="w-4 h-4 shrink-0" />
              )}
              <span className="leading-relaxed">{feedback.text}</span>
            </div>
            <button
              type="button"
              onClick={() => setFeedback(null)}
              className="min-h-[36px] min-w-[36px] text-slate-400 hover:text-white flex items-center justify-center shrink-0 cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        )}

        {/* Tab Body */}
        <div
          className={`flex-1 min-h-0 p-3.5 sm:p-5 ${
            activeTab === 'categories' || activeTab === 'channels'
              ? 'flex flex-col overflow-y-auto md:overflow-hidden overscroll-contain'
              : 'overflow-y-auto overscroll-contain'
          }`}
        >
          {/* TAB 1: ADD M3U */}
          {activeTab === 'm3u' && (
            <form onSubmit={handleAddM3u} className="max-w-2xl space-y-5">
              <div className="p-4 rounded-xl bg-blue-500/10 border border-blue-500/25 text-xs text-slate-200 leading-relaxed">
                عند إضافة رابط <strong className="text-white">M3U / M3U_PLUS</strong> أو رفع ملف، يتم <strong className="text-emerald-300">حفظ جميع القنوات والأقسام بشكل دائم تلقائياً</strong> في قاعدة بيانات السيرفر فلن تضطر لإدخال الرابط مرة أخرى أبداً، كما تُشفر الروابط بالكامل لمنع سرقتها.
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                  اسم الباقة (يظهر لك في الإدارة فقط)
                </label>
                <input
                  type="text"
                  value={m3uName}
                  onChange={(e) => setM3uName(e.target.value)}
                  placeholder="مثال: السيرفر الذهبي الرئيسي"
                  className="w-full px-4 py-2.5 rounded-xl bg-[#060B16] border border-[#1E2E4F] text-sm text-white focus:outline-none focus:border-blue-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                  رابط M3U المباشر (سري ومشفر — مخفي عن جميع المستخدمين)
                </label>
                <input
                  type="text"
                  dir="ltr"
                  spellCheck={false}
                  autoComplete="off"
                  value={m3uUrl}
                  onChange={(e) => setM3uUrl(e.target.value)}
                  placeholder="http://server.example.com:8080/get.php?username=...&password=...&type=m3u_plus"
                  className="w-full px-4 py-3 rounded-xl bg-[#060B16] border border-[#1E2E4F] text-xs font-mono text-cyan-300 focus:outline-none focus:border-blue-500"
                />
              </div>

              <div className="relative py-1 flex items-center justify-center">
                <div className="border-t border-[#1B2947] w-full" />
                <span className="bg-[#0B1222] px-3 text-xs text-slate-400 shrink-0">
                  أو ارفع ملف M3U / الصق محتواه مباشرة
                </span>
                <div className="border-t border-[#1B2947] w-full" />
              </div>

              <div className="flex flex-wrap items-center gap-2.5">
                <label className="min-h-[42px] px-4 py-2.5 rounded-xl bg-white/5 hover:bg-white/10 border border-[#1E2E4F] text-xs font-semibold text-slate-200 flex items-center gap-2 cursor-pointer">
                  <Upload className="w-4 h-4 text-blue-400 shrink-0" />
                  <span>{m3uFileName || 'اختيار ملف .m3u / .m3u8'}</span>
                  <input
                    type="file"
                    accept=".m3u,.m3u8,.txt"
                    onChange={handleFileUpload}
                    className="hidden"
                  />
                </label>

                <button
                  type="button"
                  onClick={() => setShowRawM3uBox((v) => !v)}
                  className="min-h-[42px] px-4 py-2.5 rounded-xl bg-white/5 hover:bg-white/10 border border-[#1E2E4F] text-xs font-semibold text-slate-200 flex items-center gap-2 cursor-pointer"
                >
                  <FileText className="w-4 h-4 text-cyan-400 shrink-0" />
                  <span>{showRawM3uBox ? 'إخفاء مربع اللصق النصي' : 'لصق محتوى #EXTM3U نصياً'}</span>
                </button>

                {(m3uFileName || m3uFileText) && (
                  <div className="flex items-center gap-2 text-xs text-emerald-400 font-semibold">
                    <span>جاهز للاستيراد ({Math.max(1, Math.round(m3uFileText.length / 1024))} KB)</span>
                    <button
                      type="button"
                      onClick={() => {
                        setM3uFileName('');
                        setM3uFileText('');
                      }}
                      className="p-1 rounded-lg bg-white/5 hover:bg-white/10 text-slate-300 cursor-pointer"
                      title="مسح الملف المحدد"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  </div>
                )}
              </div>

              {showRawM3uBox && (
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                    محتوى ملف M3U النصي
                  </label>
                  <textarea
                    rows={5}
                    dir="ltr"
                    spellCheck={false}
                    value={m3uFileText}
                    onChange={(e) => {
                      setM3uFileText(e.target.value);
                      if (m3uFileName) setM3uFileName('');
                    }}
                    placeholder={'#EXTM3U\n#EXTINF:-1 group-title="الرياضة",beIN Sports HD 1\nhttp://...'}
                    className="w-full p-3.5 rounded-xl bg-[#060B16] border border-[#1E2E4F] text-xs font-mono text-cyan-200 focus:outline-none focus:border-blue-500"
                  />
                </div>
              )}

              <button
                type="submit"
                disabled={busy}
                className="min-h-[44px] px-6 py-3 rounded-xl bg-blue-600 hover:bg-blue-500 disabled:opacity-60 text-white text-sm font-bold cursor-pointer"
              >
                {busy ? 'جاري استيراد وحفظ القنوات بشكل دائم...' : 'استيراد وحفظ القنوات نهائياً'}
              </button>
            </form>
          )}

          {/* TAB 2: ADD XTREAM CODES */}
          {activeTab === 'xtream' && (
            <form onSubmit={handleAddXtream} className="max-w-2xl space-y-4">
              <div className="p-4 rounded-xl bg-purple-500/10 border border-purple-500/25 text-xs text-slate-200 leading-relaxed">
                أدخل بيانات اشتراك <strong className="text-white">Xtream Codes API</strong> ليقوم السيرفر بجلب وحفظ جميع الأقسام والقنوات المباشرة والأفلام بشكل دائم وتشغيلها عبر تذاكر بث مشفرة دون كشف الهوست أو اليوزر للمشتركين.
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                    اسم السيرفر (اختياري)
                  </label>
                  <input
                    type="text"
                    value={xtName}
                    onChange={(e) => setXtName(e.target.value)}
                    placeholder="مثال: اشتراك إكستريم VIP"
                    className="w-full px-3.5 py-2.5 rounded-xl bg-[#060B16] border border-[#1E2E4F] text-sm text-white focus:outline-none focus:border-blue-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                    رابط الهوست / السيرفر (Server URL)
                  </label>
                  <input
                    type="text"
                    dir="ltr"
                    value={xtHost}
                    onChange={(e) => setXtHost(e.target.value)}
                    placeholder="http://line.server.com:8080"
                    className="w-full px-3.5 py-2.5 rounded-xl bg-[#060B16] border border-[#1E2E4F] text-xs font-mono text-cyan-300 focus:outline-none focus:border-blue-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                    اسم المستخدم (Username)
                  </label>
                  <input
                    type="text"
                    dir="ltr"
                    value={xtUser}
                    onChange={(e) => setXtUser(e.target.value)}
                    placeholder="Username"
                    className="w-full px-3.5 py-2.5 rounded-xl bg-[#060B16] border border-[#1E2E4F] text-xs font-mono text-white focus:outline-none focus:border-blue-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                    كلمة المرور (Password)
                  </label>
                  <input
                    type="password"
                    dir="ltr"
                    value={xtPass}
                    onChange={(e) => setXtPass(e.target.value)}
                    placeholder="••••••••"
                    className="w-full px-3.5 py-2.5 rounded-xl bg-[#060B16] border border-[#1E2E4F] text-xs font-mono text-white focus:outline-none focus:border-blue-500"
                  />
                </div>
              </div>

              <label className="flex items-center gap-2.5 text-xs text-slate-200 cursor-pointer select-none pt-1">
                <input
                  type="checkbox"
                  checked={xtIncludeVod}
                  onChange={(e) => setXtIncludeVod(e.target.checked)}
                  className="w-4 h-4 accent-blue-600 rounded"
                />
                <span>استيراد مكتبة الأفلام (VOD) بالإضافة إلى القنوات المباشرة</span>
              </label>

              <button
                type="submit"
                disabled={busy}
                className="px-6 py-3 rounded-xl bg-blue-600 hover:bg-blue-500 disabled:opacity-60 text-white text-sm font-bold cursor-pointer"
              >
                {busy ? 'جاري الاتصال وحفظ القنوات...' : 'اتصال واستيراد وحفظ باقة Xtream'}
              </button>
            </form>
          )}

          {/* TAB 3: ADD DIRECT STREAM LINKS */}
          {activeTab === 'direct' && (
            <form onSubmit={handleAddDirect} className="max-w-2xl space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                    اسم القناة أو الفيلم
                  </label>
                  <input
                    type="text"
                    value={dirName}
                    onChange={(e) => setDirName(e.target.value)}
                    placeholder="مثال: beIN Sports HD 1"
                    className="w-full px-3.5 py-2.5 rounded-xl bg-[#060B16] border border-[#1E2E4F] text-sm text-white focus:outline-none focus:border-blue-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                    القسم (اختر أو اكتب قسماً جديداً)
                  </label>
                  <input
                    type="text"
                    list="existing-groups-datalist"
                    value={dirGroup}
                    onChange={(e) => setDirGroup(e.target.value)}
                    placeholder="مثال: الرياضة"
                    className="w-full px-3.5 py-2.5 rounded-xl bg-[#060B16] border border-[#1E2E4F] text-sm text-white focus:outline-none focus:border-blue-500"
                  />
                  <datalist id="existing-groups-datalist">
                    {orderedCategories.map((c) => (
                      <option key={c.name} value={c.name} />
                    ))}
                  </datalist>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                  رابط البث المباشر (m3u8 / ts / mp4 — مشفر ومخفي عن المشتركين)
                </label>
                <input
                  type="text"
                  dir="ltr"
                  spellCheck={false}
                  value={dirUrl}
                  onChange={(e) => setDirUrl(e.target.value)}
                  placeholder="https://example.com/live/stream.m3u8"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-[#060B16] border border-[#1E2E4F] text-xs font-mono text-cyan-300 focus:outline-none focus:border-blue-500"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                    نوع المحتوى
                  </label>
                  <select
                    value={dirType}
                    onChange={(e) => setDirType(e.target.value as any)}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-[#060B16] border border-[#1E2E4F] text-sm text-white focus:outline-none focus:border-blue-500"
                  >
                    <option value="live">قناة بث مباشر</option>
                    <option value="movie">فيلم</option>
                    <option value="series">مسلسل</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                    رابط الشعار (اختياري)
                  </label>
                  <input
                    type="text"
                    dir="ltr"
                    spellCheck={false}
                    value={dirLogo}
                    onChange={(e) => setDirLogo(e.target.value)}
                    placeholder="https://..."
                    className="w-full px-3.5 py-2.5 rounded-xl bg-[#060B16] border border-[#1E2E4F] text-xs text-slate-200 focus:outline-none focus:border-blue-500"
                  />
                </div>
              </div>

              <button
                type="submit"
                disabled={busy}
                className="px-6 py-3 rounded-xl bg-blue-600 hover:bg-blue-500 disabled:opacity-60 text-white text-sm font-bold cursor-pointer"
              >
                {busy ? 'جاري الإضافة...' : 'إضافة وحفظ الرابط المباشر'}
              </button>
            </form>
          )}

          {/* TAB 4: HERO GALLERY / BANNER SLIDES CONTROL */}
          {activeTab === 'hero' && (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
              <form
                onSubmit={handleSaveHeroSlide}
                className="lg:col-span-7 p-4 sm:p-5 rounded-2xl bg-[#060B16] border border-[#1B2947] space-y-4"
              >
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div>
                    <h3 className="text-sm font-extrabold text-white">
                      {editingSlideId ? 'تعديل شريحة المعرض المحددة' : 'إضافة شريحة جديدة لصور المعرض'}
                    </h3>
                    <p className="text-[11px] text-slate-400 mt-0.5">
                      تحكم بالصورة، العنوان، نوع الزر (مثل: اشترك في التليجرام بدل مشاهدة الآن) والرابط
                    </p>
                  </div>
                  {editingSlideId && (
                    <button
                      type="button"
                      onClick={resetSlideForm}
                      className="min-h-[34px] px-3 py-1 rounded-xl bg-blue-500/15 hover:bg-blue-500/25 border border-blue-500/30 text-xs text-blue-300 font-bold cursor-pointer"
                    >
                      + إلغاء التعديل وإضافة شريحة جديدة
                    </button>
                  )}
                </div>

                {/* Quick 1-Click Templates */}
                <div className="p-3 rounded-xl bg-[#0B1222] border border-[#1E2E4F] space-y-2">
                  <div className="text-[11px] font-bold text-slate-300">
                    قوالب جاهزة بضغطة واحدة (يمكنك التعديل عليها بحرية):
                  </div>
                  <div className="flex flex-wrap gap-2">
                    <button
                      type="button"
                      onClick={applyTelegramSlideTemplate}
                      className="min-h-[36px] px-3 py-1.5 rounded-xl bg-[#229ED9]/20 hover:bg-[#229ED9]/30 border border-[#229ED9]/45 text-sky-200 text-xs font-bold flex items-center gap-1.5 cursor-pointer transition-colors"
                    >
                      <TelegramPaperPlaneIcon className="w-3.5 h-3.5 text-[#38BDF8]" />
                      <span>قالب: اشترك في قناة التليجرام</span>
                    </button>
                    <button
                      type="button"
                      onClick={applyVipPromoSlideTemplate}
                      className="min-h-[36px] px-3 py-1.5 rounded-xl bg-amber-500/15 hover:bg-amber-500/25 border border-amber-500/35 text-amber-200 text-xs font-bold flex items-center gap-1.5 cursor-pointer transition-colors"
                    >
                      <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                      <span>قالب: إعلان اشتراك / تواصل</span>
                    </button>
                    <button
                      type="button"
                      onClick={applyLiveMatchSlideTemplate}
                      className="min-h-[36px] px-3 py-1.5 rounded-xl bg-white/5 hover:bg-white/10 border border-[#1E2E4F] text-slate-200 text-xs font-bold flex items-center gap-1.5 cursor-pointer transition-colors"
                    >
                      <Play className="w-3.5 h-3.5 text-blue-400" />
                      <span>قالب: بث مباشر لقناة</span>
                    </button>
                  </div>
                </div>

                {/* Live WYSIWYG Banner Preview */}
                {(() => {
                  const previewIsTelegram = detectIsTelegramSlide({
                    themePreset: slideThemePreset,
                    externalUrl: slideExternalUrl,
                    title: slideTitle,
                    badge: slideBadge,
                    buttonText: slideButtonText,
                  });
                  const previewPreset: HeroThemePreset =
                    slideThemePreset || (previewIsTelegram ? 'telegram' : 'default');
                  const previewBtnLabel =
                    slideButtonText.trim() ||
                    (slideActionType === 'external_url'
                      ? previewIsTelegram
                        ? 'اشترك الآن'
                        : 'فتح الرابط'
                      : slideActionType === 'category'
                        ? 'تصفح القسم'
                        : 'مشاهدة الآن');

                  return (
                    <div className="relative h-44 rounded-2xl overflow-hidden border border-[#1E325C] bg-[#08132B] flex items-stretch select-none">
                      {slideImageUrl ? (
                        <img
                          src={slideImageUrl}
                          alt="معاينة الشريحة"
                          className="absolute inset-0 w-full h-full object-cover"
                        />
                      ) : (
                        <HeroPresetBackdrop preset={previewPreset} />
                      )}
                      <div className="absolute inset-0 bg-gradient-to-l from-[#040814]/92 via-[#071126]/70 to-[#040814]/25 pointer-events-none" />
                      <div className="relative z-10 flex-1 flex flex-col justify-between p-3.5">
                        <div className="flex items-center gap-2">
                          {slideShowLiveBadge ? (
                            <span className="inline-flex items-center gap-1 bg-[#EF233C] text-white text-[10px] font-bold px-2 py-0.5 rounded">
                              ▶ LIVE
                            </span>
                          ) : previewIsTelegram ? (
                            <span className="inline-flex items-center gap-1 bg-[#229ED9] text-white text-[10px] font-bold px-2 py-0.5 rounded">
                              <TelegramPaperPlaneIcon className="w-3 h-3" />
                              <span>TELEGRAM</span>
                            </span>
                          ) : previewPreset === 'promo' ? (
                            <span className="inline-flex items-center gap-1 bg-amber-500 text-slate-950 text-[10px] font-extrabold px-2 py-0.5 rounded">
                              VIP
                            </span>
                          ) : null}
                          {slideBadge.trim() && (
                            <span className="text-[11px] text-blue-100 font-bold px-2 py-0.5 rounded bg-black/35 border border-white/10 truncate max-w-[200px]">
                              {slideBadge}
                            </span>
                          )}
                        </div>

                        <div className="my-1">
                          <div className="text-sm sm:text-base font-extrabold text-white truncate">
                            {slideTitle || (slideImageUrl ? '' : 'اشترك في قناتنا على التليجرام')}
                          </div>
                          {slideSubtitle && (
                            <div className="text-[11px] text-slate-200 truncate mt-0.5">
                              {slideSubtitle}
                            </div>
                          )}
                        </div>

                        <div>
                          {slideActionType !== 'none' ? (
                            <span
                              className={`inline-flex items-center gap-1.5 px-4 py-1.5 rounded-full text-white text-xs font-bold shadow ${
                                slideActionType === 'external_url' && previewIsTelegram
                                  ? 'bg-gradient-to-r from-[#229ED9] to-[#0088CC]'
                                  : 'bg-gradient-to-r from-[#0D63F3] to-[#2575FC]'
                              }`}
                            >
                              {slideActionType === 'external_url' ? (
                                previewIsTelegram ? (
                                  <TelegramPaperPlaneIcon className="w-3.5 h-3.5" />
                                ) : (
                                  <ExternalLink className="w-3.5 h-3.5" />
                                )
                              ) : slideActionType === 'category' ? (
                                <Layers className="w-3.5 h-3.5" />
                              ) : (
                                <Play className="w-3.5 h-3.5 fill-white" />
                              )}
                              <span>{previewBtnLabel}</span>
                            </span>
                          ) : (
                            <span className="text-[11px] text-slate-400">بدون زر (عرض الصورة والنص فقط)</span>
                          )}
                        </div>
                      </div>
                    </div>
                  );
                })()}

                {/* Image Upload / URL / Built-in Backdrop Preset */}
                <div className="p-3.5 rounded-xl bg-[#0B1222] border border-[#1E2E4F] space-y-3">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <span className="text-xs font-bold text-white">1. صورة الخلفية للشريحة</span>
                    <div className="flex flex-wrap items-center gap-2">
                      <label className="min-h-[38px] px-3.5 py-1.5 rounded-xl bg-blue-600/20 hover:bg-blue-600/30 border border-blue-500/40 text-blue-300 text-xs font-bold flex items-center gap-1.5 cursor-pointer">
                        <Upload className="w-3.5 h-3.5" />
                        <span>رفع صورة من الجهاز</span>
                        <input
                          type="file"
                          accept="image/*"
                          onChange={handleBannerImageUpload}
                          className="hidden"
                        />
                      </label>
                      {slideImageUrl && (
                        <button
                          type="button"
                          onClick={() => setSlideImageUrl('')}
                          className="min-h-[38px] px-3 py-1.5 rounded-xl bg-red-500/15 hover:bg-red-500/25 text-xs text-red-300 font-semibold cursor-pointer"
                        >
                          إزالة الصورة المرفوعة
                        </button>
                      )}
                    </div>
                  </div>

                  <div>
                    <input
                      type="text"
                      dir="ltr"
                      value={slideImageUrl.startsWith('data:') ? '' : slideImageUrl}
                      onChange={(e) => setSlideImageUrl(e.target.value)}
                      placeholder="أو الصق رابط صورة مباشر https://example.com/banner.jpg"
                      className="w-full px-3.5 py-2 rounded-xl bg-[#060B16] border border-[#1E2E4F] text-xs font-mono text-cyan-300 focus:outline-none focus:border-blue-500"
                    />
                  </div>

                  {!slideImageUrl && (
                    <div className="flex flex-wrap items-center gap-2 pt-1">
                      <span className="text-[11px] text-slate-400">تصميم الخلفية التلقائية (عند عدم رفع صورة):</span>
                      {(
                        [
                          { id: 'telegram', label: 'خلفية تليجرام زرقاء' },
                          { id: 'default', label: 'خلفية رياضية' },
                          { id: 'promo', label: 'خلفية ذهبية VIP' },
                        ] as const
                      ).map((presetOpt) => (
                        <button
                          key={presetOpt.id}
                          type="button"
                          onClick={() => setSlideThemePreset(presetOpt.id)}
                          className={`px-2.5 py-1 rounded-lg text-[11px] font-bold border cursor-pointer transition-colors ${
                            slideThemePreset === presetOpt.id
                              ? 'bg-blue-600 border-blue-400 text-white'
                              : 'bg-white/5 border-white/10 text-slate-300 hover:bg-white/10'
                          }`}
                        >
                          {presetOpt.label}
                        </button>
                      ))}
                    </div>
                  )}
                </div>

                {/* Slide Texts & Badge */}
                <div className="p-3.5 rounded-xl bg-[#0B1222] border border-[#1E2E4F] space-y-3">
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-xs font-bold text-white">2. النصوص والشارة العلوية</span>
                    <label className="inline-flex items-center gap-2 text-[11px] text-slate-300 cursor-pointer select-none">
                      <input
                        type="checkbox"
                        checked={slideShowLiveBadge}
                        onChange={(e) => setSlideShowLiveBadge(e.target.checked)}
                        className="rounded accent-red-500 w-3.5 h-3.5"
                      />
                      <span>إظهار علامة LIVE الحمراء</span>
                    </label>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-[11px] font-semibold text-slate-300 mb-1">
                        العنوان الرئيسي
                      </label>
                      <input
                        type="text"
                        value={slideTitle}
                        onChange={(e) => setSlideTitle(e.target.value)}
                        placeholder="مثال: اشترك في قناة التليجرام"
                        className="w-full px-3.5 py-2 rounded-xl bg-[#060B16] border border-[#1E2E4F] text-xs text-white focus:outline-none focus:border-blue-500"
                      />
                    </div>
                    <div>
                      <label className="block text-[11px] font-semibold text-slate-300 mb-1">
                        نص الشارة العلوية (اختياري)
                      </label>
                      <input
                        type="text"
                        value={slideBadge}
                        onChange={(e) => setSlideBadge(e.target.value)}
                        placeholder="مثال: قناتنا الرسمية"
                        className="w-full px-3.5 py-2 rounded-xl bg-[#060B16] border border-[#1E2E4F] text-xs text-white focus:outline-none focus:border-blue-500"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-[11px] font-semibold text-slate-300 mb-1">
                      الوصف الفرعي (اختياري)
                    </label>
                    <input
                      type="text"
                      value={slideSubtitle}
                      onChange={(e) => setSlideSubtitle(e.target.value)}
                      placeholder="مثال: انضم لقناتنا على التليجرام لمتابعة أحدث القنوات والعروض"
                      className="w-full px-3.5 py-2 rounded-xl bg-[#060B16] border border-[#1E2E4F] text-xs text-white focus:outline-none focus:border-blue-500"
                    />
                  </div>
                </div>

                {/* CTA Button Action & Label Control */}
                <div className="p-3.5 rounded-xl bg-[#0B1222] border border-[#1E2E4F] space-y-3">
                  <span className="block text-xs font-bold text-white">
                    3. التحكم في زر الشريحة ووظيفته (بدل "مشاهدة الآن")
                  </span>

                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                    {(
                      [
                        { id: 'external_url', label: 'رابط تليجرام / خارجي' },
                        { id: 'watch_channel', label: 'تشغيل قناة' },
                        { id: 'category', label: 'فتح قسم قنوات' },
                        { id: 'none', label: 'بدون زر' },
                      ] as const
                    ).map((opt) => (
                      <button
                        key={opt.id}
                        type="button"
                        onClick={() => handleSelectSlideActionType(opt.id)}
                        className={`min-h-[38px] px-2.5 py-1.5 rounded-xl text-xs font-bold border transition-colors cursor-pointer ${
                          slideActionType === opt.id
                            ? 'bg-[#1268FB] border-blue-400 text-white'
                            : 'bg-[#060B16] border-[#1E2E4F] text-slate-300 hover:bg-white/5'
                        }`}
                      >
                        {opt.label}
                      </button>
                    ))}
                  </div>

                  {slideActionType !== 'none' && (
                    <div className="space-y-2">
                      <div>
                        <label className="block text-[11px] font-semibold text-slate-300 mb-1">
                          نص الزر الذي يظهر للمستخدمين
                        </label>
                        <input
                          type="text"
                          value={slideButtonText}
                          onChange={(e) => setSlideButtonText(e.target.value)}
                          placeholder="مثال: اشترك الآن"
                          className="w-full px-3.5 py-2 rounded-xl bg-[#060B16] border border-[#1E2E4F] text-xs text-white font-bold focus:outline-none focus:border-blue-500"
                        />
                      </div>

                      {/* Quick Button Text Chips */}
                      <div className="flex flex-wrap items-center gap-1.5">
                        <span className="text-[11px] text-slate-400">اختيار سريع لنص الزر:</span>
                        {[
                          'اشترك الآن',
                          'اشترك في التليجرام',
                          'انضم للقناة',
                          'تواصل للاشتراك',
                          'مشاهدة الآن',
                        ].map((presetLabel) => (
                          <button
                            key={presetLabel}
                            type="button"
                            onClick={() => setSlideButtonText(presetLabel)}
                            className={`px-2.5 py-1 rounded-lg text-[11px] font-semibold border cursor-pointer ${
                              slideButtonText === presetLabel
                                ? 'bg-sky-500/25 border-sky-400/50 text-sky-200'
                                : 'bg-white/5 border-white/10 text-slate-300 hover:bg-white/10'
                            }`}
                          >
                            {presetLabel}
                          </button>
                        ))}
                      </div>
                    </div>
                  )}

                  {slideActionType === 'external_url' && (
                    <div>
                      <label className="block text-[11px] font-semibold text-sky-300 mb-1">
                        رابط قناة التليجرام أو الرابط الخارجي *
                      </label>
                      <input
                        type="text"
                        dir="ltr"
                        spellCheck={false}
                        value={slideExternalUrl}
                        onChange={(e) => setSlideExternalUrl(e.target.value)}
                        placeholder="https://t.me/your_channel  أو  @your_channel"
                        className="w-full px-3.5 py-2.5 rounded-xl bg-[#060B16] border border-sky-500/40 text-xs font-mono text-sky-200 focus:outline-none focus:border-sky-400"
                      />
                      <p className="text-[11px] text-slate-400 mt-1">
                        يمكنك وضع رابط كامل مثل <span className="font-mono text-slate-300">https://t.me/...</span> أو معرف القناة مباشرة مثل <span className="font-mono text-slate-300">@channel</span> أو رابط واتساب.
                      </p>
                    </div>
                  )}

                  {slideActionType === 'watch_channel' && (
                    <div className="space-y-2">
                      <label className="block text-[11px] font-semibold text-slate-300">
                        القناة التي تشتغل عند الضغط على الزر
                      </label>
                      {channels.length > 40 && (
                        <input
                          type="text"
                          value={slideChannelFilter}
                          onChange={(e) => setSlideChannelFilter(e.target.value)}
                          placeholder="ابحث عن اسم القناة لربطها بالزر..."
                          className="w-full px-3 py-1.5 rounded-xl bg-[#060B16] border border-[#1E2E4F] text-xs text-white focus:outline-none focus:border-blue-500"
                        />
                      )}
                      <select
                        value={slideChannelId}
                        onChange={(e) => setSlideChannelId(e.target.value)}
                        className="w-full px-3.5 py-2 rounded-xl bg-[#060B16] border border-[#1E2E4F] text-xs text-white focus:outline-none focus:border-blue-500"
                      >
                        <option value="">تلقائي (أول قناة مميزة)</option>
                        {channels
                          .filter((ch) =>
                            !slideChannelFilter.trim()
                              ? true
                              : ch.name.toLowerCase().includes(slideChannelFilter.toLowerCase()) ||
                                ch.group.toLowerCase().includes(slideChannelFilter.toLowerCase())
                          )
                          .slice(0, 350)
                          .map((ch) => (
                            <option key={ch.id} value={ch.id}>
                              {ch.name} ({ch.group})
                            </option>
                          ))}
                      </select>
                    </div>
                  )}

                  {slideActionType === 'category' && (
                    <div>
                      <label className="block text-[11px] font-semibold text-slate-300 mb-1">
                        القسم الذي يفتح عند الضغط على الزر
                      </label>
                      <select
                        value={slideTargetCategory}
                        onChange={(e) => setSlideTargetCategory(e.target.value)}
                        className="w-full px-3.5 py-2 rounded-xl bg-[#060B16] border border-[#1E2E4F] text-xs text-white focus:outline-none focus:border-blue-500"
                      >
                        <option value="__ALL__">جميع القنوات</option>
                        {orderedCategories.map((cat) => (
                          <option key={cat.name} value={cat.name}>
                            {cat.name} ({cat.count})
                          </option>
                        ))}
                      </select>
                    </div>
                  )}
                </div>

                <button
                  type="submit"
                  disabled={busy}
                  className="w-full min-h-[46px] rounded-xl bg-gradient-to-r from-[#0D63F3] to-[#2575FC] hover:from-[#1B70FF] hover:to-[#3B82F6] disabled:opacity-60 text-white text-xs sm:text-sm font-extrabold shadow-lg cursor-pointer"
                >
                  {editingSlideId
                    ? 'حفظ التعديلات على شريحة المعرض'
                    : 'إضافة الشريحة إلى معرض الصفحة الرئيسية'}
                </button>
              </form>

              {/* Current Hero Slides List */}
              <div className="lg:col-span-5 p-4 sm:p-5 rounded-2xl bg-[#060B16] border border-[#1B2947] space-y-3">
                <div className="flex items-center justify-between gap-2">
                  <h3 className="text-sm font-extrabold text-white">
                    شرائح المعرض الحالية ({heroSlides.length})
                  </h3>
                  <span className="text-[11px] text-slate-400">
                    اضغط ✎ لتعديل أي شريحة
                  </span>
                </div>

                {heroSlides.length === 0 ? (
                  <p className="text-xs text-slate-400 py-8 text-center">
                    لا توجد شرائح مخصصة حالياً، استخدم القالب الجاهز على اليمين لإضافة شريحة التليجرام أو أي عرض جديد.
                  </p>
                ) : (
                  <div className="space-y-2.5 max-h-[600px] overflow-y-auto pr-0.5">
                    {heroSlides.map((slide, idx) => {
                      const effAction =
                        slide.actionType || (slide.externalUrl ? 'external_url' : 'watch_channel');
                      const isTg = detectIsTelegramSlide(slide);
                      const effBtnText =
                        slide.buttonText ||
                        (effAction === 'external_url'
                          ? 'اشترك الآن'
                          : effAction === 'category'
                            ? 'تصفح القسم'
                            : 'مشاهدة الآن');
                      const isBeingEdited = editingSlideId === slide.id;

                      return (
                        <div
                          key={slide.id}
                          className={`p-3 rounded-xl border flex flex-col gap-2.5 transition-colors ${
                            isBeingEdited
                              ? 'bg-blue-950/40 border-blue-500'
                              : slide.active
                                ? 'bg-[#0B1222] border-[#1E2E4F]'
                                : 'bg-[#0B1222]/50 border-white/5 opacity-60'
                          }`}
                        >
                          <div className="flex items-center justify-between gap-3">
                            <div className="flex items-center gap-3 min-w-0">
                              <div className="relative w-16 h-11 rounded-lg overflow-hidden bg-[#16233F] border border-white/10 shrink-0 flex items-center justify-center">
                                {slide.imageUrl ? (
                                  <img
                                    src={slide.imageUrl}
                                    alt={slide.title || 'شريحة'}
                                    className="w-full h-full object-cover"
                                  />
                                ) : isTg ? (
                                  <div className="w-full h-full bg-gradient-to-br from-[#07284A] to-[#229ED9] flex items-center justify-center text-white">
                                    <TelegramPaperPlaneIcon className="w-5 h-5" />
                                  </div>
                                ) : (
                                  <ImageIcon className="w-4 h-4 text-slate-400" />
                                )}
                              </div>
                              <div className="min-w-0">
                                <div className="text-xs font-bold text-white truncate">
                                  {slide.title || 'شريحة صورة بدون عنوان'}
                                </div>
                                <div className="flex flex-wrap items-center gap-1.5 mt-1">
                                  {effAction === 'external_url' ? (
                                    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded bg-sky-500/15 border border-sky-400/30 text-[10px] font-bold text-sky-300">
                                      {isTg ? (
                                        <TelegramPaperPlaneIcon className="w-2.5 h-2.5" />
                                      ) : (
                                        <ExternalLink className="w-2.5 h-2.5" />
                                      )}
                                      <span>زر: {effBtnText}</span>
                                    </span>
                                  ) : effAction === 'category' ? (
                                    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded bg-indigo-500/15 border border-indigo-400/30 text-[10px] font-bold text-indigo-300">
                                      <span>قسم: {effBtnText}</span>
                                    </span>
                                  ) : effAction === 'none' ? (
                                    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded bg-white/5 text-[10px] text-slate-400">
                                      بدون زر
                                    </span>
                                  ) : (
                                    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded bg-blue-500/15 border border-blue-400/30 text-[10px] font-bold text-blue-300">
                                      <span>زر: {effBtnText}</span>
                                    </span>
                                  )}
                                  <span className="text-[10px] text-slate-400">
                                    · {slide.active ? 'معروضة' : 'مخفية'}
                                  </span>
                                </div>
                              </div>
                            </div>

                            <div className="flex items-center gap-1 shrink-0">
                              <button
                                type="button"
                                disabled={busy || idx === 0}
                                onClick={() => handleMoveHeroSlide(slide.id, 'up')}
                                className="p-1.5 rounded-lg bg-white/5 hover:bg-white/15 disabled:opacity-30 text-slate-200 cursor-pointer"
                                title="تحريك للأعلى"
                              >
                                <ArrowUp className="w-3.5 h-3.5" />
                              </button>
                              <button
                                type="button"
                                disabled={busy || idx === heroSlides.length - 1}
                                onClick={() => handleMoveHeroSlide(slide.id, 'down')}
                                className="p-1.5 rounded-lg bg-white/5 hover:bg-white/15 disabled:opacity-30 text-slate-200 cursor-pointer"
                                title="تحريك للأسفل"
                              >
                                <ArrowDown className="w-3.5 h-3.5" />
                              </button>
                              <button
                                type="button"
                                onClick={() => handleToggleHeroSlide(slide)}
                                className="p-1.5 rounded-lg bg-white/5 hover:bg-white/15 text-slate-200 cursor-pointer"
                                title={slide.active ? 'إخفاء مؤقت' : 'إظهار'}
                              >
                                {slide.active ? (
                                  <Eye className="w-3.5 h-3.5 text-emerald-400" />
                                ) : (
                                  <EyeOff className="w-3.5 h-3.5 text-slate-400" />
                                )}
                              </button>
                              <button
                                type="button"
                                onClick={() => startEditSlide(slide)}
                                className="px-2 py-1.5 rounded-lg bg-blue-600/20 hover:bg-blue-600 text-blue-200 hover:text-white text-[11px] font-bold flex items-center gap-1 cursor-pointer"
                                title="تعديل الشريحة والزر"
                              >
                                <Edit3 className="w-3.5 h-3.5" />
                                <span>تعديل</span>
                              </button>
                              <button
                                type="button"
                                onClick={() => handleDeleteHeroSlide(slide.id)}
                                className="p-1.5 rounded-lg bg-red-500/15 hover:bg-red-500/30 text-red-300 cursor-pointer"
                                title="حذف الشريحة"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </div>

                          {effAction === 'external_url' && slide.externalUrl && (
                            <div
                              dir="ltr"
                              className="text-[11px] font-mono text-sky-300/90 bg-[#060B16] px-2.5 py-1 rounded-lg border border-white/5 truncate"
                            >
                              {slide.externalUrl}
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            </div>
          )}

          {/* TAB 5: REORDER CATEGORIES UP / DOWN, LOGOS, RENAME & DELETE UNWANTED CATEGORIES */}
          {activeTab === 'categories' && (
            <div className="max-w-4xl w-full md:h-full min-h-0 flex flex-col gap-3 md:overflow-hidden">
              <div className="shrink-0 p-3.5 sm:p-4 rounded-2xl bg-[#060B16] border border-[#1B2947] space-y-3">
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <div>
                    <h3 className="text-sm font-extrabold text-white">
                      إدارة أقسام القنوات — الترتيب، الشعارات، وحذف الأقسام غير المرغوبة
                    </h3>
                    <p className="text-xs text-slate-400 mt-0.5">
                      حدد أي أقسام لا تريدها واحذفها دفعة واحدة أو بشكل فردي مع خيار منع عودتها عند تحديث المصدر.
                    </p>
                  </div>

                  <div className="flex flex-wrap items-center gap-2 w-full sm:w-auto">
                    {newSectionLogo && (
                      <CategoryLogo name={newSectionName || 'قسم'} logo={newSectionLogo} size="sm" />
                    )}
                    <label
                      className="min-h-[40px] px-3 py-1.5 rounded-xl bg-white/5 hover:bg-white/10 border border-[#1E2E4F] text-xs font-semibold text-slate-200 flex items-center gap-1.5 cursor-pointer"
                      title="رفع شعار للقسم الجديد (اختياري)"
                    >
                      <ImageIcon className="w-3.5 h-3.5 text-cyan-400" />
                      <span>{newSectionLogo ? 'تغيير الشعار' : 'شعار'}</span>
                      <input
                        type="file"
                        accept="image/*"
                        onChange={handleNewSectionLogoUpload}
                        className="hidden"
                      />
                    </label>
                    <input
                      type="text"
                      value={newSectionName}
                      onChange={(e) => setNewSectionName(e.target.value)}
                      placeholder="اسم قسم جديد..."
                      className="flex-1 min-w-[130px] sm:w-40 min-h-[40px] px-3 py-1.5 rounded-xl bg-[#0B1222] border border-[#1E2E4F] text-xs text-white focus:outline-none focus:border-blue-500"
                    />
                    <button
                      type="button"
                      disabled={busy || !newSectionName.trim()}
                      onClick={handleCreateSection}
                      className="min-h-[40px] px-3.5 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-xs font-bold text-white cursor-pointer whitespace-nowrap"
                    >
                      + إنشاء قسم
                    </button>
                  </div>
                </div>

                {/* Search & Multi-Select Toolbar for Categories */}
                <div className="pt-2.5 border-t border-[#1B2947] flex flex-wrap items-center justify-between gap-2">
                  <div className="relative flex-1 min-w-[190px]">
                    <Search className="w-3.5 h-3.5 text-slate-400 absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                    <input
                      type="text"
                      value={catSearchQuery}
                      onChange={(e) => setCatSearchQuery(e.target.value)}
                      placeholder="ابحث عن قسم لتحديده أو حذفه أو تعديله..."
                      className="w-full min-h-[38px] pr-9 pl-8 py-1.5 rounded-xl bg-[#0B1222] border border-[#1E2E4F] focus:border-blue-500 text-xs text-white placeholder-slate-400 focus:outline-none"
                    />
                    {catSearchQuery && (
                      <button
                        type="button"
                        onClick={() => setCatSearchQuery('')}
                        className="absolute left-2 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white cursor-pointer"
                        aria-label="مسح البحث"
                      >
                        <X className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>

                  <div className="flex flex-wrap items-center gap-1.5">
                    <button
                      type="button"
                      disabled={filteredOrderedCategories.length === 0}
                      onClick={() => {
                        setSelectedCatNames((prev) => {
                          const next = new Set(prev);
                          for (const c of filteredOrderedCategories) next.add(c.name);
                          return next;
                        });
                      }}
                      className="min-h-[38px] px-3 py-1.5 rounded-xl bg-white/5 hover:bg-white/10 border border-[#1E2E4F] text-xs font-semibold text-slate-200 flex items-center gap-1.5 cursor-pointer disabled:opacity-40"
                    >
                      <CheckSquare className="w-3.5 h-3.5 text-blue-400" />
                      <span>
                        {catSearchQuery.trim()
                          ? `تحديد نتائج البحث (${filteredOrderedCategories.length})`
                          : 'تحديد الكل'}
                      </span>
                    </button>

                    {selectedCatNames.size > 0 && (
                      <button
                        type="button"
                        onClick={() => {
                          setSelectedCatNames(new Set());
                          setConfirmBulkDeleteCats(false);
                        }}
                        className="min-h-[38px] px-3 py-1.5 rounded-xl bg-white/5 hover:bg-white/10 text-xs font-semibold text-slate-300 cursor-pointer"
                      >
                        إلغاء التحديد ({selectedCatNames.size})
                      </button>
                    )}
                  </div>
                </div>

                {/* Bulk Delete Action Bar when categories are checked */}
                {selectedCatNames.size > 0 && (
                  <div className="p-3 rounded-xl bg-red-500/10 border border-red-500/30 space-y-2.5">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <div className="text-xs font-bold text-red-200">
                        تم تحديد{' '}
                        <span className="font-mono tabular-nums text-white">
                          {selectedCatNames.size}
                        </span>{' '}
                        قسم للحذف (تحتوي على{' '}
                        <span className="font-mono tabular-nums text-white">
                          {selectedCategoriesChannelSum}
                        </span>{' '}
                        قناة)
                      </div>

                      <label className="flex items-center gap-2 text-[11px] text-slate-200 cursor-pointer select-none">
                        <input
                          type="checkbox"
                          checked={blockFutureCatSync}
                          onChange={(e) => setBlockFutureCatSync(e.target.checked)}
                          className="w-4 h-4 rounded accent-red-500 cursor-pointer"
                        />
                        <span>منع عودة هذه الأقسام تلقائياً عند تحديث المصدر</span>
                      </label>
                    </div>

                    {!confirmBulkDeleteCats ? (
                      <div className="flex items-center justify-end gap-2">
                        <button
                          type="button"
                          disabled={busy}
                          onClick={() => setConfirmBulkDeleteCats(true)}
                          className="min-h-[38px] px-4 py-1.5 rounded-xl bg-red-600 hover:bg-red-500 disabled:opacity-50 text-white text-xs font-extrabold flex items-center gap-1.5 cursor-pointer"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                          <span>حذف الأقسام المحددة ({selectedCatNames.size})</span>
                        </button>
                      </div>
                    ) : (
                      <div className="pt-2 border-t border-red-500/25 flex flex-wrap items-center justify-between gap-2">
                        <span className="text-xs font-extrabold text-amber-200">
                          تأكيد نهائي: سيتم حذف {selectedCatNames.size} قسم وجميع قنواتها ({selectedCategoriesChannelSum} قناة). هل أنت متأكد؟
                        </span>
                        <div className="flex items-center gap-2">
                          <button
                            type="button"
                            onClick={() => setConfirmBulkDeleteCats(false)}
                            className="min-h-[36px] px-3 py-1.5 rounded-lg bg-white/10 hover:bg-white/15 text-slate-200 text-xs font-semibold cursor-pointer"
                          >
                            تراجع
                          </button>
                          <button
                            type="button"
                            disabled={busy}
                            onClick={() =>
                              handleDeleteCategoriesAction(Array.from(selectedCatNames))
                            }
                            className="min-h-[36px] px-4 py-1.5 rounded-lg bg-red-600 hover:bg-red-500 disabled:opacity-50 text-white text-xs font-extrabold cursor-pointer"
                          >
                            {busy ? 'جاري الحذف...' : 'نعم، تأكيد الحذف النهائي'}
                          </button>
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </div>

              <div className="flex-1 min-h-[240px] sm:min-h-0 rounded-2xl bg-[#060B16] border border-[#1B2947] divide-y divide-white/5 overflow-y-auto overscroll-contain">
                {filteredOrderedCategories.length === 0 ? (
                  <div className="p-8 text-center text-xs text-slate-400">
                    لا توجد أقسام مطابقة للبحث الحالي.
                  </div>
                ) : (
                  filteredOrderedCategories.map((cat) => {
                    const globalIdx = orderedCategories.findIndex((c) => c.name === cat.name);
                    const idx = globalIdx >= 0 ? globalIdx : 0;
                    const isEditingLogo = logoEditingCategory === cat.name;
                    const isSelected = selectedCatNames.has(cat.name);
                    const isConfirmingDelete = confirmDeleteSingleCat === cat.name;
                    const sampleLogos = sampleLogosByGroup.get(cat.name) || [];

                    return (
                      <div
                        key={cat.name}
                        className={`px-3.5 sm:px-4 py-3 space-y-3 transition-colors ${
                          isSelected ? 'bg-red-500/[0.06]' : 'hover:bg-white/[0.03]'
                        }`}
                      >
                        <div className="flex flex-wrap sm:flex-nowrap items-center justify-between gap-2.5 sm:gap-3">
                          <div className="flex items-center gap-2.5 sm:gap-3 min-w-0 flex-1">
                            <button
                              type="button"
                              onClick={() => {
                                setSelectedCatNames((prev) => {
                                  const next = new Set(prev);
                                  if (next.has(cat.name)) next.delete(cat.name);
                                  else next.add(cat.name);
                                  return next;
                                });
                              }}
                              className="min-h-[36px] min-w-[36px] rounded-lg hover:bg-white/10 flex items-center justify-center shrink-0 cursor-pointer"
                              title={isSelected ? 'إلغاء تحديد القسم' : 'تحديد القسم للحذف'}
                            >
                              {isSelected ? (
                                <CheckSquare className="w-4 h-4 text-red-400" />
                              ) : (
                                <Square className="w-4 h-4 text-slate-400" />
                              )}
                            </button>

                            <span className="w-7 h-7 rounded-lg bg-white/5 border border-white/10 text-slate-300 font-mono tabular-nums text-[11px] font-bold flex items-center justify-center shrink-0">
                              {idx + 1}
                            </span>

                            <CategoryLogo name={cat.name} logo={cat.logo} size="sm" />

                            {renamingCategory === cat.name ? (
                              <div className="flex flex-wrap sm:flex-nowrap items-center gap-1.5 flex-1 max-w-sm">
                                <input
                                  type="text"
                                  autoFocus
                                  value={renameValue}
                                  onChange={(e) => setRenameValue(e.target.value)}
                                  className="flex-1 min-w-[130px] min-h-[40px] px-3 py-1.5 rounded-lg bg-[#0B1222] border border-blue-500 text-xs text-white focus:outline-none"
                                />
                                <button
                                  type="button"
                                  onClick={() => handleRenameCategorySubmit(cat.name)}
                                  className="min-h-[40px] px-3 py-1.5 rounded-lg bg-emerald-600 text-white text-xs font-bold cursor-pointer"
                                >
                                  حفظ
                                </button>
                                <button
                                  type="button"
                                  onClick={() => setRenamingCategory(null)}
                                  className="min-h-[40px] px-2.5 py-1.5 rounded-lg bg-white/10 text-slate-300 text-xs cursor-pointer"
                                >
                                  إلغاء
                                </button>
                              </div>
                            ) : (
                              <div className="min-w-0">
                                <div className="text-xs sm:text-sm font-bold text-white truncate">
                                  {cat.name}
                                </div>
                                <div className="text-[11px] text-slate-400">
                                  {cat.count} قناة
                                  {cat.logo ? ' · شعار مخصص' : ''}
                                </div>
                              </div>
                            )}
                          </div>

                          <div className="flex items-center gap-1.5 shrink-0 mr-auto sm:mr-0">
                            <button
                              type="button"
                              onClick={() => {
                                if (isEditingLogo) {
                                  setLogoEditingCategory(null);
                                  setLogoDraftValue('');
                                } else {
                                  setRenamingCategory(null);
                                  setConfirmDeleteSingleCat(null);
                                  setLogoEditingCategory(cat.name);
                                  setLogoDraftValue(cat.logo || '');
                                }
                              }}
                              className={`min-h-[38px] px-2.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 cursor-pointer transition-colors ${
                                isEditingLogo
                                  ? 'bg-cyan-600 text-white'
                                  : 'bg-cyan-500/15 hover:bg-cyan-500/25 border border-cyan-500/30 text-cyan-300'
                              }`}
                              title="تعيين أو تعديل لوجو القسم"
                            >
                              <ImageIcon className="w-3.5 h-3.5" />
                              <span className="hidden sm:inline">اللوجو</span>
                            </button>

                            <button
                              type="button"
                              disabled={busy || idx === 0}
                              onClick={() => handleMoveCategory(cat.name, 'top')}
                              className="min-h-[38px] min-w-[38px] sm:min-w-0 px-2.5 rounded-lg bg-white/5 hover:bg-blue-600/30 disabled:opacity-25 text-slate-200 text-xs font-semibold flex items-center justify-center gap-1 cursor-pointer"
                              title="نقل إلى أول القائمة"
                            >
                              <ChevronsUp className="w-3.5 h-3.5" />
                              <span className="hidden sm:inline">للأول</span>
                            </button>

                            <button
                              type="button"
                              disabled={busy || idx === 0}
                              onClick={() => handleMoveCategory(cat.name, 'up')}
                              className="min-h-[38px] min-w-[38px] rounded-lg bg-white/10 hover:bg-blue-600 disabled:opacity-25 text-white flex items-center justify-center cursor-pointer"
                              title="تحريك للأعلى"
                            >
                              <ArrowUp className="w-4 h-4" />
                            </button>

                            <button
                              type="button"
                              disabled={busy || idx === orderedCategories.length - 1}
                              onClick={() => handleMoveCategory(cat.name, 'down')}
                              className="min-h-[38px] min-w-[38px] rounded-lg bg-white/10 hover:bg-blue-600 disabled:opacity-25 text-white flex items-center justify-center cursor-pointer"
                              title="تحريك للأسفل"
                            >
                              <ArrowDown className="w-4 h-4" />
                            </button>

                            <button
                              type="button"
                              onClick={() => {
                                setLogoEditingCategory(null);
                                setConfirmDeleteSingleCat(null);
                                setRenamingCategory(cat.name);
                                setRenameValue(cat.name);
                              }}
                              className="min-h-[38px] min-w-[38px] rounded-lg bg-white/5 hover:bg-white/15 text-slate-300 text-xs flex items-center justify-center cursor-pointer"
                              title="تغيير اسم القسم"
                            >
                              <Edit3 className="w-3.5 h-3.5" />
                            </button>

                            <button
                              type="button"
                              disabled={busy}
                              onClick={() => {
                                setLogoEditingCategory(null);
                                setRenamingCategory(null);
                                setConfirmDeleteSingleCat((prev) =>
                                  prev === cat.name ? null : cat.name
                                );
                              }}
                              className={`min-h-[38px] px-2.5 rounded-lg text-xs font-bold flex items-center justify-center gap-1 cursor-pointer transition-colors ${
                                isConfirmingDelete
                                  ? 'bg-red-600 text-white'
                                  : 'bg-red-500/15 hover:bg-red-500/30 border border-red-500/30 text-red-300'
                              }`}
                              title="حذف هذا القسم وجميع قنواته"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                              <span className="hidden md:inline">حذف</span>
                            </button>
                          </div>
                        </div>

                        {isConfirmingDelete && (
                          <div className="p-3 rounded-xl bg-red-500/10 border border-red-500/30 flex flex-wrap items-center justify-between gap-2.5">
                            <div className="space-y-1">
                              <div className="text-xs font-extrabold text-red-200">
                                هل تريد حذف قسم «{cat.name}» مع جميع قنواته ({cat.count} قناة)؟
                              </div>
                              <label className="flex items-center gap-2 text-[11px] text-slate-300 cursor-pointer select-none">
                                <input
                                  type="checkbox"
                                  checked={blockFutureCatSync}
                                  onChange={(e) => setBlockFutureCatSync(e.target.checked)}
                                  className="w-3.5 h-3.5 rounded accent-red-500 cursor-pointer"
                                />
                                <span>منع عودة هذا القسم تلقائياً عند تحديث المصدر (M3U / Xtream)</span>
                              </label>
                            </div>
                            <div className="flex items-center gap-2">
                              <button
                                type="button"
                                onClick={() => setConfirmDeleteSingleCat(null)}
                                className="min-h-[36px] px-3 py-1.5 rounded-lg bg-white/10 hover:bg-white/15 text-slate-200 text-xs font-semibold cursor-pointer"
                              >
                                إلغاء
                              </button>
                              <button
                                type="button"
                                disabled={busy}
                                onClick={() => handleDeleteCategoriesAction([cat.name])}
                                className="min-h-[36px] px-3.5 py-1.5 rounded-lg bg-red-600 hover:bg-red-500 disabled:opacity-50 text-white text-xs font-extrabold cursor-pointer"
                              >
                                {busy ? 'جاري الحذف...' : 'تأكيد حذف القسم'}
                              </button>
                            </div>
                          </div>
                        )}

                        {isEditingLogo && (
                          <div className="p-3.5 rounded-xl bg-[#0B1222] border border-[#1E325C] space-y-3">
                            <div className="flex flex-wrap items-center gap-3">
                              <CategoryLogo name={cat.name} logo={logoDraftValue} size="md" />

                              <label className="min-h-[38px] px-3.5 py-2 rounded-xl bg-white/10 hover:bg-white/15 border border-white/15 text-xs font-bold text-white flex items-center gap-1.5 cursor-pointer shrink-0">
                                <Upload className="w-3.5 h-3.5 text-cyan-400" />
                                <span>رفع صورة لوجو من الجهاز</span>
                                <input
                                  type="file"
                                  accept="image/*"
                                  onChange={handleCategoryLogoFileUpload}
                                  className="hidden"
                                />
                              </label>

                              <input
                                type="text"
                                dir="ltr"
                                value={logoDraftValue.startsWith('data:') ? '' : logoDraftValue}
                                onChange={(e) => setLogoDraftValue(e.target.value)}
                                placeholder="https://example.com/category-logo.png أو ارفع صورة..."
                                className="flex-1 min-w-[200px] px-3 py-2 rounded-xl bg-[#060B16] border border-[#1E2E4F] text-xs font-mono text-cyan-300 focus:outline-none focus:border-blue-500"
                              />
                            </div>

                            {sampleLogos.length > 0 && (
                              <div className="space-y-1.5">
                                <div className="text-[11px] text-slate-400">
                                  أو اختر بضغطة واحدة من شعارات قنوات هذا القسم:
                                </div>
                                <div className="flex flex-wrap items-center gap-2">
                                  {sampleLogos.map((sampleUrl) => (
                                    <button
                                      key={sampleUrl}
                                      type="button"
                                      onClick={() => setLogoDraftValue(sampleUrl)}
                                      className={`w-10 h-10 rounded-xl p-1 bg-[#060B16] border transition-all cursor-pointer ${
                                        logoDraftValue === sampleUrl
                                          ? 'border-cyan-400 ring-2 ring-cyan-400/30'
                                          : 'border-white/10 hover:border-white/30'
                                      }`}
                                      title="اختيار هذا الشعار للقسم"
                                    >
                                      <img
                                        src={sampleUrl}
                                        alt=""
                                        referrerPolicy="no-referrer"
                                        className="w-full h-full object-contain"
                                      />
                                    </button>
                                  ))}
                                </div>
                              </div>
                            )}

                            <div className="flex flex-wrap items-center justify-end gap-2 pt-1">
                              {(cat.logo || logoDraftValue) && (
                                <button
                                  type="button"
                                  disabled={busy}
                                  onClick={() => handleSaveCategoryLogo(cat.name, '')}
                                  className="min-h-[36px] px-3 py-1.5 rounded-lg bg-red-500/15 hover:bg-red-500/25 text-red-300 text-xs font-semibold cursor-pointer"
                                >
                                  استعادة الشعار التلقائي
                                </button>
                              )}
                              <button
                                type="button"
                                onClick={() => {
                                  setLogoEditingCategory(null);
                                  setLogoDraftValue('');
                                }}
                                className="min-h-[36px] px-3 py-1.5 rounded-lg bg-white/10 hover:bg-white/15 text-slate-300 text-xs font-semibold cursor-pointer"
                              >
                                إلغاء
                              </button>
                              <button
                                type="button"
                                disabled={busy}
                                onClick={() => handleSaveCategoryLogo(cat.name, logoDraftValue)}
                                className="min-h-[36px] px-4 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white text-xs font-bold cursor-pointer"
                              >
                                حفظ الشعار
                              </button>
                            </div>
                          </div>
                        )}
                      </div>
                    );
                  })
                )}
              </div>

              {/* Excluded / Blocked Categories Recovery Strip */}
              {(overview?.excludedCategories?.length || 0) > 0 && (
                <div className="shrink-0 p-3 rounded-2xl bg-[#060B16] border border-[#1B2947] space-y-2.5">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <button
                      type="button"
                      onClick={() => setShowExcludedCatsPanel((v) => !v)}
                      className="text-xs font-bold text-slate-300 hover:text-white flex items-center gap-2 cursor-pointer"
                    >
                      <RotateCcw className="w-3.5 h-3.5 text-amber-400" />
                      <span>
                        الأقسام المحذوفة والمحظورة من التحديث التلقائي (
                        {overview?.excludedCategories?.length || 0})
                      </span>
                      <span className="text-[11px] text-blue-400">
                        {showExcludedCatsPanel ? 'إخفاء' : 'عرض وإدارة'}
                      </span>
                    </button>

                    <button
                      type="button"
                      disabled={busy}
                      onClick={() => handleRestoreExcludedCategories(['__ALL__'])}
                      className="min-h-[32px] px-2.5 py-1 rounded-lg bg-white/5 hover:bg-white/10 text-[11px] font-semibold text-amber-300 cursor-pointer"
                    >
                      إلغاء حظر الكل
                    </button>
                  </div>

                  {showExcludedCatsPanel && (
                    <div className="max-h-32 overflow-y-auto overscroll-contain flex flex-wrap gap-1.5 pt-2 border-t border-white/5">
                      {(overview?.excludedCategories || []).map((exName) => (
                        <div
                          key={exName}
                          className="px-2.5 py-1 rounded-lg bg-[#0B1222] border border-[#1E2E4F] text-[11px] text-slate-200 flex items-center gap-2"
                        >
                          <span className="truncate max-w-[180px]">{exName}</span>
                          <button
                            type="button"
                            disabled={busy}
                            onClick={() => handleRestoreExcludedCategories([exName])}
                            className="text-emerald-400 hover:text-emerald-300 font-bold cursor-pointer"
                            title="إلغاء الحظر ليعود القسم عند مزامنة المصدر"
                          >
                            استعادة
                          </button>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}
            </div>
          )}

          {/* TAB 6: CHANNEL RENAME & BULK MOVE TO ANOTHER SECTION */}
          {activeTab === 'channels' && (
            <div className="w-full md:h-full min-h-0 flex flex-col gap-3.5 md:overflow-hidden">
              <div className="shrink-0 p-3.5 sm:p-4 rounded-2xl bg-[#060B16] border border-[#1B2947]">
                <label className="text-xs font-semibold text-slate-300 flex items-center gap-1.5 mb-2">
                  <FolderInput className="w-3.5 h-3.5 text-blue-400" />
                  <span>نقل القنوات المحددة ({selectedChIds.size}) دفعة واحدة إلى قسم آخر</span>
                </label>
                <div className="flex flex-wrap items-center gap-2">
                  <input
                    type="text"
                    list="admin-bulk-groups"
                    value={bulkTargetGroup}
                    onChange={(e) => setBulkTargetGroup(e.target.value)}
                    placeholder="اختر أو اكتب اسم القسم الهدف..."
                    className="flex-1 min-w-[180px] min-h-[42px] px-3 py-2 rounded-xl bg-[#0B1222] border border-[#1E2E4F] text-xs text-white focus:outline-none focus:border-blue-500"
                  />
                  <datalist id="admin-bulk-groups">
                    {orderedCategories.map((c) => (
                      <option key={c.name} value={c.name} />
                    ))}
                  </datalist>
                  <button
                    type="button"
                    disabled={busy || selectedChIds.size === 0 || !bulkTargetGroup.trim()}
                    onClick={handleBulkMove}
                    className="min-h-[42px] px-5 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-xs font-bold text-white cursor-pointer whitespace-nowrap"
                  >
                    نقل القنوات المحددة
                  </button>
                </div>
              </div>

              <div className="shrink-0 flex flex-wrap items-center gap-2">
                <div className="relative flex-1 min-w-[180px]">
                  <Search className="w-4 h-4 text-slate-400 absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                  <input
                    type="text"
                    value={chSearch}
                    onChange={(e) => setChSearch(e.target.value)}
                    placeholder="ابحث عن قناة لتعديل اسمها أو نقلها..."
                    className="w-full min-h-[42px] pr-9 pl-3 py-2 rounded-xl bg-[#060B16] border border-[#1E2E4F] text-xs text-white focus:outline-none focus:border-blue-500"
                  />
                </div>
                <select
                  value={chGroupFilter}
                  onChange={(e) => setChGroupFilter(e.target.value)}
                  className="min-h-[42px] max-w-full sm:max-w-[220px] px-3 py-2 rounded-xl bg-[#060B16] border border-[#1E2E4F] text-xs text-slate-200 focus:outline-none focus:border-blue-500"
                >
                  <option value="ALL">جميع الأقسام ({channels.length})</option>
                  {orderedCategories.map((c) => (
                    <option key={c.name} value={c.name}>
                      {c.name} ({c.count})
                    </option>
                  ))}
                </select>
              </div>

              <div className="flex-1 min-h-[260px] sm:min-h-0 rounded-2xl bg-[#060B16] border border-[#1B2947] divide-y divide-white/5 overflow-y-auto overscroll-contain">
                {filteredChannels.slice(0, 250).map((ch) => {
                  const checked = selectedChIds.has(ch.id);
                  return (
                    <div
                      key={ch.id}
                      className="min-h-[56px] px-3.5 sm:px-4 py-2.5 flex items-center justify-between gap-2.5 sm:gap-3 hover:bg-white/5"
                    >
                      <label className="flex items-center gap-2.5 sm:gap-3 min-w-0 flex-1 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={checked}
                          onChange={() =>
                            setSelectedChIds((prev) => {
                              const next = new Set(prev);
                              if (next.has(ch.id)) next.delete(ch.id);
                              else next.add(ch.id);
                              return next;
                            })
                          }
                          className="w-4 h-4 accent-blue-600 rounded shrink-0 cursor-pointer"
                        />
                        <ChannelLogo name={ch.name} logo={ch.logo} group={ch.group} size="sm" />
                        <div className="min-w-0">
                          <div className="text-xs font-bold text-white truncate">{ch.name}</div>
                          <div className="text-[11px] text-slate-400 truncate">
                            القسم الحالي: <span className="text-blue-300">{ch.group}</span>
                          </div>
                        </div>
                      </label>

                      <button
                        type="button"
                        onClick={() => onOpenChannelEdit(ch)}
                        className="min-h-[40px] px-3 py-1.5 rounded-xl bg-white/5 hover:bg-blue-600 text-xs font-semibold text-slate-200 hover:text-white flex items-center gap-1.5 shrink-0 transition-colors cursor-pointer"
                      >
                        <Edit3 className="w-3.5 h-3.5" />
                        <span className="hidden sm:inline">تعديل / نقل</span>
                        <span className="sm:hidden">تعديل</span>
                      </button>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* TAB 7: ANTI-HTTPCANARY, ANTI-VPN & STRONG STREAM PROTECTION */}
          {activeTab === 'protection' && (
            <div className="space-y-5">
              {/* Top Shield Control Bar */}
              {(() => {
                const pol = overview?.securityPolicy || {
                  blockSniffers: true,
                  blockVpn: true,
                  blockDevTools: true,
                  strictStreamBinding: true,
                };
                const enabledCount = [
                  pol.blockSniffers,
                  pol.blockVpn,
                  pol.strictStreamBinding,
                  pol.blockDevTools,
                ].filter(Boolean).length;

                const protectionItems: Array<{
                  key: keyof SecurityPolicyConfig;
                  title: string;
                  desc: string;
                  icon: React.ReactNode;
                  enabled: boolean;
                }> = [
                  {
                    key: 'blockSniffers',
                    title: 'منع HttpCanary وبرامج سحب روابط البث',
                    desc: 'يحظر فوراً تطبيقات التقاط الحزم وسحب الروابط مثل HttpCanary و Reqable و PCAPdroid و PacketCapture و Charles و Burp ومشغلات السحب الخارجية (VLC / FFmpeg / Python / okhttp).',
                    icon: <ShieldAlert className="w-5 h-5 text-red-400" />,
                    enabled: pol.blockSniffers,
                  },
                  {
                    key: 'blockVpn',
                    title: 'حظر تطبيقات VPN والبروكسي وكاسر البروكسي',
                    desc: 'يكشف ويحظر اتصالات الـ VPN وعناوين السيرفرات السحابية (Datacenter / Proxy / Tor) ويمنع تشغيل القنوات حتى يقوم المستخدم بإيقاف تطبيق الـ VPN.',
                    icon: <WifiOff className="w-5 h-5 text-amber-400" />,
                    enabled: pol.blockVpn,
                  },
                  {
                    key: 'strictStreamBinding',
                    title: 'تشفير البث المؤقت وربطه ببصمة الجهاز والـ IP',
                    desc: 'يربط تذكرة البث وقطع الفيديو المشفرة ببصمة جهاز المشترك وعنوان شبكته مع نبضة تحقق كل 38 ثانية؛ أي رابط يتم نسخه يتوقف فوراً خارج التطبيق.',
                    icon: <ShieldCheck className="w-5 h-5 text-emerald-400" />,
                    enabled: pol.strictStreamBinding,
                  },
                  {
                    key: 'blockDevTools',
                    title: 'منع فحص الشبكة وأدوات المطورين (Anti-DevTools)',
                    desc: 'يمنع اختصارات فتح فحص الشبكة والمصدر (F12 / Inspect) والنقر الأيمن وحقن السكربتات لدى المشتركين (مع استثناء حساب المدير تلقائياً).',
                    icon: <Lock className="w-5 h-5 text-blue-400" />,
                    enabled: pol.blockDevTools,
                  },
                ];

                const isMaintActive = Boolean(overview?.maintenanceMode);

                return (
                  <>
                    {/* App Maintenance / Pause Switch Card */}
                    <div
                      className={`p-4 sm:p-5 rounded-2xl bg-[#060B16] border space-y-4 transition-colors ${
                        isMaintActive ? 'border-amber-400/50' : 'border-[#1B2947]'
                      }`}
                    >
                      <div className="flex flex-wrap items-center justify-between gap-4">
                        <div className="flex items-start gap-3 min-w-0 flex-1">
                          <div
                            className={`w-11 h-11 rounded-xl border flex items-center justify-center shrink-0 ${
                              isMaintActive
                                ? 'bg-amber-500/15 border-amber-400/40 text-amber-400'
                                : 'bg-[#0B1222] border-[#1E2E4F] text-slate-300'
                            }`}
                          >
                            <Wrench className="w-5 h-5" />
                          </div>
                          <div className="space-y-1 min-w-0">
                            <div className="flex flex-wrap items-center gap-2">
                              <h3 className="text-sm sm:text-base font-extrabold text-white">
                                إيقاف التطبيق مؤقتاً (وضع الصيانة للمستخدمين)
                              </h3>
                              <span
                                className={`text-xs font-bold ${
                                  isMaintActive ? 'text-amber-300' : 'text-emerald-400'
                                }`}
                              >
                                · {isMaintActive ? 'متوقف للصيانة حالياً' : 'التطبيق يعمل للمستخدمين'}
                              </span>
                            </div>
                            <p className="text-xs text-slate-400 leading-relaxed max-w-2xl">
                              عند تفعيل وضع الصيانة يتم إيقاف القنوات والتطبيق فوراً لدى جميع المشتركين وتظهر لهم شاشة الصيانة، بينما يبقى حسابك كمدير يعمل بشكل كامل لإدارة التطبيق.
                            </p>
                          </div>
                        </div>

                        <button
                          type="button"
                          disabled={maintenanceBusy}
                          onClick={() => handleToggleMaintenanceMode(!isMaintActive)}
                          className={`min-h-[44px] px-5 py-2.5 rounded-xl text-xs sm:text-sm font-extrabold flex items-center justify-center gap-2 cursor-pointer transition-colors disabled:opacity-60 shrink-0 ${
                            isMaintActive
                              ? 'bg-emerald-600 hover:bg-emerald-500 text-white'
                              : 'bg-amber-500 hover:bg-amber-400 text-slate-950'
                          }`}
                        >
                          <Power className="w-4 h-4" />
                          <span>
                            {maintenanceBusy
                              ? 'جاري التنفيذ...'
                              : isMaintActive
                                ? 'تشغيل التطبيق وإنهاء الصيانة'
                                : 'إيقاف التطبيق (تفعيل وضع الصيانة)'}
                          </span>
                        </button>
                      </div>

                      <form
                        onSubmit={handleSaveMaintenanceMessage}
                        className="pt-3.5 border-t border-[#1B2947] space-y-2"
                      >
                        <div className="flex flex-wrap items-center justify-between gap-2">
                          <label className="text-xs font-semibold text-slate-300">
                            رسالة الصيانة التي تظهر للمستخدمين على الشاشة:
                          </label>
                          {maintenanceMessageDraft.trim() !==
                            'التطبيق في وضع الصيانة يرجى المحاولة لاحقاً' && (
                            <button
                              type="button"
                              onClick={() =>
                                setMaintenanceMessageDraft(
                                  'التطبيق في وضع الصيانة يرجى المحاولة لاحقاً'
                                )
                              }
                              className="text-[11px] font-semibold text-blue-400 hover:text-blue-300 cursor-pointer"
                            >
                              استعادة الرسالة الافتراضية
                            </button>
                          )}
                        </div>
                        <div className="flex flex-wrap sm:flex-nowrap items-center gap-2">
                          <input
                            type="text"
                            value={maintenanceMessageDraft}
                            onChange={(e) => setMaintenanceMessageDraft(e.target.value)}
                            placeholder="التطبيق في وضع الصيانة يرجى المحاولة لاحقاً"
                            className="flex-1 min-w-[200px] min-h-[42px] px-3.5 py-2 rounded-xl bg-[#0B1222] border border-[#1E2E4F] focus:border-amber-400 text-xs text-white focus:outline-none"
                          />
                          <button
                            type="submit"
                            disabled={maintenanceBusy}
                            className="min-h-[42px] px-4 py-2 rounded-xl bg-white/10 hover:bg-white/15 disabled:opacity-50 text-xs font-bold text-white cursor-pointer whitespace-nowrap"
                          >
                            حفظ نص الرسالة
                          </button>
                        </div>
                      </form>
                    </div>

                    <div className="p-4 sm:p-5 rounded-2xl bg-[#060B16] border border-[#1B2947] flex flex-wrap items-center justify-between gap-4">
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <Shield className="w-5 h-5 text-emerald-400 shrink-0" />
                          <h3 className="text-sm sm:text-base font-extrabold text-white">
                            مركز الحماية القوية ضد سحب الروابط وتطبيقات الـ VPN
                          </h3>
                          <span
                            className={`px-2 py-0.5 rounded-md text-[11px] font-bold font-mono tabular-nums ${
                              enabledCount === 4
                                ? 'bg-emerald-500/15 text-emerald-300 border border-emerald-500/30'
                                : enabledCount > 0
                                  ? 'bg-blue-500/15 text-blue-300 border border-blue-500/30'
                                  : 'bg-amber-500/15 text-amber-300 border border-amber-500/30'
                            }`}
                          >
                            {enabledCount}/4 مفعل
                          </span>
                        </div>
                        <p className="text-xs text-slate-400 leading-relaxed max-w-2xl">
                          تحكم بتشغيل أو إطفاء كل طبقة حماية بضغطة زر. ملاحظة: حساب المدير مستثنى تلقائياً من الحظر حتى لا تفقد الوصول إلى لوحة التحكم أبداً.
                        </p>
                      </div>

                      <div className="flex flex-wrap items-center gap-2">
                        <button
                          type="button"
                          disabled={policyBusyField !== null}
                          onClick={() => handleSetAllSecurityPolicy(true)}
                          className="min-h-[40px] px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 disabled:opacity-60 text-white text-xs font-extrabold cursor-pointer transition-colors"
                        >
                          تشغيل الحماية القصوى
                        </button>
                        <button
                          type="button"
                          disabled={policyBusyField !== null}
                          onClick={() => handleSetAllSecurityPolicy(false)}
                          className="min-h-[40px] px-3.5 py-2 rounded-xl bg-white/5 hover:bg-white/10 border border-[#1E2E4F] disabled:opacity-60 text-slate-300 text-xs font-bold cursor-pointer transition-colors"
                        >
                          إطفاء الكل
                        </button>
                      </div>
                    </div>

                    {/* Individual ON / OFF Protection Switches */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
                      {protectionItems.map((item) => {
                        const isUpdating =
                          policyBusyField === item.key || policyBusyField === 'ALL';
                        return (
                          <div
                            key={item.key}
                            className={`p-4 rounded-2xl bg-[#060B16] border transition-colors flex flex-col justify-between gap-4 ${
                              item.enabled ? 'border-emerald-500/35' : 'border-[#1B2947]'
                            }`}
                          >
                            <div className="flex items-start gap-3">
                              <div className="w-10 h-10 rounded-xl bg-[#0B1222] border border-[#1E2E4F] flex items-center justify-center shrink-0">
                                {item.icon}
                              </div>
                              <div className="space-y-1 min-w-0">
                                <div className="text-xs sm:text-sm font-extrabold text-white">
                                  {item.title}
                                </div>
                                <p className="text-[11px] sm:text-xs text-slate-400 leading-relaxed">
                                  {item.desc}
                                </p>
                              </div>
                            </div>

                            <div className="pt-2.5 border-t border-[#1B2947] flex items-center justify-between gap-3">
                              <span
                                className={`text-xs font-bold ${
                                  item.enabled ? 'text-emerald-400' : 'text-slate-400'
                                }`}
                              >
                                الحالة الآن: {item.enabled ? 'مفعّل (يعمل)' : 'متوقف (مطفأ)'}
                              </span>

                              <div className="flex items-center gap-1.5">
                                <button
                                  type="button"
                                  role="switch"
                                  aria-checked={item.enabled}
                                  disabled={isUpdating}
                                  onClick={() =>
                                    handleToggleSecurityPolicy(item.key, !item.enabled)
                                  }
                                  className={`min-h-[36px] px-4 rounded-xl text-xs font-extrabold transition-colors cursor-pointer disabled:opacity-50 ${
                                    item.enabled
                                      ? 'bg-emerald-600 hover:bg-emerald-500 text-white'
                                      : 'bg-[#0B1222] hover:bg-white/10 border border-[#1E2E4F] text-slate-300'
                                  }`}
                                >
                                  {item.enabled ? 'إطفاء' : 'تشغيل'}
                                </button>
                              </div>
                            </div>
                          </div>
                        );
                      })}
                    </div>

                    {/* Live Security Audit Log */}
                    <div className="p-4 sm:p-5 rounded-2xl bg-[#060B16] border border-[#1B2947] space-y-3">
                      <div className="flex flex-wrap items-center justify-between gap-2">
                        <div className="flex items-center gap-2">
                          <h4 className="text-xs sm:text-sm font-extrabold text-white">
                            سجل الحماية ومحاولات السحب والـ VPN المحظورة
                          </h4>
                          <span className="px-2 py-0.5 rounded-md bg-white/5 text-slate-300 text-[11px] font-mono tabular-nums">
                            {overview?.securityEvents?.length || 0}
                          </span>
                        </div>

                        <div className="flex items-center gap-2">
                          <button
                            type="button"
                            disabled={loadingOverview}
                            onClick={loadOverview}
                            className="min-h-[34px] px-3 rounded-lg bg-white/5 hover:bg-white/10 text-xs font-semibold text-slate-200 flex items-center gap-1.5 cursor-pointer"
                          >
                            <RefreshCw
                              className={`w-3.5 h-3.5 ${loadingOverview ? 'animate-spin' : ''}`}
                            />
                            <span>تحديث</span>
                          </button>
                          {(overview?.securityEvents?.length || 0) > 0 && (
                            <button
                              type="button"
                              disabled={busy}
                              onClick={handleClearSecurityEvents}
                              className="min-h-[34px] px-3 rounded-lg bg-red-500/15 hover:bg-red-500/25 text-xs font-semibold text-red-300 flex items-center gap-1.5 cursor-pointer"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                              <span>مسح السجل</span>
                            </button>
                          )}
                        </div>
                      </div>

                      {!overview?.securityEvents || overview.securityEvents.length === 0 ? (
                        <div className="py-8 text-center text-xs text-slate-400 border border-dashed border-[#1B2947] rounded-xl">
                          لا توجد محاولات سحب أو اتصالات VPN محظورة مسجلة حتى الآن.
                        </div>
                      ) : (
                        <div className="divide-y divide-white/5 max-h-[280px] overflow-y-auto overscroll-contain">
                          {overview.securityEvents.map((ev) => {
                            const badge =
                              ev.type === 'sniffer_blocked'
                                ? {
                                    text: 'HttpCanary / سحب روابط',
                                    cls: 'bg-red-500/15 text-red-300 border-red-500/30',
                                  }
                                : ev.type === 'vpn_blocked'
                                  ? {
                                      text: 'VPN / بروكسي',
                                      cls: 'bg-amber-500/15 text-amber-300 border-amber-500/30',
                                    }
                                  : ev.type === 'device_limit'
                                    ? {
                                        text: 'تجاوز عدد الأشخاص',
                                        cls: 'bg-purple-500/15 text-purple-300 border-purple-500/30',
                                      }
                                    : {
                                        text: 'فحص شبكة / DevTools',
                                        cls: 'bg-blue-500/15 text-blue-300 border-blue-500/30',
                                      };

                            const dt = new Date(ev.createdAt);
                            const timeStr = Number.isNaN(dt.getTime())
                              ? ''
                              : `${dt.toLocaleDateString('en-GB')} ${dt.toTimeString().slice(0, 8)}`;

                            return (
                              <div
                                key={ev.id}
                                className="py-2.5 flex flex-wrap items-center justify-between gap-2 text-xs"
                              >
                                <div className="space-y-1 min-w-0">
                                  <div className="flex flex-wrap items-center gap-2">
                                    <span
                                      className={`px-2 py-0.5 rounded-md border text-[10px] font-bold ${badge.cls}`}
                                    >
                                      {badge.text}
                                    </span>
                                    <span className="font-bold text-white">{ev.reason}</span>
                                  </div>
                                  <div className="text-[11px] text-slate-400 flex flex-wrap items-center gap-2">
                                    <span>الجهاز: {ev.deviceName || 'غير معروف'}</span>
                                    <span>·</span>
                                    <span>
                                      IP:{' '}
                                      <strong className="font-mono tabular-nums text-slate-200">
                                        {ev.ip}
                                      </strong>
                                    </span>
                                    {ev.subscriberCode && (
                                      <>
                                        <span>·</span>
                                        <span>
                                          الكود:{' '}
                                          <strong className="font-mono text-cyan-300">
                                            {ev.subscriberCode}
                                          </strong>
                                        </span>
                                      </>
                                    )}
                                  </div>
                                </div>
                                <span
                                  className="text-[11px] font-mono tabular-nums text-slate-400 shrink-0"
                                  dir="ltr"
                                >
                                  {timeStr}
                                </span>
                              </div>
                            );
                          })}
                        </div>
                      )}
                    </div>
                  </>
                );
              })()}
            </div>
          )}

          {/* TAB 8: USER SUBSCRIPTIONS (1-PERSON OR CUSTOM MULTI-PERSON) & ADMIN CODE */}
          {activeTab === 'security' && (
            <div className="space-y-6">
              {overview?.detectedServerUrl && (
                <div
                  className={`p-4 rounded-2xl bg-[#080F1E] border space-y-3 ${
                    overview.publicUrlStatus === 'live'
                      ? 'border-emerald-500/35'
                      : 'border-amber-500/45'
                  }`}
                >
                  <div className="flex flex-wrap items-start justify-between gap-3">
                    <div className="space-y-1 min-w-0 flex-1">
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="text-xs sm:text-sm font-extrabold text-white">
                          رابط دخول المشتركين العام
                        </span>
                        {overview.publicUrlStatus === 'live' ? (
                          <span className="text-xs font-bold text-emerald-400">
                            · مفعّل ويعمل للمشتركين الآن
                          </span>
                        ) : (
                          <span className="text-xs font-bold text-amber-300">
                            · يحتاج ضغطة تفعيل أولى من الشريط العلوي (Share أو Deploy)
                          </span>
                        )}
                      </div>

                      {overview.publicUrlStatus !== 'live' ? (
                        <div className="text-[11px] sm:text-xs text-amber-100/90 leading-relaxed space-y-1 pt-0.5">
                          <p>
                            سبب ظهور <span className="font-mono text-amber-300">Error: Page not found</span> عند فتح الرابط الآن هو أنك لم تقم بنشر الرابط للعامة بعد من شريط المنصة العلوي:
                          </p>
                          <p className="text-slate-300">
                            <strong className="text-white">الطريقة 1 (الأفضل والدائمة):</strong> اضغط على زر <strong className="text-cyan-300">Deploy (نشر)</strong> في أعلى الشاشة ليعطيك رابط <span className="font-mono">run.app</span> دائم يعمل لجميع المشتركين وتطبيق الـ APK.
                          </p>
                          <p className="text-slate-300">
                            <strong className="text-white">الطريقة 2 (مشاركة سريعة):</strong> اضغط على زر <strong className="text-cyan-300">Share (مشاركة)</strong> في أعلى الشاشة وفعّل مشاركة التطبيق للعامة، وسيعمل الرابط بالأسفل فوراً دون خطأ 404 أو 403.
                          </p>
                        </div>
                      ) : (
                        <div className="text-[11px] text-slate-300 leading-relaxed">
                          هذا الرابط العام نشط وجاهز لإرساله للمشتركين للدخول بأكوادهم:
                        </div>
                      )}

                      <div className="font-mono text-xs text-cyan-300 truncate pt-1" dir="ltr">
                        {overview.detectedServerUrl}
                      </div>
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      <button
                        type="button"
                        onClick={() => loadOverview()}
                        className="min-h-[40px] px-3 py-2 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-slate-200 text-xs font-bold flex items-center gap-1.5 cursor-pointer"
                      >
                        <RefreshCw className="w-3.5 h-3.5" />
                        <span>فحص الحالة</span>
                      </button>
                      <button
                        type="button"
                        onClick={handleCopyApkServerUrl}
                        className="min-h-[40px] px-4 py-2 rounded-xl bg-cyan-500/15 hover:bg-cyan-500/25 border border-cyan-500/35 text-cyan-200 text-xs font-bold flex items-center gap-1.5 cursor-pointer"
                      >
                        <Copy className="w-3.5 h-3.5" />
                        <span>{copiedApkServer ? 'تم نسخ الرابط' : 'نسخ الرابط'}</span>
                      </button>
                    </div>
                  </div>
                </div>
              )}

              <div className="grid grid-cols-1 lg:grid-cols-[1.15fr_0.85fr] gap-6 items-start">
                {/* Create New User Subscription */}
                <form
                  onSubmit={handleCreateSubscription}
                  className="p-5 rounded-2xl bg-[#060B16] border border-[#1B2947] space-y-4"
                >
                  <div>
                    <h3 className="text-sm font-extrabold text-white">
                      إنشاء اشتراك جديد (لشخص واحد أو لعدة أشخاص أنت تحددهم)
                    </h3>
                    <p className="text-xs text-slate-400 mt-0.5">
                      اختر ما إذا كان الاشتراك لشخص واحد فقط أو لعدة أشخاص وحدد تاريخ الانتهاء بدقة.
                    </p>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs font-semibold text-slate-300 mb-1">
                        اسم المشترك أو المجموعة
                      </label>
                      <input
                        type="text"
                        value={subLabel}
                        onChange={(e) => setSubLabel(e.target.value)}
                        placeholder="مثال: أحمد محمد"
                        className="w-full px-3.5 py-2.5 rounded-xl bg-[#0B1222] border border-[#1E2E4F] text-xs text-white focus:outline-none focus:border-blue-500"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-300 mb-1">
                        كود دخول المشترك *
                      </label>
                      <div className="flex items-center gap-1.5">
                        <input
                          type="text"
                          dir="ltr"
                          value={subCode}
                          onChange={(e) => setSubCode(e.target.value)}
                          placeholder="مثال: 784512"
                          className="flex-1 px-3 py-2.5 rounded-xl bg-[#0B1222] border border-[#1E2E4F] font-mono text-xs text-cyan-300 focus:outline-none focus:border-blue-500"
                        />
                        <button
                          type="button"
                          onClick={generateRandomSubscriberCode}
                          className="min-h-[38px] px-2.5 rounded-xl bg-white/10 hover:bg-white/15 text-xs text-slate-200 flex items-center gap-1 cursor-pointer shrink-0"
                          title="توليد كود عشوائي"
                        >
                          <Sparkles className="w-3.5 h-3.5 text-amber-300" />
                          <span>توليد</span>
                        </button>
                      </div>
                    </div>
                  </div>

                  {/* Subscription Capacity: 1 Person vs Multi-Person (Custom Count) */}
                  <div className="space-y-2.5">
                    <label className="block text-xs font-semibold text-slate-300">
                      نوع الاشتراك وعدد الأشخاص المسموح لهم بالدخول
                    </label>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                      <button
                        type="button"
                        onClick={() => setSubSeatMode('single')}
                        className={`p-3 rounded-xl border text-right transition-colors cursor-pointer flex items-start gap-2.5 ${
                          subSeatMode === 'single'
                            ? 'bg-blue-600/20 border-blue-500 text-white'
                            : 'bg-[#0B1222] border-[#1E2E4F] text-slate-300 hover:bg-white/5'
                        }`}
                      >
                        <User className="w-4 h-4 text-blue-400 shrink-0 mt-0.5" />
                        <div className="min-w-0">
                          <div className="text-xs font-extrabold">شخص واحد فقط (جهاز واحد)</div>
                          <div className="text-[11px] text-slate-400 mt-0.5">
                            يرتبط بأول جهاز يسجل الدخول ويمنع مشاركة الكود
                          </div>
                        </div>
                      </button>

                      <button
                        type="button"
                        onClick={() => {
                          setSubSeatMode('multi');
                          if (subMaxDevices < 2) setSubMaxDevices(3);
                        }}
                        className={`p-3 rounded-xl border text-right transition-colors cursor-pointer flex items-start gap-2.5 ${
                          subSeatMode === 'multi'
                            ? 'bg-emerald-600/20 border-emerald-500 text-white'
                            : 'bg-[#0B1222] border-[#1E2E4F] text-slate-300 hover:bg-white/5'
                        }`}
                      >
                        <Users className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                        <div className="min-w-0">
                          <div className="text-xs font-extrabold">عدة أشخاص (أنا أحدد العدد)</div>
                          <div className="text-[11px] text-slate-400 mt-0.5">
                            تحدد أنت عدد الأشخاص أو الأجهزة المسموح لها بالكود
                          </div>
                        </div>
                      </button>
                    </div>

                    {subSeatMode === 'multi' && (
                      <div className="p-3.5 rounded-xl bg-[#0B1222] border border-emerald-500/35 space-y-2.5">
                        <div className="flex flex-wrap items-center justify-between gap-2">
                          <label className="text-xs font-bold text-emerald-300">
                            حدد عدد الأشخاص / الأجهزة المسموح بها:
                          </label>
                          <div className="flex items-center gap-2">
                            <input
                              type="number"
                              min={2}
                              max={1000}
                              dir="ltr"
                              value={subMaxDevices}
                              onChange={(e) =>
                                setSubMaxDevices(
                                  Math.max(1, Math.min(1000, Number(e.target.value) || 1))
                                )
                              }
                              className="w-24 px-3 py-1.5 rounded-lg bg-[#060B16] border border-emerald-500/50 font-mono tabular-nums text-sm font-bold text-center text-white focus:outline-none focus:border-emerald-400"
                            />
                            <span className="text-xs text-slate-300 font-semibold">أشخاص</span>
                          </div>
                        </div>

                        <div className="flex flex-wrap gap-1.5">
                          {[2, 3, 4, 5, 10, 20].map((num) => (
                            <button
                              key={num}
                              type="button"
                              onClick={() => setSubMaxDevices(num)}
                              className={`px-2.5 py-1 rounded-lg border text-[11px] font-bold font-mono tabular-nums cursor-pointer ${
                                subMaxDevices === num
                                  ? 'bg-emerald-600 border-emerald-400 text-white'
                                  : 'bg-white/5 hover:bg-white/10 border-white/10 text-slate-300'
                              }`}
                            >
                              {num} أشخاص
                            </button>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1.5 flex items-center gap-1.5">
                      <Calendar className="w-3.5 h-3.5 text-blue-400" />
                      <span>متى ينتهي الاشتراك؟ (اختر التاريخ أو المدة السريعة)</span>
                    </label>
                    <input
                      type="date"
                      dir="ltr"
                      value={subExpiryDate}
                      onChange={(e) => setSubExpiryDate(e.target.value)}
                      className="w-full px-3.5 py-2.5 rounded-xl bg-[#0B1222] border border-[#1E2E4F] font-mono text-xs text-white focus:outline-none focus:border-blue-500"
                    />
                    <div className="flex flex-wrap gap-1.5 mt-2">
                      {[
                        { label: 'تجريبي يوم', days: 1 },
                        { label: 'أسبوع', days: 7 },
                        { label: 'شهر', days: 30 },
                        { label: '3 أشهر', days: 90 },
                        { label: '6 أشهر', days: 180 },
                        { label: 'سنة كاملة', days: 365 },
                      ].map((preset) => (
                        <button
                          key={preset.days}
                          type="button"
                          onClick={() => setSubExpiryDate(toDateInputValue(preset.days))}
                          className="px-2.5 py-1 rounded-lg bg-white/5 hover:bg-blue-600/30 border border-white/10 text-[11px] font-semibold text-slate-200 cursor-pointer"
                        >
                          {preset.label}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">
                      ملاحظات خاصة لك (اختياري)
                    </label>
                    <input
                      type="text"
                      value={subNotes}
                      onChange={(e) => setSubNotes(e.target.value)}
                      placeholder="مثال: تم الدفع عبر التحويل..."
                      className="w-full px-3.5 py-2 rounded-xl bg-[#0B1222] border border-[#1E2E4F] text-xs text-white focus:outline-none focus:border-blue-500"
                    />
                  </div>

                  <button
                    type="submit"
                    disabled={busy}
                    className="w-full min-h-[44px] rounded-xl bg-emerald-600 hover:bg-emerald-500 disabled:opacity-60 text-white text-xs font-extrabold cursor-pointer"
                  >
                    {subSeatMode === 'single'
                      ? '+ إنشاء اشتراك لشخص واحد فقط'
                      : `+ إنشاء اشتراك لـ (${subMaxDevices}) أشخاص`}
                  </button>
                </form>

                {/* Secret Master Admin Code + Shortcut to Protection Shield */}
                <div className="space-y-4">
                  <form
                    onSubmit={handleSaveMasterAdminCode}
                    className="p-5 rounded-2xl bg-[#060B16] border border-[#1B2947] space-y-4"
                  >
                    <h3 className="text-sm font-extrabold text-white">
                      كود لوحة المدير السري الخاص بك
                    </h3>
                    <div>
                      <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                        كود المدير السري (تفتح به اللوحة من شاشة الدخول الرئيسية)
                      </label>
                      <div className="relative">
                        <input
                          type={showAdminCodePlain ? 'text' : 'password'}
                          dir="ltr"
                          value={newAdminCode}
                          onChange={(e) => setNewAdminCode(e.target.value)}
                          className="w-full px-3.5 py-2.5 rounded-xl bg-[#0B1222] border border-purple-500/40 font-mono text-sm text-purple-300 focus:outline-none focus:border-purple-500"
                        />
                        <button
                          type="button"
                          onClick={() => setShowAdminCodePlain((s) => !s)}
                          className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white cursor-pointer"
                        >
                          {showAdminCodePlain ? (
                            <EyeOff className="w-4 h-4" />
                          ) : (
                            <Eye className="w-4 h-4" />
                          )}
                        </button>
                      </div>
                    </div>

                    <button
                      type="submit"
                      disabled={busy}
                      className="w-full min-h-[42px] py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold cursor-pointer"
                    >
                      حفظ كود المدير السري
                    </button>
                  </form>

                  {/* Telegram Code Request Link on Login Screen */}
                  <form
                    onSubmit={handleSaveTelegramCodeUrl}
                    className="p-4 sm:p-5 rounded-2xl bg-[#060B16] border border-[#229ED9]/35 space-y-3"
                  >
                    <div className="flex items-center gap-2 text-xs sm:text-sm font-extrabold text-white">
                      <TelegramPaperPlaneIcon className="w-4 h-4 text-[#38BDF8] shrink-0" />
                      <span>زر "الحصول على كود عن طريق التليجرام" (واجهة الدخول)</span>
                    </div>
                    <p className="text-[11px] text-slate-400 leading-relaxed">
                      ضع رابط حسابك أو قناتك في التليجرام ليفتح مباشرة عند ضغط الزوار على زر طلب الكود في شاشة تسجيل الدخول.
                    </p>
                    <div>
                      <input
                        type="text"
                        dir="ltr"
                        spellCheck={false}
                        value={telegramCodeUrl}
                        onChange={(e) => setTelegramCodeUrl(e.target.value)}
                        placeholder="https://t.me/your_channel أو @your_username"
                        className="w-full px-3.5 py-2.5 rounded-xl bg-[#0B1222] border border-[#1E2E4F] focus:border-[#38BDF8] font-mono text-xs text-cyan-300 focus:outline-none"
                      />
                    </div>
                    <button
                      type="submit"
                      disabled={busy}
                      className="w-full min-h-[40px] py-2 rounded-xl bg-gradient-to-r from-[#229ED9] to-[#0088CC] hover:from-[#2AABEE] hover:to-[#0296DE] disabled:opacity-60 text-white text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer"
                    >
                      <TelegramPaperPlaneIcon className="w-3.5 h-3.5" />
                      <span>حفظ رابط التليجرام لواجهة الدخول</span>
                    </button>
                  </form>

                  <div className="p-4 rounded-2xl bg-[#060B16] border border-[#1B2947] space-y-3">
                    <div className="flex items-center gap-2 text-xs font-extrabold text-white">
                      <Shield className="w-4 h-4 text-emerald-400" />
                      <span>إعدادات منع HttpCanary والـ VPN</span>
                    </div>
                    <p className="text-xs text-slate-400 leading-relaxed">
                      يمكنك تشغيل أو إطفاء حظر HttpCanary وبرامج سحب الروابط وتطبيقات الـ VPN ومراجعة سجل المحاولات المحظورة من تبويب الحماية.
                    </p>
                    <button
                      type="button"
                      onClick={() => setActiveTab('protection')}
                      className="w-full min-h-[40px] px-4 py-2 rounded-xl bg-emerald-600/20 hover:bg-emerald-600/30 border border-emerald-500/35 text-emerald-300 text-xs font-bold flex items-center justify-center gap-2 cursor-pointer"
                    >
                      <Shield className="w-4 h-4" />
                      <span>فتح إعدادات الحماية والـ VPN</span>
                    </button>
                  </div>
                </div>
              </div>

              {/* Subscribers Table with Device Limit & Connected Devices Control */}
              <div className="p-5 rounded-2xl bg-[#060B16] border border-[#1B2947] space-y-3">
                <h3 className="text-sm font-extrabold text-white">
                  قائمة اشتراكات المستخدمين والأجهزة المرتبطة ({overview?.accessCodes.length || 0})
                </h3>

                <div className="divide-y divide-white/5 max-h-[440px] overflow-y-auto overscroll-contain">
                  {overview?.accessCodes.map((ac) => {
                    const expMs = Date.parse(ac.expiresAt || '');
                    const isExpired = !Number.isNaN(expMs) && expMs <= Date.now();
                    const daysLeft = !Number.isNaN(expMs)
                      ? Math.max(0, Math.ceil((expMs - Date.now()) / 86400000))
                      : ac.durationDays;
                    const formattedExp = !Number.isNaN(expMs)
                      ? toDateInputValue(ac.expiresAt)
                      : 'غير محدد';
                    const maxSeats = Math.max(1, ac.maxDevices || 1);
                    const boundList = Array.isArray(ac.boundDevices) ? ac.boundDevices : [];
                    const isDevicesExpanded = expandedDevicesSubId === ac.id;

                    return (
                      <div key={ac.id} className="py-3.5 space-y-2.5 text-xs">
                        <div className="flex flex-wrap items-center justify-between gap-3">
                          <div className="space-y-1.5 min-w-0">
                            <div className="flex flex-wrap items-center gap-2">
                              <span className="font-mono font-bold text-sm text-cyan-300 bg-cyan-500/10 border border-cyan-500/25 px-2.5 py-0.5 rounded-lg">
                                {ac.code}
                              </span>
                              <span className="font-bold text-white">{ac.label}</span>

                              {/* Single vs Multi-Person Capacity Badge */}
                              <span
                                className={`px-2 py-0.5 rounded-md text-[11px] font-bold flex items-center gap-1 ${
                                  maxSeats === 1
                                    ? 'bg-blue-500/15 text-blue-300 border border-blue-500/25'
                                    : 'bg-purple-500/15 text-purple-300 border border-purple-500/25'
                                }`}
                              >
                                {maxSeats === 1 ? (
                                  <>
                                    <User className="w-3 h-3" />
                                    <span>شخص واحد</span>
                                  </>
                                ) : (
                                  <>
                                    <Users className="w-3 h-3" />
                                    <span>{maxSeats} أشخاص</span>
                                  </>
                                )}
                                <span className="font-mono tabular-nums opacity-90">
                                  ({boundList.length}/{maxSeats})
                                </span>
                              </span>

                              {!ac.active ? (
                                <span className="px-2 py-0.5 rounded-md bg-amber-500/15 text-amber-300 text-[11px] font-bold">
                                  موقوف
                                </span>
                              ) : isExpired ? (
                                <span className="px-2 py-0.5 rounded-md bg-red-500/15 text-red-300 text-[11px] font-bold">
                                  منتهي الصلاحية
                                </span>
                              ) : (
                                <span className="px-2 py-0.5 rounded-md bg-emerald-500/15 text-emerald-300 text-[11px] font-bold">
                                  نشط ({daysLeft} يوم متبقي)
                                </span>
                              )}
                            </div>

                            <div className="text-[11px] text-slate-400">
                              تاريخ الانتهاء:{' '}
                              <span className="font-mono tabular-nums text-slate-200">
                                {formattedExp}
                              </span>
                              {ac.notes ? ` · ${ac.notes}` : ''}
                            </div>
                          </div>

                          <div className="flex flex-wrap items-center gap-1.5">
                            {editingExpiryId === ac.id ? (
                              <div className="flex items-center gap-1.5">
                                <input
                                  type="date"
                                  dir="ltr"
                                  value={editingExpiryDate}
                                  onChange={(e) => setEditingExpiryDate(e.target.value)}
                                  className="px-2.5 py-1.5 rounded-lg bg-[#0B1222] border border-blue-500 font-mono text-xs text-white"
                                />
                                <button
                                  type="button"
                                  onClick={() => handleUpdateSubscriptionExpiry(ac.id)}
                                  className="px-2.5 py-1.5 rounded-lg bg-emerald-600 text-white font-bold cursor-pointer"
                                >
                                  حفظ
                                </button>
                                <button
                                  type="button"
                                  onClick={() => setEditingExpiryId(null)}
                                  className="px-2 py-1.5 rounded-lg bg-white/10 text-slate-300 cursor-pointer"
                                >
                                  إلغاء
                                </button>
                              </div>
                            ) : editingMaxDevicesId === ac.id ? (
                              <div className="flex items-center gap-1.5 bg-[#0B1222] border border-purple-500/50 rounded-xl px-2.5 py-1">
                                <span className="text-[11px] text-purple-200 font-semibold">
                                  العدد:
                                </span>
                                <input
                                  type="number"
                                  min={1}
                                  max={1000}
                                  dir="ltr"
                                  value={editingMaxDevicesVal}
                                  onChange={(e) =>
                                    setEditingMaxDevicesVal(
                                      Math.max(1, Math.min(1000, Number(e.target.value) || 1))
                                    )
                                  }
                                  className="w-16 px-2 py-1 rounded-lg bg-[#060B16] border border-[#1E2E4F] font-mono tabular-nums text-xs text-center text-white"
                                />
                                <button
                                  type="button"
                                  onClick={() => handleUpdateSubscriptionMaxDevices(ac.id)}
                                  className="px-2.5 py-1 rounded-lg bg-emerald-600 text-white font-bold cursor-pointer"
                                >
                                  حفظ
                                </button>
                                <button
                                  type="button"
                                  onClick={() => setEditingMaxDevicesId(null)}
                                  className="px-2 py-1 rounded-lg bg-white/10 text-slate-300 cursor-pointer"
                                >
                                  إلغاء
                                </button>
                              </div>
                            ) : (
                              <>
                                <button
                                  type="button"
                                  onClick={() => {
                                    navigator.clipboard?.writeText(ac.code).catch(() => {});
                                    notify('ok', `تم نسخ كود المشترك (${ac.code})`);
                                  }}
                                  className="min-h-[34px] px-2.5 rounded-lg bg-white/5 hover:bg-white/15 text-slate-200 flex items-center gap-1 cursor-pointer"
                                  title="نسخ الكود"
                                >
                                  <Copy className="w-3.5 h-3.5" />
                                  <span>نسخ</span>
                                </button>

                                <button
                                  type="button"
                                  onClick={() => {
                                    setEditingMaxDevicesId(ac.id);
                                    setEditingMaxDevicesVal(maxSeats);
                                    setEditingExpiryId(null);
                                  }}
                                  className="min-h-[34px] px-2.5 rounded-lg bg-purple-600/20 hover:bg-purple-600/35 text-purple-200 font-semibold flex items-center gap-1 cursor-pointer"
                                  title="تحديد شخص واحد أو عدة أشخاص"
                                >
                                  <Users className="w-3.5 h-3.5" />
                                  <span>تعديل العدد</span>
                                </button>

                                <button
                                  type="button"
                                  onClick={() =>
                                    setExpandedDevicesSubId((prev) =>
                                      prev === ac.id ? null : ac.id
                                    )
                                  }
                                  className={`min-h-[34px] px-2.5 rounded-lg font-semibold flex items-center gap-1 cursor-pointer ${
                                    isDevicesExpanded
                                      ? 'bg-cyan-600 text-white'
                                      : 'bg-cyan-500/15 hover:bg-cyan-500/25 text-cyan-300'
                                  }`}
                                >
                                  <Smartphone className="w-3.5 h-3.5" />
                                  <span className="font-mono tabular-nums">
                                    الأجهزة ({boundList.length}/{maxSeats})
                                  </span>
                                </button>

                                <button
                                  type="button"
                                  onClick={() => {
                                    setEditingExpiryId(ac.id);
                                    setEditingExpiryDate(toDateInputValue(ac.expiresAt));
                                    setEditingMaxDevicesId(null);
                                  }}
                                  className="min-h-[34px] px-2.5 rounded-lg bg-blue-600/20 hover:bg-blue-600/35 text-blue-300 font-semibold flex items-center gap-1 cursor-pointer"
                                >
                                  <Calendar className="w-3.5 h-3.5" />
                                  <span>تعديل الانتهاء</span>
                                </button>

                                <button
                                  type="button"
                                  onClick={() => handleToggleSubscriptionActive(ac.id, ac.active)}
                                  className="min-h-[34px] px-2.5 rounded-lg bg-white/5 hover:bg-white/15 text-slate-200 flex items-center gap-1 cursor-pointer"
                                >
                                  {ac.active ? (
                                    <>
                                      <PauseCircle className="w-3.5 h-3.5 text-amber-300" />
                                      <span>إيقاف</span>
                                    </>
                                  ) : (
                                    <>
                                      <PlayCircle className="w-3.5 h-3.5 text-emerald-400" />
                                      <span>تفعيل</span>
                                    </>
                                  )}
                                </button>

                                {(overview?.accessCodes.length || 0) > 1 && (
                                  <button
                                    type="button"
                                    onClick={async () => {
                                      await api.deleteAccessCode(ac.id);
                                      await loadOverview();
                                      await triggerSilentCloudBackup();
                                    }}
                                    className="min-h-[34px] px-2 rounded-lg bg-red-500/15 hover:bg-red-500/30 text-red-300 cursor-pointer"
                                    title="حذف الاشتراك"
                                  >
                                    <Trash2 className="w-3.5 h-3.5" />
                                  </button>
                                )}
                              </>
                            )}
                          </div>
                        </div>

                        {/* Expandable Bound Devices Panel */}
                        {isDevicesExpanded && (
                          <div className="p-3.5 rounded-xl bg-[#0B1222] border border-[#1E2E4F] space-y-2.5">
                            <div className="flex flex-wrap items-center justify-between gap-2">
                              <span className="text-xs font-bold text-slate-200">
                                الأجهزة المرتبطة بهذا الاشتراك ({boundList.length} من أصل {maxSeats})
                              </span>
                              {boundList.length > 0 && (
                                <button
                                  type="button"
                                  disabled={busy}
                                  onClick={() => handleResetSubscriberDevices(ac.id)}
                                  className="min-h-[30px] px-2.5 py-1 rounded-lg bg-amber-500/15 hover:bg-amber-500/25 text-amber-300 text-[11px] font-bold flex items-center gap-1 cursor-pointer"
                                >
                                  <RotateCcw className="w-3 h-3" />
                                  <span>تصفير وفصل جميع الأجهزة</span>
                                </button>
                              )}
                            </div>

                            {boundList.length === 0 ? (
                              <div className="text-[11px] text-slate-400 py-2">
                                لم يسجل أي جهاز الدخول بهذا الكود بعد. سيتم ربط أول{' '}
                                {maxSeats === 1 ? 'جهاز تلقائياً' : `${maxSeats} أجهزة تلقائياً`} فور تسجيل الدخول.
                              </div>
                            ) : (
                              <div className="divide-y divide-white/5">
                                {boundList.map((dev, dIdx) => {
                                  const lastDt = new Date(dev.lastSeenAt);
                                  const lastSeenLabel = Number.isNaN(lastDt.getTime())
                                    ? ''
                                    : `${lastDt.toLocaleDateString('en-GB')} ${lastDt.toTimeString().slice(0, 5)}`;
                                  return (
                                    <div
                                      key={dev.deviceId}
                                      className="py-2 flex flex-wrap items-center justify-between gap-2"
                                    >
                                      <div className="flex items-center gap-2 min-w-0">
                                        <span className="w-5 h-5 rounded-md bg-white/5 text-slate-300 font-mono tabular-nums text-[10px] flex items-center justify-center shrink-0">
                                          {dIdx + 1}
                                        </span>
                                        <div className="min-w-0">
                                          <div className="text-xs font-bold text-white truncate">
                                            {dev.deviceName || 'جهاز مشترك'}
                                          </div>
                                          <div className="text-[11px] text-slate-400 font-mono tabular-nums">
                                            IP: {dev.ip}
                                            {lastSeenLabel ? ` · آخر ظهور: ${lastSeenLabel}` : ''}
                                          </div>
                                        </div>
                                      </div>

                                      <button
                                        type="button"
                                        disabled={busy}
                                        onClick={() =>
                                          handleResetSubscriberDevices(ac.id, dev.deviceId)
                                        }
                                        className="px-2.5 py-1 rounded-lg bg-red-500/15 hover:bg-red-500/25 text-red-300 text-[11px] font-bold cursor-pointer shrink-0"
                                      >
                                        فصل الجهاز
                                      </button>
                                    </div>
                                  );
                                })}
                              </div>
                            )}
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          )}

          {/* TAB 8: SECRET SOURCES & PERMANENT CLOUD PERSISTENCE */}
          {activeTab === 'sources' && (
            <div className="space-y-5">
              {/* Cloud Vault Backup Card */}
              <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-l from-blue-950/60 to-[#060B16] border border-blue-500/30 flex flex-wrap items-center justify-between gap-4">
                <div className="space-y-1 max-w-xl">
                  <div className="text-sm font-extrabold text-white flex items-center gap-2">
                    <Cloud className="w-4 h-4 text-cyan-400" />
                    <span>الحفظ الدائم على السيرفر + الخزنة السحابية المشفرة (Firebase)</span>
                  </div>
                  <p className="text-xs text-slate-300 leading-relaxed">
                    جميع القنوات وروابط M3U والأقسام والاشتراكات تُحفظ تلقائياً بشكل دائم على السيرفر فور إضافتها. يمكنك أيضاً ربط حساب Google لحفظ نسخة احتياطية مشفرة بتشفير AES-256 في سحابة Firebase.
                  </p>
                  {cloudUser && (
                    <div className="text-[11px] text-emerald-400 font-semibold pt-0.5">
                      متصل بالسحابة: {cloudUser.email}{' '}
                      <button
                        type="button"
                        onClick={() => signOutAdminCloudVault()}
                        className="text-slate-400 hover:text-white underline mr-2 cursor-pointer"
                      >
                        (فصل الحساب)
                      </button>
                    </div>
                  )}
                </div>

                <div className="flex flex-wrap items-center gap-2">
                  <button
                    type="button"
                    disabled={cloudSyncing}
                    onClick={handleManualCloudBackup}
                    className="min-h-[40px] px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 disabled:opacity-60 text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer"
                  >
                    <Cloud className="w-3.5 h-3.5" />
                    <span>{cloudUser ? 'حفظ نسخة سحابية الآن' : 'ربط Google وحفظ سحابي'}</span>
                  </button>
                  <button
                    type="button"
                    disabled={cloudSyncing}
                    onClick={handleManualCloudRestore}
                    className="min-h-[40px] px-3.5 py-2 rounded-xl bg-white/10 hover:bg-white/15 disabled:opacity-60 text-slate-200 text-xs font-semibold cursor-pointer"
                  >
                    استعادة من السحابة
                  </button>
                </div>
              </div>

              {loadingOverview ? (
                <div className="text-xs text-slate-400 py-8 text-center">
                  جاري تحميل المصادر السرية...
                </div>
              ) : overview?.sources.length === 0 ? (
                <div className="p-10 text-center bg-[#060B16] rounded-2xl border border-[#1B2947] text-xs text-slate-400">
                  لا توجد مصادر مضافة حالياً. أضف رابط M3U أو حساب Xtream من التبويبات أعلاه.
                </div>
              ) : (
                overview?.sources.map((src) => {
                  const isRevealed = revealedIds.has(src.id);
                  return (
                    <div
                      key={src.id}
                      className="p-4 rounded-2xl bg-[#060B16] border border-[#1B2947] flex flex-col gap-3"
                    >
                      <div className="flex flex-wrap items-center justify-between gap-2">
                        <div>
                          <div className="text-sm font-bold text-white flex items-center gap-2">
                            <span>{src.name}</span>
                            {src.type !== 'starter' && (
                              <span className="px-2 py-0.5 rounded-md bg-emerald-500/15 text-emerald-300 text-[10px] font-bold">
                                محفوظ دائماً
                              </span>
                            )}
                          </div>
                          <div className="text-xs text-slate-400 mt-0.5">
                            النوع: {src.type.toUpperCase()} · القنوات:{' '}
                            <span className="font-mono tabular-nums text-white">
                              {src.channelCount}
                            </span>{' '}
                            · الأقسام:{' '}
                            <span className="font-mono tabular-nums text-white">
                              {src.groupsInOrder.length}
                            </span>
                          </div>
                        </div>

                        <div className="flex items-center gap-2">
                          {(src.m3uUrl || src.xtreamHost) && (
                            <button
                              type="button"
                              onClick={() =>
                                setRevealedIds((prev) => {
                                  const next = new Set(prev);
                                  if (next.has(src.id)) next.delete(src.id);
                                  else next.add(src.id);
                                  return next;
                                })
                              }
                              className="px-3 py-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-xs text-slate-200 flex items-center gap-1.5 cursor-pointer"
                            >
                              {isRevealed ? (
                                <EyeOff className="w-3.5 h-3.5" />
                              ) : (
                                <Eye className="w-3.5 h-3.5" />
                              )}
                              <span>{isRevealed ? 'إخفاء الرابط' : 'إظهار الرابط لك'}</span>
                            </button>
                          )}

                          {(src.type === 'm3u_url' || src.type === 'xtream') && (
                            <button
                              type="button"
                              disabled={busy}
                              onClick={() => handleRefreshSource(src.id)}
                              className="px-3 py-1.5 rounded-lg bg-blue-600/20 hover:bg-blue-600/30 text-blue-300 text-xs font-semibold flex items-center gap-1.5 cursor-pointer"
                            >
                              <RefreshCw className="w-3.5 h-3.5" />
                              <span>مزامنة القنوات الجديدة</span>
                            </button>
                          )}

                          <button
                            type="button"
                            disabled={busy}
                            onClick={() => handleDeleteSource(src.id)}
                            className="px-3 py-1.5 rounded-lg bg-red-500/15 hover:bg-red-500/25 text-red-300 text-xs font-semibold flex items-center gap-1.5 cursor-pointer"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                            <span>حذف</span>
                          </button>
                        </div>
                      </div>

                      {isRevealed && src.m3uUrl && (
                        <div
                          className="p-3 rounded-xl bg-[#0B1222] border border-[#1E2E4F] font-mono text-xs text-cyan-300 break-all"
                          dir="ltr"
                        >
                          {src.m3uUrl}
                        </div>
                      )}

                      {isRevealed && src.xtreamHost && (
                        <div
                          className="p-3 rounded-xl bg-[#0B1222] border border-[#1E2E4F] font-mono text-xs text-cyan-300 space-y-1"
                          dir="ltr"
                        >
                          <div>Host: {src.xtreamHost}</div>
                          <div>Username: {src.xtreamUsername}</div>
                          <div>Password: {src.xtreamPassword}</div>
                        </div>
                      )}
                    </div>
                  );
                })
              )}
            </div>
          )}

          {/* TAB: ANDROID APK BUILDER & SUBSCRIBER DOWNLOAD */}
          {activeTab === 'apk' && (
            <div className="space-y-5">
              {/* 1. Server Connection & Direct Subscriber APK Link */}
              <form
                onSubmit={handleSaveApkSettings}
                className="bg-[#080F1E] border border-[#1B2947] rounded-2xl p-4 sm:p-5 space-y-4"
              >
                <div className="flex items-start justify-between gap-3 flex-wrap">
                  <div>
                    <h3 className="text-sm sm:text-base font-bold text-white flex items-center gap-2">
                      <Smartphone className="w-4 h-4 text-emerald-400 shrink-0" />
                      <span>إعدادات تطبيق الأندرويد الرسمي (MS TV APK)</span>
                    </h3>
                    <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                      تم تجهيز مشروع الأندرويد الرسمي (<span className="font-mono text-slate-200">com.mstv.iptv</span>) بشعار MS TV ودعم الهواتف وشاشات Android TV وحماية مدمجة ضد شهادات HttpCanary.
                    </p>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-1.5">
                    <label className="block text-xs font-semibold text-slate-200">
                      رابط السيرفر المتصل به تطبيق الـ APK
                    </label>
                    <div className="flex items-center gap-2">
                      <input
                        type="url"
                        dir="ltr"
                        value={apkServerUrlDraft}
                        onChange={(e) => setApkServerUrlDraft(e.target.value)}
                        placeholder={overview?.detectedServerUrl || 'https://...'}
                        className="flex-1 min-h-[42px] px-3.5 py-2 rounded-xl bg-[#060B16] border border-[#1E2E4F] text-xs font-mono text-cyan-300 focus:outline-none focus:border-blue-500"
                      />
                      <button
                        type="button"
                        onClick={handleCopyApkServerUrl}
                        className="min-h-[42px] px-3 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-slate-200 text-xs font-semibold flex items-center gap-1.5 shrink-0 cursor-pointer"
                      >
                        <Copy className="w-3.5 h-3.5" />
                        <span>{copiedApkServer ? 'تم النسخ' : 'نسخ'}</span>
                      </button>
                    </div>
                    <p className="text-[11px] text-slate-400 leading-relaxed">
                      يتصل ملف الـ APK بهذا الرابط لجلب القنوات والتحقق من أكواد المشتركين وإخفاء روابط البث.
                    </p>
                  </div>

                  <div className="space-y-1.5">
                    <label className="block text-xs font-semibold text-slate-200">
                      رابط تحميل ملف الـ APK المباشر للمشتركين (اختياري)
                    </label>
                    <input
                      type="url"
                      dir="ltr"
                      value={apkDownloadUrlDraft}
                      onChange={(e) => setApkDownloadUrlDraft(e.target.value)}
                      placeholder="https://github.com/.../releases/latest/download/MS-TV.apk"
                      className="w-full min-h-[42px] px-3.5 py-2 rounded-xl bg-[#060B16] border border-[#1E2E4F] text-xs font-mono text-emerald-300 focus:outline-none focus:border-emerald-500"
                    />
                    <p className="text-[11px] text-slate-400 leading-relaxed">
                      عند وضع رابط ملف الـ APK هنا (من GitHub Releases أو Telegram أو MediaFire) سيظهر زر «تحميل تطبيق الأندرويد (APK)» في شاشة تسجيل الدخول للمشتركين.
                    </p>
                  </div>
                </div>

                <div className="flex items-center justify-end pt-1">
                  <button
                    type="submit"
                    disabled={apkSaving}
                    className="min-h-[42px] px-5 py-2 rounded-xl bg-gradient-to-r from-[#1268FB] to-[#2563EB] hover:from-[#1D74FF] hover:to-[#3B82F6] disabled:opacity-60 text-white text-xs font-bold flex items-center gap-2 cursor-pointer"
                  >
                    <CheckCircle2 className="w-4 h-4" />
                    <span>{apkSaving ? 'جاري الحفظ...' : 'حفظ إعدادات الـ APK'}</span>
                  </button>
                </div>
              </form>

              {/* 2. Automatic Cloud Build (GitHub Actions) + Direct Android Project Download */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                <div className="bg-[#080F1E] border border-emerald-500/25 rounded-2xl p-4 sm:p-5 space-y-3">
                  <h4 className="text-sm font-bold text-emerald-300 flex items-center gap-2">
                    <Cloud className="w-4 h-4 shrink-0" />
                    <span>استخراج ملف MS-TV.apk تلقائياً بدون برامج (GitHub Actions)</span>
                  </h4>
                  <ol className="space-y-2.5 text-xs text-slate-300 list-decimal list-inside leading-relaxed">
                    <li>
                      احفظ <strong className="text-white">رابط السيرفر</strong> أعلاه بعد نشر التطبيق على رابط عام دائم.
                    </li>
                    <li>
                      ارفع المشروع إلى حسابك في <strong className="text-white">GitHub</strong> (عبر زر التصدير إلى GitHub أو رفع الحزمة المحمّلة بالأسفل).
                    </li>
                    <li>
                      افتح تبويب <strong className="text-white">Actions</strong> في مستودعك واضغط <strong className="text-emerald-300">Build MS TV Android APK</strong> — سيتم بناء وتوقيع ملف <strong className="font-mono text-white">MS-TV.apk</strong> تلقائياً خلال دقيقتين ونشره في قسم <strong className="text-white">Releases</strong> جاهزاً للتحميل والتثبيت!
                    </li>
                  </ol>
                </div>

                <div className="bg-[#080F1E] border border-[#1B2947] rounded-2xl p-4 sm:p-5 flex flex-col justify-between gap-4">
                  <div className="space-y-2">
                    <h4 className="text-sm font-bold text-white flex items-center gap-2">
                      <Download className="w-4 h-4 text-cyan-400 shrink-0" />
                      <span>تنزيل حزمة مشروع الأندرويد الكاملة (Capacitor + Gradle)</span>
                    </h4>
                    <p className="text-xs text-slate-400 leading-relaxed">
                      تحتوي الحزمة على مجلد <span className="font-mono text-slate-200">android/</span> الكامل وملف البناء التلقائي <span className="font-mono text-slate-200">.github/workflows/build-apk.yml</span> مربوطاً مسبقاً برابط السيرفر الخاص بك، مع استثناء بيانات المصادر السرية لحمايتها.
                    </p>
                  </div>

                  <a
                    href={api.getApkProjectDownloadUrl()}
                    download="MS-TV-Android-APK-Project.tar.gz"
                    className="w-full min-h-[44px] px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs sm:text-sm font-bold flex items-center justify-center gap-2 transition-colors cursor-pointer"
                  >
                    <Download className="w-4 h-4 shrink-0" />
                    <span>تنزيل حزمة مشروع الأندرويد الجاهزة (.tar.gz)</span>
                  </a>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
