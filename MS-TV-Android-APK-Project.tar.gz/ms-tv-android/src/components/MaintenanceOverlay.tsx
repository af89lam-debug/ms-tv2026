import React, { useEffect, useRef, useState } from 'react';
import { Wrench, RefreshCw, Lock } from 'lucide-react';
import { api } from '../api';
import type { PublicStatusResponse } from '../types';
import { BrandMark } from './BrandMark';
import { TelegramPaperPlaneIcon, normalizeSlideExternalUrl } from './HeroBanner';

export const DEFAULT_MAINTENANCE_TEXT = 'التطبيق في وضع الصيانة يرجى المحاولة لاحقاً';

interface MaintenanceOverlayProps {
  message?: string;
  telegramUrl?: string;
  onCleared: (status: PublicStatusResponse) => void;
  onOpenAdminGate: () => void;
}

export const MaintenanceOverlay: React.FC<MaintenanceOverlayProps> = ({
  message,
  telegramUrl,
  onCleared,
  onOpenAdminGate,
}) => {
  const [checking, setChecking] = useState(false);
  const [stillPausedNotice, setStillPausedNotice] = useState<string | null>(null);
  const [liveMessage, setLiveMessage] = useState<string>(
    message?.trim() || DEFAULT_MAINTENANCE_TEXT
  );

  const secretTapCountRef = useRef(0);
  const secretTapTimerRef = useRef<number | null>(null);

  useEffect(() => {
    setLiveMessage(message?.trim() || DEFAULT_MAINTENANCE_TEXT);
  }, [message]);

  useEffect(() => {
    const timer = window.setInterval(async () => {
      try {
        const pub = await api.getPublicStatus();
        if (!pub.maintenanceMode) {
          onCleared(pub);
        } else if (pub.maintenanceMessage) {
          setLiveMessage(pub.maintenanceMessage);
        }
      } catch {
        // ignore transient network check errors
      }
    }, 25000);
    return () => window.clearInterval(timer);
  }, [onCleared]);

  const handleRecheck = async () => {
    setChecking(true);
    setStillPausedNotice(null);
    try {
      const pub = await api.getPublicStatus();
      if (!pub.maintenanceMode) {
        onCleared(pub);
        return;
      }
      if (pub.maintenanceMessage) {
        setLiveMessage(pub.maintenanceMessage);
      }
      setStillPausedNotice('لا يزال التطبيق متوقفاً للصيانة حالياً، يرجى المحاولة بعد قليل.');
    } catch {
      setStillPausedNotice('تعذر التحقق من الحالة حالياً، يرجى المحاولة مجدداً.');
    } finally {
      setChecking(false);
    }
  };

  const handleBrandTap = () => {
    secretTapCountRef.current += 1;
    if (secretTapTimerRef.current) window.clearTimeout(secretTapTimerRef.current);
    if (secretTapCountRef.current >= 5) {
      secretTapCountRef.current = 0;
      onOpenAdminGate();
      return;
    }
    secretTapTimerRef.current = window.setTimeout(() => {
      secretTapCountRef.current = 0;
    }, 1400);
  };

  const telegramHref = normalizeSlideExternalUrl(telegramUrl);

  return (
    <div
      onContextMenu={(e) => e.preventDefault()}
      className="fixed inset-0 z-[82] bg-[#060B16] flex flex-col items-center pt-safe pb-safe px-safe select-none overflow-y-auto overscroll-contain"
      dir="rtl"
    >
      <div className="pointer-events-none fixed inset-0 opacity-40 bg-[radial-gradient(circle_at_25%_20%,rgba(245,158,11,0.14),transparent_48%),radial-gradient(circle_at_75%_80%,rgba(18,104,251,0.16),transparent_48%)]" />

      <div className="relative z-10 w-full max-w-md space-y-5 sm:space-y-6 my-auto px-4 py-6">
        <div className="flex justify-center">
          <button
            type="button"
            onClick={handleBrandTap}
            className="focus:outline-none cursor-pointer"
            aria-label="MS TV"
          >
            <BrandMark size="lg" />
          </button>
        </div>

        <div className="bg-[#0B1222] border border-[#1B2947] rounded-3xl p-6 sm:p-8 space-y-5 shadow-2xl">
          <div className="flex flex-col items-center text-center space-y-3.5">
            <div className="w-14 h-14 rounded-2xl bg-amber-500/12 border border-amber-500/35 text-amber-400 flex items-center justify-center">
              <Wrench className="w-7 h-7" />
            </div>

            <h1
              className="text-lg sm:text-xl font-extrabold text-white leading-relaxed"
              style={{ textWrap: 'balance' }}
            >
              {liveMessage}
            </h1>

            <p className="text-xs sm:text-sm text-slate-400 leading-relaxed">
              نعمل حالياً على تحديث وتحسين القنوات والخوادم لضمان أفضل جودة بث واستقرار للمشاهدة.
            </p>
          </div>

          {stillPausedNotice && (
            <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/25 text-amber-200 text-xs font-medium text-center leading-relaxed">
              {stillPausedNotice}
            </div>
          )}

          <div className="space-y-2.5 pt-1">
            <button
              type="button"
              disabled={checking}
              onClick={handleRecheck}
              className="w-full min-h-[48px] px-5 py-3 rounded-2xl bg-[#1268FB] hover:bg-[#1D74FF] disabled:opacity-60 text-white text-xs sm:text-sm font-extrabold flex items-center justify-center gap-2 cursor-pointer transition-colors"
            >
              <RefreshCw className={`w-4 h-4 ${checking ? 'animate-spin' : ''}`} />
              <span>{checking ? 'جاري التحقق من حالة التطبيق...' : 'إعادة المحاولة الآن'}</span>
            </button>

            {telegramHref && (
              <a
                href={telegramHref}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full min-h-[46px] py-3 px-5 rounded-2xl bg-[#229ED9]/15 hover:bg-[#229ED9]/25 border border-[#229ED9]/45 text-[#7DD3FC] hover:text-white font-bold text-xs sm:text-sm flex items-center justify-center gap-2 transition-colors cursor-pointer"
              >
                <TelegramPaperPlaneIcon className="w-4 h-4 shrink-0 text-[#38BDF8]" />
                <span>متابعة التحديثات عبر التليجرام</span>
              </a>
            )}
          </div>

          <div className="pt-3 border-t border-[#1B2947] flex justify-center">
            <button
              type="button"
              onClick={onOpenAdminGate}
              className="min-h-[42px] px-3 text-xs font-semibold text-slate-400 hover:text-slate-200 flex items-center justify-center gap-1.5 cursor-pointer transition-colors"
            >
              <Lock className="w-3.5 h-3.5" />
              <span>دخول المدير لإدارة التطبيق</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
