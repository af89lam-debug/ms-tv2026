import React, { useState, useMemo } from 'react';
import { X, Check, Search, ListPlus, Trash2 } from 'lucide-react';
import type { CategorySummary, Channel, CustomPlaylist } from '../types';
import { ChannelLogo } from './ChannelLogo';

const LIST_COLOR_OPTIONS: ReadonlyArray<{ hex: string; bgClass: string }> = [
  { hex: '#2563EB', bgClass: 'bg-[#2563EB]' },
  { hex: '#059669', bgClass: 'bg-[#059669]' },
  { hex: '#E11D48', bgClass: 'bg-[#E11D48]' },
  { hex: '#7C3AED', bgClass: 'bg-[#7C3AED]' },
  { hex: '#D97706', bgClass: 'bg-[#D97706]' },
  { hex: '#0891B2', bgClass: 'bg-[#0891B2]' },
];

interface CustomListModalProps {
  existingList?: CustomPlaylist | null;
  channels: Channel[];
  categories: CategorySummary[];
  isAdminUnlocked: boolean;
  onClose: () => void;
  onSave: (payload: {
    id?: string;
    name: string;
    color: string;
    channelIds: string[];
    isGlobal: boolean;
  }) => Promise<void>;
  onDelete?: (listId: string) => Promise<void>;
}

export const CustomListModal: React.FC<CustomListModalProps> = ({
  existingList,
  channels,
  categories,
  isAdminUnlocked,
  onClose,
  onSave,
  onDelete,
}) => {
  const [name, setName] = useState(existingList?.name || '');
  const [color, setColor] = useState(existingList?.color || LIST_COLOR_OPTIONS[0].hex);
  const [selectedIds, setSelectedIds] = useState<Set<string>>(
    new Set(existingList?.channelIds || [])
  );
  const [isGlobal, setIsGlobal] = useState<boolean>(
    existingList ? existingList.isGlobal : isAdminUnlocked
  );
  const [search, setSearch] = useState('');
  const [filterGroup, setFilterGroup] = useState('ALL');
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const filteredChannels = useMemo(() => {
    return channels.filter((c) => {
      if (filterGroup !== 'ALL' && c.group !== filterGroup) return false;
      if (search.trim()) {
        const q = search.toLowerCase();
        return c.name.toLowerCase().includes(q) || c.group.toLowerCase().includes(q);
      }
      return true;
    });
  }, [channels, filterGroup, search]);

  const toggleChannel = (id: string) => {
    setSelectedIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) {
        next.delete(id);
      } else {
        next.add(id);
      }
      return next;
    });
  };

  const selectAllVisible = () => {
    setSelectedIds((prev) => {
      const next = new Set(prev);
      filteredChannels.slice(0, 200).forEach((c) => next.add(c.id));
      return next;
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      setError('يرجى إدخال اسم القائمة الخاصة.');
      return;
    }
    setSaving(true);
    setError(null);
    try {
      await onSave({
        id: existingList?.id,
        name: name.trim(),
        color,
        channelIds: Array.from(selectedIds),
        isGlobal: isAdminUnlocked ? isGlobal : false,
      });
      onClose();
    } catch (err: any) {
      setError(err?.message || 'حدث خطأ أثناء حفظ القائمة.');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div
      onClick={onClose}
      className="fixed inset-0 z-[70] bg-black/75 backdrop-blur-xs flex items-end sm:items-center justify-center p-0 sm:p-4"
      dir="rtl"
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="bg-[#0B1222] border-t sm:border border-[#1E325C] rounded-t-3xl sm:rounded-2xl w-full sm:max-w-2xl h-[92dvh] sm:h-[88dvh] max-h-[94dvh] flex flex-col overflow-hidden shadow-2xl"
      >
        <div className="w-10 h-1.5 bg-slate-600 rounded-full mx-auto mt-3 sm:hidden shrink-0" />

        <div className="shrink-0 flex items-center justify-between gap-2 px-4 sm:px-5 py-3.5 sm:py-4 border-b border-[#1B2947]">
          <div className="flex items-center gap-2.5 min-w-0">
            <ListPlus className="w-5 h-5 text-blue-400 shrink-0" />
            <h3 className="text-sm sm:text-base font-bold text-white truncate">
              {existingList ? 'تعديل القائمة الخاصة للقنوات' : 'إنشاء قائمة خاصة للقنوات'}
            </h3>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="min-h-[44px] min-w-[44px] rounded-xl text-slate-400 hover:text-white hover:bg-white/10 flex items-center justify-center cursor-pointer shrink-0"
            aria-label="إغلاق"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form
          onSubmit={handleSubmit}
          className="flex-1 min-h-0 flex flex-col overflow-hidden p-4 sm:p-5 sheet-pb-safe sm:pb-5 gap-3"
        >
          <div className="shrink-0 grid grid-cols-1 sm:grid-cols-2 gap-3.5 sm:gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                اسم القائمة الخاصة
              </label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="مثال: قنوات المباريات المفضلة"
                className="w-full min-h-[44px] px-3.5 py-2.5 rounded-xl bg-[#060B16] border border-[#1E2E4F] text-sm text-white focus:outline-none focus:border-blue-500"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                لون التمييز
              </label>
              <div className="flex items-center gap-2 pt-0.5">
                {LIST_COLOR_OPTIONS.map(({ hex, bgClass }) => (
                  <button
                    key={hex}
                    type="button"
                    onClick={() => setColor(hex)}
                    className={`w-10 h-10 sm:w-9 sm:h-9 rounded-xl ${bgClass} flex items-center justify-center border-2 transition-transform cursor-pointer ${
                      color === hex ? 'border-white scale-105' : 'border-transparent opacity-80'
                    }`}
                    aria-label={`لون ${hex}`}
                  >
                    {color === hex && <Check className="w-4 h-4 text-white" />}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {isAdminUnlocked && !existingList && (
            <label className="shrink-0 min-h-[38px] flex items-center gap-2 text-xs text-slate-300 cursor-pointer select-none">
              <input
                type="checkbox"
                checked={isGlobal}
                onChange={(e) => setIsGlobal(e.target.checked)}
                className="w-4 h-4 accent-blue-600 rounded shrink-0"
              />
              <span>إظهار هذه القائمة الخاصة لجميع المشتركين في الشريط الجانبي</span>
            </label>
          )}

          {/* Filter & Select Channels */}
          <div className="shrink-0 flex flex-wrap items-center gap-2">
            <div className="relative flex-1 min-w-[170px]">
              <Search className="w-4 h-4 text-slate-400 absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" />
              <input
                type="text"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="ابحث عن قناة لإضافتها..."
                className="w-full min-h-[42px] pr-9 pl-3 py-2 rounded-xl bg-[#060B16] border border-[#1E2E4F] text-xs text-white focus:outline-none focus:border-blue-500"
              />
            </div>

            <select
              value={filterGroup}
              onChange={(e) => setFilterGroup(e.target.value)}
              className="min-h-[42px] max-w-full sm:max-w-[200px] px-3 py-2 rounded-xl bg-[#060B16] border border-[#1E2E4F] text-xs text-slate-200 focus:outline-none focus:border-blue-500"
            >
              <option value="ALL">جميع الأقسام ({channels.length})</option>
              {categories.map((cat) => (
                <option key={cat.name} value={cat.name}>
                  {cat.name} ({cat.count})
                </option>
              ))}
            </select>

            <button
              type="button"
              onClick={selectAllVisible}
              className="min-h-[42px] px-3 py-2 rounded-xl bg-white/5 hover:bg-white/10 text-xs font-semibold text-blue-400 cursor-pointer whitespace-nowrap"
            >
              تحديد المعروض
            </button>
          </div>

          <div className="shrink-0 text-xs text-slate-400 flex items-center justify-between">
            <span>
              القنوات المحددة حالياً:{' '}
              <strong className="text-white tabular-nums">{selectedIds.size}</strong> قناة
            </span>
            {selectedIds.size > 0 && (
              <button
                type="button"
                onClick={() => setSelectedIds(new Set())}
                className="min-h-[36px] px-2 text-slate-400 hover:text-red-400 text-[11px] cursor-pointer"
              >
                إلغاء تحديد الكل
              </button>
            )}
          </div>

          <div className="flex-1 min-h-[160px] overflow-y-auto overscroll-contain rounded-xl bg-[#060B16] border border-[#1B2947] divide-y divide-white/5">
            {filteredChannels.slice(0, 300).map((ch) => {
              const checked = selectedIds.has(ch.id);
              return (
                <label
                  key={ch.id}
                  className={`min-h-[52px] flex items-center gap-3 px-3.5 py-2.5 cursor-pointer transition-colors ${
                    checked ? 'bg-blue-600/15' : 'hover:bg-white/5'
                  }`}
                >
                  <input
                    type="checkbox"
                    checked={checked}
                    onChange={() => toggleChannel(ch.id)}
                    className="w-4 h-4 accent-blue-600 rounded shrink-0"
                  />
                  <ChannelLogo name={ch.name} logo={ch.logo} group={ch.group} size="sm" />
                  <div className="min-w-0 flex-1">
                    <div className="text-xs font-bold text-white truncate">{ch.name}</div>
                    <div className="text-[11px] text-slate-400 truncate">{ch.group}</div>
                  </div>
                </label>
              );
            })}
            {filteredChannels.length === 0 && (
              <div className="p-8 text-center text-xs text-slate-400">
                لا توجد قنوات مطابقة للبحث الحالي.
              </div>
            )}
          </div>

          {error && (
            <div className="shrink-0 p-3 rounded-xl bg-red-500/10 border border-red-500/30 text-xs text-red-300">
              {error}
            </div>
          )}

          <div className="shrink-0 flex flex-wrap items-center justify-between gap-2.5 pt-2 border-t border-[#1B2947]">
            <div>
              {existingList && onDelete && (
                <button
                  type="button"
                  onClick={async () => {
                    setSaving(true);
                    await onDelete(existingList.id);
                    onClose();
                  }}
                  disabled={saving}
                  className="min-h-[44px] px-3.5 py-2 rounded-xl bg-red-500/10 hover:bg-red-500/20 text-red-400 text-xs font-semibold flex items-center gap-1.5 cursor-pointer"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>حذف القائمة</span>
                </button>
              )}
            </div>

            <div className="flex items-center gap-2 mr-auto sm:mr-0">
              <button
                type="button"
                onClick={onClose}
                className="min-h-[44px] px-4 py-2 rounded-xl bg-white/5 hover:bg-white/10 text-slate-300 text-xs font-semibold cursor-pointer"
              >
                إلغاء
              </button>
              <button
                type="submit"
                disabled={saving}
                className="min-h-[44px] px-5 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 disabled:opacity-60 text-white text-xs font-bold cursor-pointer"
              >
                {saving ? 'جاري الحفظ...' : existingList ? 'حفظ التحديثات' : 'إنشاء القائمة الخاصة'}
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};
