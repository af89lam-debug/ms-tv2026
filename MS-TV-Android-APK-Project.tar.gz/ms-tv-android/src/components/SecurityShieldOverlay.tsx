import React, { useEffect, useRef, useState } from 'react';
import { ShieldAlert, WifiOff, RefreshCw, Lock, AlertTriangle } from 'lucide-react';
import { api, isNativeApkRuntime } from '../api';
import type { SecurityPolicyConfig } from '../types';
import { BrandMark } from './BrandMark';

export interface SecurityBlockState {
  code: 'VPN_BLOCKED' | 'SNIFFER_BLOCKED' | 'DEVTOOLS_BLOCKED';
  message: string;
}

const NATIVE_FETCH_REF = typeof window !== 'undefined' ? window.fetch : null;
const NATIVE_XHR_OPEN_REF =
  typeof XMLHttpRequest !== 'undefined' ? XMLHttpRequest.prototype.open : null;
const NATIVE_XHR_SEND_REF =
  typeof XMLHttpRequest !== 'undefined' ? XMLHttpRequest.prototype.send : null;

export function useClientSecurityMonitor({
  policy,
  isAdminUnlocked,
  onBlock,
}: {
  policy: SecurityPolicyConfig;
  isAdminUnlocked: boolean;
  onBlock: (block: SecurityBlockState) => void;
}): void {
  const reportedRef = useRef<Set<string>>(new Set());

  // 1. Client-side Anti-Sniffer / Anti-Hook integrity monitor
  useEffect(() => {
    if (!policy.blockSniffers || isAdminUnlocked) return;

    const inspectRuntimeHooks = () => {
      const win = window as unknown as Record<string, unknown>;
      const suspiciousGlobals = [
        '__HTTPCANARY__',
        '__REQABLE__',
        '__PCAPDROID__',
        '__SSL_PINNING_BYPASS__',
        '__FRIDA__',
      ];

      for (const key of suspiciousGlobals) {
        if (win[key]) {
          if (!reportedRef.current.has(key)) {
            reportedRef.current.add(key);
            api.reportSecurityTamper({
              type: 'sniffer_blocked',
              reason: `اكتشاف حقن اعتراض الشبكة في المتصفح (${key})`,
            });
          }
          onBlock({
            code: 'SNIFFER_BLOCKED',
            message:
              'تم اكتشاف أداة اعتراض أو سحب لروابط البث (مثل HttpCanary أو ما شابه). يرجى إيقاف أداة السحب للمتابعة.',
          });
          return;
        }
      }

      const fetchTampered = Boolean(NATIVE_FETCH_REF && window.fetch !== NATIVE_FETCH_REF);
      const xhrTampered = Boolean(
        (NATIVE_XHR_OPEN_REF && XMLHttpRequest.prototype.open !== NATIVE_XHR_OPEN_REF) ||
          (NATIVE_XHR_SEND_REF && XMLHttpRequest.prototype.send !== NATIVE_XHR_SEND_REF)
      );

      if (fetchTampered || xhrTampered) {
        if (!reportedRef.current.has('hook_tamper')) {
          reportedRef.current.add('hook_tamper');
          api.reportSecurityTamper({
            type: 'sniffer_blocked',
            reason: 'اكتشاف تعديل أو اعتراض على دوال الشبكة (Fetch/XHR Hook)',
          });
        }
        onBlock({
          code: 'SNIFFER_BLOCKED',
          message:
            'تم حظر الاتصال لحماية البث بسبب اكتشاف إضافة أو برنامج يعترض طلبات الشبكة ويسحب الروابط.',
        });
      }
    };

    const timer = window.setInterval(inspectRuntimeHooks, 3500);
    return () => window.clearInterval(timer);
  }, [policy.blockSniffers, isAdminUnlocked, onBlock]);

  // 2. Anti-DevTools & Network Inspector blocking
  useEffect(() => {
    if (!policy.blockDevTools || isAdminUnlocked) return;

    const onKeyDown = (e: KeyboardEvent) => {
      // Allow Ctrl+Shift+A secret owner shortcut
      if ((e.ctrlKey || e.metaKey) && e.shiftKey && (e.key === 'A' || e.key === 'a')) {
        return;
      }

      const keyLower = (e.key || '').toLowerCase();
      const isInspectorShortcut =
        e.key === 'F12' ||
        ((e.ctrlKey || e.metaKey) &&
          e.shiftKey &&
          (keyLower === 'i' || keyLower === 'j' || keyLower === 'c')) ||
        ((e.ctrlKey || e.metaKey) && keyLower === 'u');

      if (isInspectorShortcut) {
        e.preventDefault();
        e.stopPropagation();
        if (!reportedRef.current.has('devtools_key')) {
          reportedRef.current.add('devtools_key');
          api.reportSecurityTamper({
            type: 'devtools_tamper',
            reason: `محاولة فتح أدوات فحص الشبكة (${e.key})`,
          });
        }
        onBlock({
          code: 'DEVTOOLS_BLOCKED',
          message:
            'تم إيقاف العرض مؤقتاً بسبب محاولة فتح أدوات فحص الشبكة والمصدر. يرجى إغلاق أدوات المطورين للمتابعة.',
        });
      }
    };

    // Only check docked window dimensions on top-level desktop windows (never in iframes, native APKs, or touch devices)
    const checkDesktopDockedInspector = () => {
      if (isNativeApkRuntime()) return;
      const isTopWindow = window.self === window.top;
      const isDesktopPointer =
        window.matchMedia('(pointer: fine)').matches && (navigator.maxTouchPoints || 0) === 0;
      if (!isTopWindow || !isDesktopPointer) return;

      const widthDiff = window.outerWidth - window.innerWidth;
      const heightDiff = window.outerHeight - window.innerHeight;
      if (widthDiff > 240 || heightDiff > 260) {
        if (!reportedRef.current.has('devtools_dock')) {
          reportedRef.current.add('devtools_dock');
          api.reportSecurityTamper({
            type: 'devtools_tamper',
            reason: 'اكتشاف فتح لوحة فحص الشبكة (DevTools) أثناء التشغيل',
          });
        }
        onBlock({
          code: 'DEVTOOLS_BLOCKED',
          message:
            'يرجى إغلاق نافذة فحص الشبكة (DevTools) لإعادة تفعيل المشاهدة المحمية.',
        });
      }
    };

    window.addEventListener('keydown', onKeyDown, true);
    const interval = window.setInterval(checkDesktopDockedInspector, 2500);
    return () => {
      window.removeEventListener('keydown', onKeyDown, true);
      window.clearInterval(interval);
    };
  }, [policy.blockDevTools, isAdminUnlocked, onBlock]);
}

interface SecurityShieldOverlayProps {
  block: SecurityBlockState;
  onCleared: (policy: SecurityPolicyConfig) => void;
  onOpenAdminGate: () => void;
}

export const SecurityShieldOverlay: React.FC<SecurityShieldOverlayProps> = ({
  block,
  onCleared,
  onOpenAdminGate,
}) => {
  const [checking, setChecking] = useState(false);
  const [retryError, setRetryError] = useState<string | null>(null);

  const isVpn = block.code === 'VPN_BLOCKED';
  const isSniffer = block.code === 'SNIFFER_BLOCKED';

  const handleRecheck = async () => {
    setChecking(true);
    setRetryError(null);
    try {
      const res = await api.checkSecurityAccess();
      if (res.ok) {
        onCleared(res.securityPolicy);
      }
    } catch (err: any) {
      setRetryError(err?.message || 'لا يزال سبب الحظر قائماً، يرجى إيقافه ثم المحاولة مجدداً.');
    } finally {
      setChecking(false);
    }
  };

  return (
    <div
      onContextMenu={(e) => e.preventDefault()}
      className="fixed inset-0 z-[85] bg-[#060B16] flex flex-col items-center pt-safe pb-safe px-safe select-none overflow-y-auto overscroll-contain"
      dir="rtl"
    >
      <div className="w-full max-w-md space-y-5 sm:space-y-6 my-auto px-4 py-6">
        <div className="flex justify-center">
          <BrandMark size="lg" />
        </div>

        <div className="bg-[#0B1222] border border-[#1B2947] rounded-2xl p-5 sm:p-7 space-y-5 shadow-2xl">
          <div className="flex flex-col items-center text-center space-y-3">
            <div
              className={`w-14 h-14 rounded-2xl flex items-center justify-center border ${
                isVpn
                  ? 'bg-amber-500/10 border-amber-500/30 text-amber-400'
                  : 'bg-red-500/10 border-red-500/30 text-red-400'
              }`}
            >
              {isVpn ? (
                <WifiOff className="w-7 h-7" />
              ) : isSniffer ? (
                <ShieldAlert className="w-7 h-7" />
              ) : (
                <AlertTriangle className="w-7 h-7" />
              )}
            </div>

            <h1 className="text-base sm:text-lg font-extrabold text-white">
              {isVpn
                ? 'تم حظر الاتصال عبر تطبيقات VPN أو البروكسي'
                : isSniffer
                  ? 'حماية مشددة — تم رصد أداة سحب روابط البث'
                  : 'حماية البث — تم إيقاف أدوات فحص الشبكة'}
            </h1>

            <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
              {retryError || block.message}
            </p>
          </div>

          <div className="p-3.5 rounded-xl bg-[#060B16] border border-[#1B2947] text-xs text-slate-300 space-y-1.5 leading-relaxed">
            {isVpn ? (
              <>
                <div className="font-bold text-white">خطوات المتابعة:</div>
                <div>1. قم بإيقاف تشغيل أي تطبيق VPN أو كاسر بروكسي أو DNS مشفر على جهازك.</div>
                <div>2. اضغط على زر «إعادة الفحص والمتابعة» أدناه للدخول فوراً.</div>
              </>
            ) : isSniffer ? (
              <>
                <div className="font-bold text-white">خطوات المتابعة:</div>
                <div>
                  1. قم بإغلاق تطبيقات التقاط الحزم وسحب الروابط مثل HttpCanary أو Reqable أو PCAPdroid أو أي شهادة اعتراض شبكة.
                </div>
                <div>2. اضغط على «إعادة الفحص والمتابعة» لاستئناف المشاهدة بشكل طبيعي.</div>
              </>
            ) : (
              <>
                <div className="font-bold text-white">خطوات المتابعة:</div>
                <div>1. أغلق نافذة فحص الشبكة (DevTools) أو أي إضافة تتبع في المتصفح.</div>
                <div>2. اضغط على «إعادة الفحص والمتابعة» للعودة إلى القنوات.</div>
              </>
            )}
          </div>

          <button
            type="button"
            disabled={checking}
            onClick={handleRecheck}
            className="w-full min-h-[48px] px-5 py-3 rounded-xl bg-[#1268FB] hover:bg-[#1D74FF] disabled:opacity-60 text-white text-xs sm:text-sm font-extrabold flex items-center justify-center gap-2 cursor-pointer transition-colors"
          >
            <RefreshCw className={`w-4 h-4 ${checking ? 'animate-spin' : ''}`} />
            <span>{checking ? 'جاري فحص الاتصال...' : 'إعادة الفحص والمتابعة'}</span>
          </button>

          <div className="pt-2 border-t border-[#1B2947] flex justify-center">
            <button
              type="button"
              onClick={onOpenAdminGate}
              className="min-h-[44px] px-3 text-xs font-semibold text-slate-400 hover:text-slate-200 flex items-center justify-center gap-1.5 cursor-pointer"
            >
              <Lock className="w-3.5 h-3.5" />
              <span>دخول المدير لإدارة إعدادات الحماية</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
