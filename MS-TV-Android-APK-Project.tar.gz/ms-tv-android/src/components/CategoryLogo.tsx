import React, { useEffect, useState } from 'react';
import {
  Tv,
  Trophy,
  Film,
  Clapperboard,
  Baby,
  Globe,
  BookOpen,
  Music2,
  Crown,
  MoonStar,
  Radio,
  LayoutGrid,
} from 'lucide-react';

interface CategoryLogoProps {
  name: string;
  logo?: string;
  size?: 'xs' | 'sm' | 'md' | 'lg';
  isAll?: boolean;
  className?: string;
}

type CategoryVisual =
  | {
      kind: 'brand';
      bg: string;
      border: string;
      text: string;
      sub?: string;
      accent: string;
    }
  | {
      kind: 'icon';
      bg: string;
      border: string;
      icon:
        | 'all'
        | 'sports'
        | 'movies'
        | 'series'
        | 'kids'
        | 'news'
        | 'islamic'
        | 'docu'
        | 'music'
        | 'vip'
        | 'radio'
        | 'tv';
      iconColor: string;
      tag?: string;
    };

function resolveCategoryVisual(name: string, isAll = false): CategoryVisual {
  if (isAll) {
    return {
      kind: 'icon',
      bg: 'from-[#0D4ED8] to-[#0A2463]',
      border: 'border-blue-400/35',
      icon: 'all',
      iconColor: '#93C5FD',
    };
  }

  const lower = name.toLowerCase();

  // 1. Major Broadcast & Streaming Networks
  if (lower.includes('bein') || lower.includes('بي ان') || lower.includes('بي إن')) {
    return {
      kind: 'brand',
      bg: 'from-[#5B21B6] to-[#2E1065]',
      border: 'border-purple-400/40',
      text: 'beIN',
      sub: 'SPORTS',
      accent: '#D8B4FE',
    };
  }
  if (lower.includes('ssc') || lower.includes('اس اس سي')) {
    return {
      kind: 'brand',
      bg: 'from-[#1E293B] to-[#090D16]',
      border: 'border-amber-400/45',
      text: 'SSC',
      sub: 'SPORT',
      accent: '#FBBF24',
    };
  }
  if (
    lower.includes('alkass') ||
    lower.includes('al kass') ||
    lower.includes('الكأس') ||
    lower.includes('الكاس')
  ) {
    return {
      kind: 'brand',
      bg: 'from-[#881337] to-[#4C0519]',
      border: 'border-rose-400/35',
      text: 'الكأس',
      sub: 'HD',
      accent: '#FDA4AF',
    };
  }
  if (
    lower.includes('abu dhabi') ||
    lower.includes('ad sport') ||
    lower.includes('ابوظبي') ||
    lower.includes('أبوظبي')
  ) {
    return {
      kind: 'brand',
      bg: 'from-[#0369A1] to-[#082F49]',
      border: 'border-sky-400/35',
      text: 'AD',
      sub: 'TV',
      accent: '#7DD3FC',
    };
  }
  if (lower.includes('shahid') || lower.includes('شاهد')) {
    return {
      kind: 'brand',
      bg: 'from-[#065F46] to-[#022C22]',
      border: 'border-emerald-400/40',
      text: 'شاهد',
      sub: 'VIP',
      accent: '#34D399',
    };
  }
  if (lower.includes('mbc') || lower.includes('ام بي سي')) {
    return {
      kind: 'brand',
      bg: 'from-[#991B1B] to-[#450A0A]',
      border: 'border-red-400/40',
      text: 'MBC',
      sub: 'GROUP',
      accent: '#FCA5A5',
    };
  }
  if (lower.includes('osn') || lower.includes('او اس ان')) {
    return {
      kind: 'brand',
      bg: 'from-[#B91C1C] to-[#450A0A]',
      border: 'border-red-400/40',
      text: 'OSN',
      sub: 'PLUS',
      accent: '#FECACA',
    };
  }
  if (lower.includes('netflix') || lower.includes('نتفليكس') || lower.includes('نتفلكس')) {
    return {
      kind: 'brand',
      bg: 'from-[#7F1D1D] to-[#09090B]',
      border: 'border-red-500/45',
      text: 'NETFLIX',
      sub: '4K',
      accent: '#F87171',
    };
  }
  if (lower.includes('rotana') || lower.includes('روتانا')) {
    return {
      kind: 'brand',
      bg: 'from-[#065F46] to-[#064E3B]',
      border: 'border-emerald-400/35',
      text: 'روتانا',
      sub: 'HD',
      accent: '#FDE047',
    };
  }
  if (lower.includes('art ') || lower.startsWith('art') || lower.includes('اي ار تي')) {
    return {
      kind: 'brand',
      bg: 'from-[#1E3A8A] to-[#0F172A]',
      border: 'border-blue-400/35',
      text: 'ART',
      sub: 'NETWORK',
      accent: '#FBBF24',
    };
  }
  if (lower.includes('jazeera') || lower.includes('الجزيرة')) {
    return {
      kind: 'brand',
      bg: 'from-[#78350F] to-[#1C1917]',
      border: 'border-amber-400/40',
      text: 'الجزيرة',
      sub: 'NET',
      accent: '#FBBF24',
    };
  }
  if (lower.includes('sky') || lower.includes('سكاي')) {
    return {
      kind: 'brand',
      bg: 'from-[#1E3A8A] to-[#7F1D1D]',
      border: 'border-blue-400/35',
      text: 'SKY',
      sub: 'HD',
      accent: '#93C5FD',
    };
  }
  if (lower.includes('canal') || lower.includes('كانال')) {
    return {
      kind: 'brand',
      bg: 'from-[#18181B] to-[#09090B]',
      border: 'border-zinc-500/40',
      text: 'C+',
      sub: 'CANAL',
      accent: '#FFFFFF',
    };
  }
  if (lower.includes('starz') || lower.includes('ستارز')) {
    return {
      kind: 'brand',
      bg: 'from-[#0F172A] to-[#020617]',
      border: 'border-cyan-400/35',
      text: 'STARZ',
      sub: 'PLAY',
      accent: '#38BDF8',
    };
  }
  if (lower.includes('watch it') || lower.includes('watchit') || lower.includes('واتش ات')) {
    return {
      kind: 'brand',
      bg: 'from-[#9A3412] to-[#431407]',
      border: 'border-orange-400/40',
      text: 'WATCH',
      sub: 'iT',
      accent: '#FDBA74',
    };
  }
  if (lower.includes('tod') || lower.includes('تود')) {
    return {
      kind: 'brand',
      bg: 'from-[#4C1D95] to-[#1E1B4B]',
      border: 'border-violet-400/40',
      text: 'TOD',
      sub: '4K',
      accent: '#FACC15',
    };
  }
  if (lower.includes('on time') || lower.includes('اون تايم') || lower.includes('أون تايم')) {
    return {
      kind: 'brand',
      bg: 'from-[#991B1B] to-[#18181B]',
      border: 'border-red-400/40',
      text: 'ON',
      sub: 'SPORTS',
      accent: '#FCA5A5',
    };
  }
  if (lower.includes('spacetoon') || lower.includes('سبيستون') || lower.includes('سبيس تون')) {
    return {
      kind: 'brand',
      bg: 'from-[#1D4ED8] to-[#1E1B4B]',
      border: 'border-amber-400/40',
      text: 'ST',
      sub: 'KIDS',
      accent: '#FACC15',
    };
  }

  // 2. Content Genres (Arabic & International)
  if (
    lower.includes('رياض') ||
    lower.includes('كورة') ||
    lower.includes('كرة') ||
    lower.includes('مباريات') ||
    lower.includes('دوري') ||
    lower.includes('sport') ||
    lower.includes('foot') ||
    lower.includes('calcio') ||
    lower.includes('arena') ||
    lower.includes('dazn') ||
    lower.includes('espn') ||
    lower.includes('eurosport')
  ) {
    return {
      kind: 'icon',
      bg: 'from-[#065F46] to-[#022C22]',
      border: 'border-emerald-400/35',
      icon: 'sports',
      iconColor: '#34D399',
    };
  }

  if (
    lower.includes('قرآن') ||
    lower.includes('قران') ||
    lower.includes('إسلام') ||
    lower.includes('اسلام') ||
    lower.includes('ديني') ||
    lower.includes('دينيه') ||
    lower.includes('مكة') ||
    lower.includes('المدين') ||
    lower.includes('quran') ||
    lower.includes('islam') ||
    lower.includes('relig')
  ) {
    return {
      kind: 'icon',
      bg: 'from-[#0F766E] to-[#042F2E]',
      border: 'border-teal-400/35',
      icon: 'islamic',
      iconColor: '#5EEAD4',
    };
  }

  if (
    lower.includes('أفلام') ||
    lower.includes('افلام') ||
    lower.includes('فيلم') ||
    lower.includes('سينما') ||
    lower.includes('movie') ||
    lower.includes('film') ||
    lower.includes('cinema') ||
    lower.includes('vod') ||
    lower.includes('box office') ||
    lower.includes('bluray')
  ) {
    return {
      kind: 'icon',
      bg: 'from-[#9F1239] to-[#4C0519]',
      border: 'border-rose-400/35',
      icon: 'movies',
      iconColor: '#FDA4AF',
    };
  }

  if (
    lower.includes('مسلسل') ||
    lower.includes('دراما') ||
    lower.includes('رمضان') ||
    lower.includes('حلقات') ||
    lower.includes('series') ||
    lower.includes('drama') ||
    lower.includes('animes') ||
    lower.includes('anime') ||
    lower.includes('انمي') ||
    lower.includes('أنمي')
  ) {
    return {
      kind: 'icon',
      bg: 'from-[#6B21A8] to-[#2E1065]',
      border: 'border-purple-400/35',
      icon: 'series',
      iconColor: '#D8B4FE',
    };
  }

  if (
    lower.includes('أطفال') ||
    lower.includes('اطفال') ||
    lower.includes('كرتون') ||
    lower.includes('براعم') ||
    lower.includes('طيور') ||
    lower.includes('ماجد') ||
    lower.includes('kids') ||
    lower.includes('cartoon') ||
    lower.includes('disney') ||
    lower.includes('nick') ||
    lower.includes('junior') ||
    lower.includes('baby')
  ) {
    return {
      kind: 'icon',
      bg: 'from-[#B45309] to-[#451A03]',
      border: 'border-amber-400/40',
      icon: 'kids',
      iconColor: '#FCD34D',
    };
  }

  if (
    lower.includes('أخبار') ||
    lower.includes('اخبار') ||
    lower.includes('إخبار') ||
    lower.includes('عاجل') ||
    lower.includes('news') ||
    lower.includes('info') ||
    lower.includes('cnn') ||
    lower.includes('bbc') ||
    lower.includes('france 24')
  ) {
    return {
      kind: 'icon',
      bg: 'from-[#0369A1] to-[#082F49]',
      border: 'border-sky-400/35',
      icon: 'news',
      iconColor: '#7DD3FC',
    };
  }

  if (
    lower.includes('وثائق') ||
    lower.includes('ثقاف') ||
    lower.includes('طبيعة') ||
    lower.includes('علوم') ||
    lower.includes('ناشيونال') ||
    lower.includes('ديسكفري') ||
    lower.includes('docu') ||
    lower.includes('nat geo') ||
    lower.includes('discovery') ||
    lower.includes('history') ||
    lower.includes('animal')
  ) {
    return {
      kind: 'icon',
      bg: 'from-[#0E7490] to-[#083344]',
      border: 'border-cyan-400/35',
      icon: 'docu',
      iconColor: '#67E8F9',
    };
  }

  if (lower.includes('راديو') || lower.includes('إذاع') || lower.includes('اذاع') || lower.includes('radio')) {
    return {
      kind: 'icon',
      bg: 'from-[#3730A3] to-[#1E1B4B]',
      border: 'border-indigo-400/35',
      icon: 'radio',
      iconColor: '#A5B4FC',
    };
  }

  if (
    lower.includes('موسيق') ||
    lower.includes('أغاني') ||
    lower.includes('اغاني') ||
    lower.includes('طرب') ||
    lower.includes('وناسة') ||
    lower.includes('ترفيه') ||
    lower.includes('منوعات') ||
    lower.includes('music') ||
    lower.includes('entertainment')
  ) {
    return {
      kind: 'icon',
      bg: 'from-[#9D174D] to-[#4A044E]',
      border: 'border-pink-400/35',
      icon: 'music',
      iconColor: '#F9A8D4',
    };
  }

  if (
    lower.includes('vip') ||
    lower.includes('4k') ||
    lower.includes('uhd') ||
    lower.includes('raw') ||
    lower.includes('مميز') ||
    lower.includes('باقة خاصة')
  ) {
    return {
      kind: 'icon',
      bg: 'from-[#92400E] to-[#3B1906]',
      border: 'border-amber-400/45',
      icon: 'vip',
      iconColor: '#FDE047',
    };
  }

  // 3. Regional / Country Broadcast Packages
  const countryBadges: Array<{ keys: string[]; code: string; sub: string; bg: string }> = [
    { keys: ['سعود', 'saudi', 'ksa', '| sa', 'sa |', 'sa:'], code: 'KSA', sub: 'TV', bg: 'from-[#065F46] to-[#022C22]' },
    { keys: ['مصر', 'egypt', '| eg', 'eg |', 'eg:'], code: 'EGY', sub: 'TV', bg: 'from-[#991B1B] to-[#1E293B]' },
    { keys: ['إمارات', 'امارات', 'uae', 'dubai', 'دبي', '| ae', 'ae |'], code: 'UAE', sub: 'TV', bg: 'from-[#0F766E] to-[#0F172A]' },
    { keys: ['قطر', 'qatar', '| qa', 'qa |'], code: 'QAT', sub: 'TV', bg: 'from-[#881337] to-[#270915]' },
    { keys: ['كويت', 'kuwait', '| kw', 'kw |'], code: 'KWT', sub: 'TV', bg: 'from-[#0369A1] to-[#0F172A]' },
    { keys: ['عراق', 'iraq', '| iq', 'iq |'], code: 'IRQ', sub: 'TV', bg: 'from-[#1E3A8A] to-[#0F172A]' },
    { keys: ['مغرب', 'morocco', 'maroc', '| ma', 'ma |'], code: 'MAR', sub: 'TV', bg: 'from-[#991B1B] to-[#064E3B]' },
    { keys: ['جزائر', 'algeria', 'algerie', '| dz', 'dz |'], code: 'ALG', sub: 'TV', bg: 'from-[#065F46] to-[#1E293B]' },
    { keys: ['تونس', 'tunisia', 'tunisie', '| tn', 'tn |'], code: 'TUN', sub: 'TV', bg: 'from-[#991B1B] to-[#450A0A]' },
    { keys: ['شام', 'سوري', 'syria', '| sy', 'sy |'], code: 'SYR', sub: 'TV', bg: 'from-[#1E3A8A] to-[#0F172A]' },
    { keys: ['لبنان', 'lebanon', '| lb', 'lb |'], code: 'LBN', sub: 'TV', bg: 'from-[#991B1B] to-[#064E3B]' },
    { keys: ['أردن', 'اردن', 'jordan', '| jo', 'jo |'], code: 'JOR', sub: 'TV', bg: 'from-[#1E293B] to-[#7F1D1D]' },
    { keys: ['فلسطين', 'palestine', '| ps', 'ps |'], code: 'PAL', sub: 'TV', bg: 'from-[#065F46] to-[#7F1D1D]' },
    { keys: ['يمن', 'yemen', '| ye', 'ye |'], code: 'YEM', sub: 'TV', bg: 'from-[#7F1D1D] to-[#0F172A]' },
    { keys: ['سودان', 'sudan', '| sd', 'sd |'], code: 'SDN', sub: 'TV', bg: 'from-[#065F46] to-[#1E293B]' },
    { keys: ['ليبيا', 'libya', '| ly', 'ly |'], code: 'LBY', sub: 'TV', bg: 'from-[#1E293B] to-[#065F46]' },
    { keys: ['عمان', 'oman', '| om', 'om |'], code: 'OMN', sub: 'TV', bg: 'from-[#991B1B] to-[#065F46]' },
    { keys: ['بحرين', 'bahrain', '| bh', 'bh |'], code: 'BHR', sub: 'TV', bg: 'from-[#991B1B] to-[#3B0812]' },
    { keys: ['كرد', 'kurd'], code: 'KUR', sub: 'TV', bg: 'from-[#065F46] to-[#78350F]' },
    { keys: ['ترك', 'turk', '| tr', 'tr |', 'tr:'], code: 'TR', sub: 'TV', bg: 'from-[#991B1B] to-[#450A0A]' },
    { keys: ['فرنس', 'france', 'french', '| fr', 'fr |', 'fr:'], code: 'FR', sub: 'TV', bg: 'from-[#1D4ED8] to-[#7F1D1D]' },
    { keys: ['بريطان', 'انجليز', 'english', '| uk', 'uk |', 'uk:', '| us', 'us |', 'usa'], code: 'EN', sub: 'TV', bg: 'from-[#1E3A8A] to-[#0F172A]' },
    { keys: ['ألمان', 'المان', 'german', '| de', 'de |', 'de:'], code: 'DE', sub: 'TV', bg: 'from-[#1E293B] to-[#78350F]' },
    { keys: ['إسبان', 'اسبان', 'spain', 'spanish', '| es', 'es |', 'es:'], code: 'ES', sub: 'TV', bg: 'from-[#991B1B] to-[#78350F]' },
    { keys: ['إيطال', 'ايطال', 'ital', '| it', 'it |', 'it:'], code: 'IT', sub: 'TV', bg: 'from-[#065F46] to-[#7F1D1D]' },
    { keys: ['عرب', 'arab', 'خليج', 'gulf', '| ar', 'ar |', 'ar:'], code: 'AR', sub: 'TV', bg: 'from-[#1D4ED8] to-[#0A1E4E]' },
  ];

  for (const c of countryBadges) {
    if (c.keys.some((k) => lower.includes(k))) {
      return {
        kind: 'brand',
        bg: c.bg,
        border: 'border-white/15',
        text: c.code,
        sub: c.sub,
        accent: '#93C5FD',
      };
    }
  }

  // 4. Clean Broadcast TV Emblem Fallback
  return {
    kind: 'icon',
    bg: 'from-[#162C63] to-[#0B1530]',
    border: 'border-blue-400/30',
    icon: 'tv',
    iconColor: '#60A5FA',
  };
}

export const CategoryLogo: React.FC<CategoryLogoProps> = ({
  name,
  logo,
  size = 'md',
  isAll = false,
  className = '',
}) => {
  const [imgFailed, setImgFailed] = useState(false);

  useEffect(() => {
    setImgFailed(false);
  }, [logo]);

  const visual = resolveCategoryVisual(name, isAll);

  const boxSize = {
    xs: 'w-7 h-7 rounded-lg',
    sm: 'w-9 h-9 rounded-xl',
    md: 'w-12 h-12 rounded-xl',
    lg: 'w-14 h-14 rounded-2xl',
  }[size];

  const iconSize = {
    xs: 'w-3.5 h-3.5',
    sm: 'w-4 h-4',
    md: 'w-5 h-5',
    lg: 'w-6 h-6',
  }[size];

  const brandTextSize = {
    xs: 'text-[9px]',
    sm: 'text-[10px]',
    md: 'text-xs',
    lg: 'text-sm',
  }[size];

  const showCustomImg = Boolean(logo && logo.trim() && !imgFailed);

  const renderGlyph = () => {
    if (visual.kind !== 'icon') return null;
    const props = { className: iconSize, style: { color: visual.iconColor } };
    switch (visual.icon) {
      case 'all':
        return <LayoutGrid {...props} />;
      case 'sports':
        return <Trophy {...props} />;
      case 'movies':
        return <Film {...props} />;
      case 'series':
        return <Clapperboard {...props} />;
      case 'kids':
        return <Baby {...props} />;
      case 'news':
        return <Globe {...props} />;
      case 'islamic':
        return <MoonStar {...props} />;
      case 'docu':
        return <BookOpen {...props} />;
      case 'music':
        return <Music2 {...props} />;
      case 'vip':
        return <Crown {...props} />;
      case 'radio':
        return <Radio {...props} />;
      default:
        return <Tv {...props} />;
    }
  };

  return (
    <div
      className={`relative overflow-hidden bg-gradient-to-br ${visual.bg} border ${visual.border} flex flex-col items-center justify-center shrink-0 select-none shadow-sm ${boxSize} ${className}`}
    >
      {showCustomImg ? (
        <img
          src={logo}
          alt={name}
          referrerPolicy="no-referrer"
          loading="lazy"
          draggable={false}
          onError={() => setImgFailed(true)}
          className="w-full h-full object-contain p-1 bg-[#080F1E]/90"
        />
      ) : visual.kind === 'brand' ? (
        <div className="flex flex-col items-center justify-center px-1 text-center leading-none">
          <span
            className={`font-display font-extrabold tracking-tight truncate max-w-full text-white ${brandTextSize}`}
          >
            {visual.text}
          </span>
          {size !== 'xs' && visual.sub && (
            <span
              className="font-display text-[7px] font-bold tracking-wider mt-0.5 opacity-95"
              style={{ color: visual.accent }}
            >
              {visual.sub}
            </span>
          )}
        </div>
      ) : (
        renderGlyph()
      )}
    </div>
  );
};
