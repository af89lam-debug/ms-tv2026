import React, { useState } from 'react';

interface ChannelLogoProps {
  name: string;
  logo?: string;
  group?: string;
  size?: 'sm' | 'md' | 'lg' | 'wide';
  className?: string;
}

function getBrandStyle(name: string, group = '') {
  const lower = `${name} ${group}`.toLowerCase();

  if (lower.includes('bein') || lower.includes('بي ان') || lower.includes('بي إن')) {
    return { bg: 'from-[#4C1D95] to-[#2E1065]', text: 'beIN', sub: 'SPORTS', accentClass: 'text-purple-300' };
  }
  if (lower.includes('mbc') || lower.includes('ام بي سي')) {
    return { bg: 'from-[#991B1B] to-[#450A0A]', text: 'MBC', sub: 'HD', accentClass: 'text-red-300' };
  }
  if (lower.includes('osn')) {
    return { bg: 'from-[#B91C1C] to-[#7F1D1D]', text: 'OSN', sub: 'PLUS', accentClass: 'text-red-200' };
  }
  if (lower.includes('sky')) {
    return { bg: 'from-[#1E3A8A] to-[#991B1B]', text: 'sky', sub: 'NEWS HD', accentClass: 'text-blue-300' };
  }
  if (lower.includes('jazeera') || lower.includes('الجزيرة')) {
    return { bg: 'from-[#422006] to-[#1C1917]', text: 'الجزيرة', sub: 'LIVE', accentClass: 'text-amber-400' };
  }
  if (lower.includes('bbc')) {
    return { bg: 'from-[#991B1B] to-[#7F1D1D]', text: 'BBC', sub: 'WORLD', accentClass: 'text-white' };
  }
  if (lower.includes('trt')) {
    return { bg: 'from-[#1E3A8A] to-[#0F172A]', text: 'TRT', sub: 'ARABI', accentClass: 'text-blue-400' };
  }
  if (lower.includes('france') || lower.includes('فرانس')) {
    return { bg: 'from-[#0369A1] to-[#0C4A6E]', text: 'F24', sub: 'ARABIC', accentClass: 'text-sky-300' };
  }
  if (lower.includes('dw')) {
    return { bg: 'from-[#1D4ED8] to-[#1E293B]', text: 'DW', sub: 'عربية', accentClass: 'text-blue-300' };
  }
  if (lower.includes('nasa')) {
    return { bg: 'from-[#1E3A8A] to-[#090D16]', text: 'NASA', sub: 'TV UHD', accentClass: 'text-blue-400' };
  }
  if (lower.includes('red bull')) {
    return { bg: 'from-[#1D4ED8] to-[#991B1B]', text: 'RB TV', sub: 'SPORTS', accentClass: 'text-yellow-300' };
  }
  if (lower.includes('cn') || lower.includes('cartoon') || lower.includes('أطفال') || lower.includes('كرتون')) {
    return { bg: 'from-[#18181B] to-[#27272A]', text: 'KIDS', sub: 'TV', accentClass: 'text-yellow-400' };
  }
  if (lower.includes('رياض') || lower.includes('sport') || lower.includes('on time')) {
    return { bg: 'from-[#065F46] to-[#022C22]', text: 'SPORT', sub: 'LIVE', accentClass: 'text-emerald-400' };
  }

  const trimmed = name.trim();
  const words = trimmed.split(/\s+/).filter(Boolean);
  const initials =
    words.length >= 2
      ? `${words[0][0] || ''}${words[1][0] || ''}`.toUpperCase()
      : trimmed.slice(0, 3).toUpperCase();

  return {
    bg: 'from-[#172554] to-[#0F172A]',
    text: initials || 'TV',
    sub: 'HD',
    accentClass: 'text-blue-400',
  };
}

export const ChannelLogo: React.FC<ChannelLogoProps> = ({
  name,
  logo,
  group,
  size = 'md',
  className = '',
}) => {
  const [imgFailed, setImgFailed] = useState(false);
  const style = getBrandStyle(name, group);

  const sizeClasses = {
    sm: 'w-9 h-9 sm:w-10 sm:h-10 rounded-lg text-[10px] sm:text-[11px]',
    md: 'w-11 h-11 sm:w-12 sm:h-12 rounded-xl text-xs',
    lg: 'w-14 h-14 sm:w-16 sm:h-16 rounded-xl text-sm',
    wide: 'w-full h-full rounded-xl text-xs sm:text-sm',
  }[size];

  const showImg = Boolean(logo && logo.trim() && !imgFailed);

  return (
    <div
      className={`relative overflow-hidden bg-gradient-to-br ${style.bg} border border-white/10 flex flex-col items-center justify-center shrink-0 select-none ${sizeClasses} ${className}`}
    >
      {showImg ? (
        <img
          src={logo}
          alt={name}
          referrerPolicy="no-referrer"
          loading="lazy"
          onError={() => setImgFailed(true)}
          className="w-full h-full object-contain p-1 bg-[#0B1222]/80"
        />
      ) : (
        <div className="flex flex-col items-center justify-center px-1 text-center leading-none">
          <span className="font-display font-extrabold tracking-tight truncate max-w-full text-white">
            {style.text}
          </span>
          <span
            className={`font-display text-[8px] font-bold tracking-widest mt-0.5 opacity-90 ${style.accentClass}`}
          >
            {style.sub}
          </span>
        </div>
      )}
    </div>
  );
};
