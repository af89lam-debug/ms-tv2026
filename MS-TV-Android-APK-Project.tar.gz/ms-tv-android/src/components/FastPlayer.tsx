import React, { useEffect, useRef, useState, useCallback } from 'react';
import Hls from 'hls.js';
import mpegts from 'mpegts.js';
import {
  Play,
  Pause,
  Volume2,
  VolumeX,
  Maximize2,
  Minimize2,
  RefreshCw,
  Star,
  ListVideo,
  ChevronRight,
  ChevronLeft,
  Tv,
  ArrowRight,
  Settings2,
  Edit3,
  ShieldCheck,
  Scan,
  X,
} from 'lucide-react';
import type { CategorySummary, Channel } from '../types';
import { api, buildFastSessionStreamUrl, buildProtectedStreamUrl } from '../api';
import { ChannelLogo } from './ChannelLogo';

type EngineMode = 'auto' | 'hls' | 'mpegts' | 'native';
type AspectMode = 'contain' | 'cover' | 'fill';

interface FastPlayerProps {
  channel: Channel | null;
  isOpen: boolean;
  streamSessionToken?: string | null;
  allChannels: Channel[];
  categories: CategorySummary[];
  favorites: string[];
  isAdminUnlocked: boolean;
  onClose: () => void;
  onSelectChannel: (channel: Channel) => void;
  onToggleFavorite: (channelId: string) => void;
  onEditChannel?: (channel: Channel) => void;
  onSecurityBlock?: (block: {
    code: 'VPN_BLOCKED' | 'SNIFFER_BLOCKED';
    message: string;
  }) => void;
  onMaintenanceMode?: (message: string) => void;
}

export const FastPlayer: React.FC<FastPlayerProps> = ({
  channel,
  isOpen,
  streamSessionToken,
  allChannels,
  categories,
  favorites,
  isAdminUnlocked,
  onClose,
  onSelectChannel,
  onToggleFavorite,
  onEditChannel,
  onSecurityBlock,
  onMaintenanceMode,
}) => {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const playerContainerRef = useRef<HTMLDivElement | null>(null);
  const hlsRef = useRef<Hls | null>(null);
  const mpegtsRef = useRef<mpegts.Player | null>(null);
  const hideTimerRef = useRef<number | null>(null);
  const ticketRenewTimerRef = useRef<number | null>(null);
  const reconnectTimerRef = useRef<number | null>(null);
  const startupTimerRef = useRef<number | null>(null);
  const healthyTimerRef = useRef<number | null>(null);
  const activeTicketRef = useRef<string | null>(null);
  const activePlayIdRef = useRef<string | null>(null);
  const streamSessionTokenRef = useRef<string | null | undefined>(streamSessionToken);
  const userPausedRef = useRef<boolean>(false);
  const hasPlayedRef = useRef<boolean>(false);
  const autoRecoverCountRef = useRef<number>(0);
  const forceEdgeRefreshRef = useRef<boolean>(false);
  const forceTicketFallbackRef = useRef<boolean>(false);
  const learnedEngineRef = useRef<Map<string, 'hls' | 'mpegts' | 'native'>>(new Map());
  const lastProgressRef = useRef<{ time: number; ts: number }>({ time: 0, ts: Date.now() });

  streamSessionTokenRef.current = streamSessionToken;

  const [isPlaying, setIsPlaying] = useState(true);
  const [isMuted, setIsMuted] = useState(false);
  const [volume, setVolume] = useState(0.95);
  const [isBuffering, setIsBuffering] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [engineMode, setEngineMode] = useState<EngineMode>('auto');
  const [aspectMode, setAspectMode] = useState<AspectMode>('contain');
  const [reloadNonce, setReloadNonce] = useState(0);
  const [levels, setLevels] = useState<Array<{ index: number; label: string }>>([]);
  const [currentLevel, setCurrentLevel] = useState<number>(-1);

  // Clean UI Visibility States (Auto-hide after 2.8s so player is never intrusive)
  const [controlsVisible, setControlsVisible] = useState(true);
  const [showSettingsMenu, setShowSettingsMenu] = useState(false);
  const [showZapper, setShowZapper] = useState(false);
  const [zapperGroup, setZapperGroup] = useState<string>('ALL');
  const [zapperSearch, setZapperSearch] = useState('');
  const [isNativeFullscreen, setIsNativeFullscreen] = useState(false);

  const scheduleAutoHide = useCallback(() => {
    if (hideTimerRef.current) {
      window.clearTimeout(hideTimerRef.current);
    }
    setControlsVisible(true);
    hideTimerRef.current = window.setTimeout(() => {
      setControlsVisible((prev) => {
        if (showZapper || showSettingsMenu) return prev;
        return false;
      });
    }, 2800);
  }, [showZapper, showSettingsMenu]);

  useEffect(() => {
    if (isOpen) {
      scheduleAutoHide();
    }
    return () => {
      if (hideTimerRef.current) window.clearTimeout(hideTimerRef.current);
    };
  }, [isOpen, channel?.id, scheduleAutoHide]);

  const stopEnginesOnly = useCallback(() => {
    if (hlsRef.current) {
      try {
        hlsRef.current.destroy();
      } catch {
        // ignore
      }
      hlsRef.current = null;
    }
    if (mpegtsRef.current) {
      try {
        mpegtsRef.current.pause();
        mpegtsRef.current.unload();
        mpegtsRef.current.detachMediaElement();
        mpegtsRef.current.destroy();
      } catch {
        // ignore
      }
      mpegtsRef.current = null;
    }
    if (videoRef.current) {
      try {
        videoRef.current.onerror = null;
        videoRef.current.removeAttribute('src');
        videoRef.current.load();
      } catch {
        // ignore
      }
    }
  }, []);

  const cleanupEngines = useCallback(() => {
    if (ticketRenewTimerRef.current) {
      window.clearTimeout(ticketRenewTimerRef.current);
      ticketRenewTimerRef.current = null;
    }
    if (reconnectTimerRef.current) {
      window.clearTimeout(reconnectTimerRef.current);
      reconnectTimerRef.current = null;
    }
    if (startupTimerRef.current) {
      window.clearTimeout(startupTimerRef.current);
      startupTimerRef.current = null;
    }
    if (healthyTimerRef.current) {
      window.clearTimeout(healthyTimerRef.current);
      healthyTimerRef.current = null;
    }
    stopEnginesOnly();
    const prevTicket = activeTicketRef.current;
    const prevPlayId = activePlayIdRef.current;
    activeTicketRef.current = null;
    activePlayIdRef.current = null;
    if (prevTicket && prevPlayId) {
      api.releaseStream(prevTicket, { playId: prevPlayId, reason: 'cleanup' });
    }
  }, [stopEnginesOnly]);

  // Authenticated short-lease heartbeat (keeps stream alive inside the app while expiring stolen links outside)
  useEffect(() => {
    if (!isOpen || !channel) return;
    const hbTimer = window.setInterval(async () => {
      const ticket = activeTicketRef.current;
      if (!ticket) return;
      try {
        await api.sendStreamHeartbeat(ticket, channel.id);
      } catch (err: any) {
        if (err?.code === 'MAINTENANCE_MODE') {
          stopEnginesOnly();
          setIsBuffering(false);
          onMaintenanceMode?.(
            err?.message || 'التطبيق في وضع الصيانة يرجى المحاولة لاحقاً'
          );
          return;
        }
        if (err?.status === 401 || err?.status === 403) {
          stopEnginesOnly();
          setIsBuffering(false);
          setErrorMsg(err?.message || 'تم إيقاف البث لانتهاء الجلسة أو لتفعيل أداة محظورة.');
          if (err?.code === 'VPN_BLOCKED' || err?.code === 'SNIFFER_BLOCKED') {
            onSecurityBlock?.({ code: err.code, message: err.message });
          }
        }
      }
    }, 38000);

    return () => window.clearInterval(hbTimer);
  }, [isOpen, channel?.id, stopEnginesOnly, onSecurityBlock, onMaintenanceMode]);

  // Reset recovery counters whenever user switches channel or engine mode
  useEffect(() => {
    autoRecoverCountRef.current = 0;
    hasPlayedRef.current = false;
    userPausedRef.current = false;
    forceEdgeRefreshRef.current = false;
    forceTicketFallbackRef.current = false;
  }, [channel?.id, engineMode]);

  useEffect(() => {
    if (!isOpen || !channel) {
      cleanupEngines();
      return;
    }

    const video = videoRef.current;
    if (!video) return;

    setErrorMsg(null);
    setIsBuffering(true);
    setLevels([]);
    setCurrentLevel(-1);
    setShowSettingsMenu(false);

    video.volume = volume;
    video.muted = isMuted;
    lastProgressRef.current = { time: 0, ts: Date.now() };

    let cancelled = false;
    const playId = `p_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 8)}`;
    activePlayIdRef.current = playId;
    const attemptedEngines = new Set<'hls' | 'mpegts' | 'native'>();

    const clearStartupWatchdog = () => {
      if (startupTimerRef.current) {
        window.clearTimeout(startupTimerRef.current);
        startupTimerRef.current = null;
      }
    };

    const scheduleSilentReconnect = (delayMs?: number) => {
      if (cancelled) return;
      clearStartupWatchdog();
      if (autoRecoverCountRef.current >= 5) {
        setIsBuffering(false);
        setErrorMsg('انقطع البث من المصدر الأصلي، اضغط إعادة المحاولة لتحديث الاتصال.');
        return;
      }
      autoRecoverCountRef.current += 1;
      forceEdgeRefreshRef.current = true;
      setIsBuffering(true);
      setErrorMsg(null);

      const wait = delayMs ?? Math.min(3500, 650 * autoRecoverCountRef.current);
      if (reconnectTimerRef.current) window.clearTimeout(reconnectTimerRef.current);
      reconnectTimerRef.current = window.setTimeout(() => {
        if (!cancelled) {
          setReloadNonce((n) => n + 1);
        }
      }, wait);
    };

    const safePlay = () => {
      const v = videoRef.current;
      if (!v || cancelled || userPausedRef.current) return;
      v.play().catch(() => {
        if (videoRef.current && !cancelled && !userPausedRef.current) {
          videoRef.current.muted = true;
          setIsMuted(true);
          videoRef.current.play().catch(() => {});
        }
      });
    };

    const launchWithTicket = async () => {
      const shouldRefreshEdge = forceEdgeRefreshRef.current;
      forceEdgeRefreshRef.current = false;

      const currentSessionToken = streamSessionTokenRef.current;
      const useFastSession = Boolean(currentSessionToken && !forceTicketFallbackRef.current);
      let activeTicket = '';
      let formatHint = channel.streamFormat || 'auto';

      if (useFastSession && currentSessionToken) {
        // 0ms Instant Single-Round-Trip Launch — zero waiting for /api/stream-ticket!
        activeTicket = currentSessionToken;
      } else {
        try {
          const ticketData = await api.issueStreamTicket(channel.id, {
            refreshEdge: shouldRefreshEdge,
          });
          activeTicket = ticketData.ticket;
          formatHint = ticketData.streamFormat || formatHint;
        } catch (err: any) {
          if (!cancelled) {
            if (err?.code === 'MAINTENANCE_MODE') {
              setIsBuffering(false);
              onMaintenanceMode?.(
                err?.message || 'التطبيق في وضع الصيانة يرجى المحاولة لاحقاً'
              );
              return;
            }
            if (err?.code === 'VPN_BLOCKED' || err?.code === 'SNIFFER_BLOCKED') {
              setIsBuffering(false);
              setErrorMsg(err?.message || 'تم حظر الاتصال لحماية البث.');
              onSecurityBlock?.({ code: err.code, message: err.message });
              return;
            }
            if (err?.status !== 401 && err?.status !== 403 && autoRecoverCountRef.current < 3) {
              scheduleSilentReconnect(600);
              return;
            }
            setIsBuffering(false);
            setErrorMsg(err?.message || 'تعذر التحقق من صلاحية البث.');
          }
          return;
        }
      }

      if (cancelled || !videoRef.current) return;

      activeTicketRef.current = activeTicket;

      const buildEngineUrl = (eng: 'hls' | 'mpegts' | 'native') =>
        useFastSession && currentSessionToken
          ? buildFastSessionStreamUrl(currentSessionToken, channel.id, eng, {
              refreshEdge: shouldRefreshEdge,
              nonce: reloadNonce,
              playId,
            })
          : buildProtectedStreamUrl(activeTicket, eng, playId);

      // Renew 6-hour rolling stream session silently at 5.5 hours for continuous viewing
      ticketRenewTimerRef.current = window.setTimeout(() => {
        if (!cancelled && channel.contentType === 'live') {
          forceTicketFallbackRef.current = true;
          setReloadNonce((n) => n + 1);
        }
      }, 330 * 60 * 1000);

      const canSafariNativeHls = Boolean(
        videoRef.current.canPlayType('application/vnd.apple.mpegurl')
      );
      const isDedicatedMpegTs = formatHint === 'mpegts' && mpegts.isSupported();

      const armStartupWatchdog = (currentEng: 'hls' | 'mpegts' | 'native') => {
        clearStartupWatchdog();
        if (channel.contentType !== 'live') return;
        startupTimerRef.current = window.setTimeout(() => {
          if (cancelled || hasPlayedRef.current || userPausedRef.current) return;
          if (engineMode === 'auto') {
            // Do NOT auto-switch dedicated Xtream .ts streams to HLS on timeout (touching .m3u8 locks max_connections=1 panels for 60s!)
            if (
              currentEng === 'mpegts' &&
              !isDedicatedMpegTs &&
              !attemptedEngines.has('hls') &&
              Hls.isSupported()
            ) {
              startHls();
              return;
            }
            if (currentEng === 'hls' && !attemptedEngines.has('mpegts') && mpegts.isSupported()) {
              startMpegTs();
              return;
            }
          }
          if (autoRecoverCountRef.current < 4) {
            scheduleSilentReconnect(350);
          }
        }, 6500);
      };

      const triggerTicketFallbackOnAuthStatus = (httpCode: number): boolean => {
        if (useFastSession && (httpCode === 401 || httpCode === 403)) {
          forceTicketFallbackRef.current = true;
          setReloadNonce((n) => n + 1);
          return true;
        }
        return false;
      };

      const startNative = (protocolHint: 'native' | 'hls' = 'native') => {
        if (cancelled || !videoRef.current) return;
        attemptedEngines.add('native');
        stopEnginesOnly();
        armStartupWatchdog('native');
        const url = buildEngineUrl(protocolHint);
        videoRef.current.src = url;
        videoRef.current.onerror = () => {
          if (cancelled) return;
          if (hasPlayedRef.current && channel.contentType === 'live') {
            scheduleSilentReconnect(700);
            return;
          }
          if (engineMode === 'auto' && !attemptedEngines.has('mpegts') && mpegts.isSupported()) {
            startMpegTs();
          } else if (engineMode === 'auto' && !attemptedEngines.has('hls') && Hls.isSupported()) {
            startHls();
          } else if (useFastSession && !forceTicketFallbackRef.current) {
            forceTicketFallbackRef.current = true;
            setReloadNonce((n) => n + 1);
          } else if (autoRecoverCountRef.current < 3) {
            scheduleSilentReconnect(650);
          } else {
            setIsBuffering(false);
            setErrorMsg('تعذر تشغيل هذا المصدر حالياً، قد تكون القناة متوقفة من المصدر الأصلي.');
          }
        };
        safePlay();
      };

      const startMpegTs = () => {
        if (cancelled || !videoRef.current) return;
        attemptedEngines.add('mpegts');
        stopEnginesOnly();
        armStartupWatchdog('mpegts');
        const url = buildEngineUrl('mpegts');

        if (mpegts.isSupported()) {
          try {
            const player = mpegts.createPlayer(
              {
                type: 'mpegts',
                isLive: channel.contentType === 'live',
                url,
                cors: true,
              },
              {
                enableWorker: false,
                enableStashBuffer: true,
                stashInitialSize: 32 * 1024,
                lazyLoad: false,
                fixAudioTimestampGap: true,
                autoCleanupSourceBuffer: true,
                autoCleanupMaxBackwardDuration: 45,
                autoCleanupMinBackwardDuration: 20,
                liveBufferLatencyChasing: true,
                liveBufferLatencyMaxLatency: 8,
                liveBufferLatencyMinRemain: 2.5,
              }
            );
            mpegtsRef.current = player;
            player.attachMediaElement(videoRef.current);
            player.load();
            const playPromise = player.play();
            if (playPromise && typeof (playPromise as Promise<void>).catch === 'function') {
              (playPromise as Promise<void>).catch(() => safePlay());
            }

            // Live IPTV .ts streams occasionally close HTTP EOF mid-broadcast without emitting ERROR;
            // auto-reconnect seamlessly so the picture never freezes!
            player.on(mpegts.Events.LOADING_COMPLETE, () => {
              if (cancelled) return;
              if (channel.contentType === 'live' && !userPausedRef.current) {
                scheduleSilentReconnect(500);
              }
            });

            player.on(mpegts.Events.ERROR, (_errType: any, errDetail: any, errInfo: any) => {
              if (cancelled) return;
              const httpCode = Number(errInfo?.code || 0);
              if (httpCode === 499) return;

              if (triggerTicketFallbackOnAuthStatus(httpCode)) {
                return;
              }

              // Server detected an #EXTM3U playlist on a stream requested as mpegts -> switch to HLS immediately!
              if (httpCode === 415 && engineMode === 'auto' && !attemptedEngines.has('hls')) {
                learnedEngineRef.current.set(channel.id, 'hls');
                startHls();
                return;
              }

              // If stream was already playing frames, perform silent self-healing reconnect instead of showing error
              if (hasPlayedRef.current && channel.contentType === 'live') {
                scheduleSilentReconnect(700);
                return;
              }

              // For dedicated MPEG-TS live streams on MSE browsers, retry mpegts directly instead of touching .m3u8
              if (isDedicatedMpegTs) {
                if (autoRecoverCountRef.current < 4) {
                  scheduleSilentReconnect(550);
                } else {
                  setIsBuffering(false);
                  setErrorMsg(
                    errDetail
                      ? 'تعذر تشغيل البث حالياً، جرب تحديث البث أو اختيار قناة أخرى.'
                      : 'تعذر تشغيل البث حالياً.'
                  );
                }
                return;
              }

              if (engineMode === 'auto' && !attemptedEngines.has('hls') && httpCode !== 401) {
                startHls();
              } else if (
                engineMode === 'auto' &&
                !attemptedEngines.has('native') &&
                canSafariNativeHls
              ) {
                startNative('hls');
              } else if (autoRecoverCountRef.current < 3) {
                scheduleSilentReconnect(650);
              } else {
                setIsBuffering(false);
                setErrorMsg(
                  errDetail
                    ? 'تعذر تشغيل البث حالياً، جرب تحديث البث أو اختيار قناة أخرى.'
                    : 'تعذر تشغيل البث حالياً.'
                );
              }
            });
          } catch {
            if (!attemptedEngines.has('hls') && Hls.isSupported()) {
              startHls();
            } else if (!attemptedEngines.has('native')) {
              startNative(canSafariNativeHls ? 'hls' : 'native');
            } else {
              setIsBuffering(false);
              setErrorMsg('تعذر تشغيل البث حالياً.');
            }
          }
        } else if (canSafariNativeHls) {
          startNative('hls');
        } else {
          startNative('native');
        }
      };

      const startHls = () => {
        if (cancelled || !videoRef.current) return;
        attemptedEngines.add('hls');
        stopEnginesOnly();
        armStartupWatchdog('hls');
        const url = buildEngineUrl('hls');

        if (Hls.isSupported()) {
          let networkRecoveryCount = 0;
          let lastMediaRecoveryAt = 0;
          let swappedCodec = false;

          const hls = new Hls({
            enableWorker: true,
            lowLatencyMode: false,
            startFragPrefetch: true,
            liveSyncDurationCount: 2,
            liveMaxLatencyDurationCount: 7,
            backBufferLength: 15,
            maxBufferLength: 20,
            maxMaxBufferLength: 40,
            abrEwmaDefaultEstimate: 2500000,
            maxBufferHole: 1.2,
            highBufferWatchdogPeriod: 2,
            nudgeOffset: 0.2,
            nudgeMaxRetry: 8,
            manifestLoadingTimeOut: 9000,
            manifestLoadingMaxRetry: 2,
            manifestLoadingRetryDelay: 500,
            levelLoadingTimeOut: 9000,
            levelLoadingMaxRetry: 3,
            levelLoadingRetryDelay: 600,
            fragLoadingTimeOut: 12000,
            fragLoadingMaxRetry: 3,
            fragLoadingRetryDelay: 600,
          });
          hlsRef.current = hls;
          hls.loadSource(url);
          hls.attachMedia(videoRef.current);

          hls.on(Hls.Events.MANIFEST_PARSED, (_event, data) => {
            if (cancelled || !videoRef.current) return;
            learnedEngineRef.current.set(channel.id, 'hls');
            setIsBuffering(false);
            if (data.levels && data.levels.length > 1) {
              setLevels(
                data.levels.map((lvl, idx) => ({
                  index: idx,
                  label: lvl.height ? `${lvl.height}p` : `جودة ${idx + 1}`,
                }))
              );
            }
            safePlay();
          });

          hls.on(Hls.Events.ERROR, (_event, data) => {
            if (cancelled) return;
            if (!data.fatal) return;

            const httpCode = Number(data.response?.code || 0);
            if (httpCode === 499) return;
            if (triggerTicketFallbackOnAuthStatus(httpCode)) {
              return;
            }

            // Server sniffed raw MPEG-TS or MP4 bytes (HTTP 415) -> switch engine instantaneously!
            if (httpCode === 415 && engineMode === 'auto') {
              if (!attemptedEngines.has('mpegts') && mpegts.isSupported()) {
                learnedEngineRef.current.set(channel.id, 'mpegts');
                startMpegTs();
              } else if (!attemptedEngines.has('native')) {
                learnedEngineRef.current.set(channel.id, 'native');
                startNative('native');
              }
              return;
            }

            if (data.type === Hls.ErrorTypes.MEDIA_ERROR) {
              const now = Date.now();
              if (now - lastMediaRecoveryAt > 3000) {
                lastMediaRecoveryAt = now;
                hls.recoverMediaError();
                return;
              }
              if (!swappedCodec) {
                swappedCodec = true;
                lastMediaRecoveryAt = now;
                hls.swapAudioCodec();
                hls.recoverMediaError();
                return;
              }
            }

            if (
              data.type === Hls.ErrorTypes.NETWORK_ERROR &&
              networkRecoveryCount < 1 &&
              httpCode !== 415 &&
              httpCode !== 403 &&
              httpCode !== 401
            ) {
              networkRecoveryCount += 1;
              setIsBuffering(true);
              window.setTimeout(() => {
                if (!cancelled && hlsRef.current === hls) {
                  hls.startLoad();
                }
              }, 500);
              return;
            }

            // If channel was already playing and upstream token rotated/dropped, reconnect silently!
            if (hasPlayedRef.current && channel.contentType === 'live') {
              scheduleSilentReconnect(700);
              return;
            }

            if (engineMode === 'auto') {
              if (!attemptedEngines.has('mpegts') && mpegts.isSupported()) {
                startMpegTs();
                return;
              }
              if (!attemptedEngines.has('native')) {
                startNative(canSafariNativeHls ? 'hls' : 'native');
                return;
              }
            }

            if (autoRecoverCountRef.current < 3) {
              scheduleSilentReconnect(650);
              return;
            }

            setIsBuffering(false);
            setErrorMsg('تعذر فتح البث حالياً. قد تكون القناة متوقفة مؤقتاً من المصدر.');
          });
        } else if (canSafariNativeHls) {
          startNative('hls');
        } else {
          startMpegTs();
        }
      };

      const rememberedEngine = learnedEngineRef.current.get(channel.id);

      const initialEngine: 'hls' | 'mpegts' | 'native' =
        engineMode !== 'auto'
          ? engineMode
          : rememberedEngine
          ? rememberedEngine
          : formatHint === 'mp4'
          ? 'native'
          : formatHint === 'mpegts'
          ? mpegts.isSupported()
            ? 'mpegts'
            : canSafariNativeHls
            ? 'native'
            : 'hls'
          : Hls.isSupported()
          ? 'hls'
          : canSafariNativeHls
          ? 'native'
          : 'mpegts';

      if (initialEngine === 'mpegts') {
        startMpegTs();
      } else if (initialEngine === 'native') {
        startNative(
          formatHint === 'mp4' || channel.contentType !== 'live' ? 'native' : 'hls'
        );
      } else {
        startHls();
      }
    };

    launchWithTicket();

    return () => {
      cancelled = true;
      cleanupEngines();
    };
  }, [
    isOpen,
    channel?.id,
    engineMode,
    reloadNonce,
    cleanupEngines,
    stopEnginesOnly,
  ]);

  // Live Freeze Watchdog: detects frozen decoder / stalled live stream and self-heals automatically
  useEffect(() => {
    if (!isOpen || !channel || channel.contentType !== 'live' || errorMsg) return;

    const timer = window.setInterval(() => {
      const v = videoRef.current;
      if (!v || userPausedRef.current || !hasPlayedRef.current) return;
      if (document.visibilityState === 'hidden') {
        lastProgressRef.current = { time: v.currentTime, ts: Date.now() };
        return;
      }

      const now = Date.now();
      const cur = v.currentTime;
      if (Math.abs(cur - lastProgressRef.current.time) > 0.05) {
        lastProgressRef.current = { time: cur, ts: now };
        return;
      }

      const stalledMs = now - lastProgressRef.current.ts;

      // At 8s of stall, skip over any small PTS hole if buffered data exists ahead
      if (stalledMs >= 8000 && stalledMs < 15000) {
        for (let i = 0; i < v.buffered.length; i++) {
          const start = v.buffered.start(i);
          const end = v.buffered.end(i);
          if (start > cur + 0.15 && end > start + 0.5) {
            v.currentTime = start + 0.1;
            v.play().catch(() => {});
            lastProgressRef.current = { time: v.currentTime, ts: now };
            return;
          }
        }
        if (hlsRef.current) {
          hlsRef.current.startLoad();
        }
        v.play().catch(() => {});
      }

      // At 16s of complete freeze on a live channel, perform silent reconnect
      if (stalledMs >= 16000 && autoRecoverCountRef.current < 5) {
        autoRecoverCountRef.current += 1;
        forceEdgeRefreshRef.current = true;
        lastProgressRef.current = { time: cur, ts: now };
        setIsBuffering(true);
        setReloadNonce((n) => n + 1);
      }
    }, 3000);

    return () => window.clearInterval(timer);
  }, [isOpen, channel, errorMsg]);

  const stepChannel = useCallback(
    (delta: number) => {
      if (!channel || allChannels.length === 0) return;
      const idx = allChannels.findIndex((c) => c.id === channel.id);
      const nextIdx = (idx + delta + allChannels.length) % allChannels.length;
      onSelectChannel(allChannels[nextIdx]);
      scheduleAutoHide();
    },
    [channel, allChannels, onSelectChannel, scheduleAutoHide]
  );

  useEffect(() => {
    if (!isOpen) return;
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement) return;
      scheduleAutoHide();
      if (e.key === 'Escape' && !document.fullscreenElement) {
        if (showZapper) setShowZapper(false);
        else if (showSettingsMenu) setShowSettingsMenu(false);
        else onClose();
      } else if (e.key === 'ArrowUp' || e.key === 'ArrowRight') {
        e.preventDefault();
        stepChannel(-1);
      } else if (e.key === 'ArrowDown' || e.key === 'ArrowLeft') {
        e.preventDefault();
        stepChannel(1);
      } else if (e.key === ' ') {
        e.preventDefault();
        const v = videoRef.current;
        if (v) {
          if (v.paused) {
            userPausedRef.current = false;
            lastProgressRef.current = { time: v.currentTime, ts: Date.now() };
            v.play().catch(() => {});
          } else {
            userPausedRef.current = true;
            v.pause();
          }
        }
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [isOpen, showZapper, showSettingsMenu, onClose, stepChannel, scheduleAutoHide]);

  useEffect(() => {
    const onPageHide = () => {
      if (activeTicketRef.current) {
        api.releaseStream(activeTicketRef.current, {
          playId: activePlayIdRef.current,
          reason: 'pagehide',
        });
      }
    };
    window.addEventListener('pagehide', onPageHide);
    return () => window.removeEventListener('pagehide', onPageHide);
  }, []);

  useEffect(() => {
    const v = videoRef.current as (HTMLVideoElement & { webkitDisplayingFullscreen?: boolean }) | null;
    const onFsChange = () => {
      const docFs = Boolean(
        document.fullscreenElement ||
          (document as Document & { webkitFullscreenElement?: Element }).webkitFullscreenElement ||
          v?.webkitDisplayingFullscreen
      );
      setIsNativeFullscreen(docFs);
      if (!docFs) {
        try {
          (screen.orientation as ScreenOrientation & { unlock?: () => void })?.unlock?.();
        } catch {
          // ignore if unsupported
        }
      }
    };
    const onWebkitEnd = () => {
      setIsNativeFullscreen(false);
    };
    const onWebkitBegin = () => {
      setIsNativeFullscreen(true);
    };

    document.addEventListener('fullscreenchange', onFsChange);
    document.addEventListener('webkitfullscreenchange', onFsChange as EventListener);
    v?.addEventListener('webkitbeginfullscreen', onWebkitBegin as EventListener);
    v?.addEventListener('webkitendfullscreen', onWebkitEnd as EventListener);
    return () => {
      document.removeEventListener('fullscreenchange', onFsChange);
      document.removeEventListener('webkitfullscreenchange', onFsChange as EventListener);
      v?.removeEventListener('webkitbeginfullscreen', onWebkitBegin as EventListener);
      v?.removeEventListener('webkitendfullscreen', onWebkitEnd as EventListener);
    };
  }, [isOpen, channel?.id]);

  if (!isOpen || !channel) return null;

  const exitAnyFullscreen = async () => {
    const docAny = document as Document & {
      webkitFullscreenElement?: Element;
      webkitExitFullscreen?: () => Promise<void> | void;
    };
    const vidAny = videoRef.current as
      | (HTMLVideoElement & {
          webkitDisplayingFullscreen?: boolean;
          webkitExitFullscreen?: () => void;
        })
      | null;

    if (document.fullscreenElement) {
      await document.exitFullscreen().catch(() => {});
    } else if (docAny.webkitFullscreenElement && docAny.webkitExitFullscreen) {
      await Promise.resolve(docAny.webkitExitFullscreen()).catch(() => {});
    } else if (vidAny?.webkitDisplayingFullscreen && vidAny.webkitExitFullscreen) {
      try {
        vidAny.webkitExitFullscreen();
      } catch {
        // ignore
      }
    }
    try {
      (screen.orientation as ScreenOrientation & { unlock?: () => void })?.unlock?.();
    } catch {
      // ignore
    }
  };

  const togglePlay = (e?: React.MouseEvent) => {
    e?.stopPropagation();
    const v = videoRef.current;
    if (!v) return;
    if (v.paused) {
      userPausedRef.current = false;
      lastProgressRef.current = { time: v.currentTime, ts: Date.now() };
      v.play().catch(() => {});
    } else {
      userPausedRef.current = true;
      v.pause();
    }
    scheduleAutoHide();
  };

  const toggleMute = (e?: React.MouseEvent) => {
    e?.stopPropagation();
    const v = videoRef.current;
    if (!v) return;
    const next = !isMuted;
    v.muted = next;
    setIsMuted(next);
    scheduleAutoHide();
  };

  const cycleAspectMode = (e?: React.MouseEvent) => {
    e?.stopPropagation();
    setAspectMode((prev) =>
      prev === 'contain' ? 'cover' : prev === 'cover' ? 'fill' : 'contain'
    );
    scheduleAutoHide();
  };

  const handleFullscreen = async (e?: React.MouseEvent) => {
    e?.stopPropagation();
    const container = playerContainerRef.current as
      | (HTMLDivElement & { webkitRequestFullscreen?: () => Promise<void> | void })
      | null;
    const vidAny = videoRef.current as
      | (HTMLVideoElement & {
          webkitEnterFullscreen?: () => void;
          webkitDisplayingFullscreen?: boolean;
        })
      | null;
    const docAny = document as Document & { webkitFullscreenElement?: Element };

    if (
      document.fullscreenElement ||
      docAny.webkitFullscreenElement ||
      vidAny?.webkitDisplayingFullscreen
    ) {
      await exitAnyFullscreen();
      scheduleAutoHide();
      return;
    }

    let enteredStandardFs = false;
    if (container?.requestFullscreen) {
      try {
        await container.requestFullscreen();
        enteredStandardFs = true;
      } catch {
        enteredStandardFs = false;
      }
    } else if (container?.webkitRequestFullscreen) {
      try {
        await Promise.resolve(container.webkitRequestFullscreen());
        enteredStandardFs = true;
      } catch {
        enteredStandardFs = false;
      }
    }

    if (enteredStandardFs) {
      try {
        await (
          screen.orientation as ScreenOrientation & {
            lock?: (orientation: string) => Promise<void>;
          }
        )?.lock?.('landscape');
      } catch {
        // Orientation lock is optional and ignored if unsupported on browser
      }
    } else if (vidAny?.webkitEnterFullscreen) {
      // iOS Safari native <video> fullscreen fallback
      try {
        vidAny.webkitEnterFullscreen();
      } catch {
        // ignore
      }
    }
    scheduleAutoHide();
  };

  const handleSurfaceTap = () => {
    if (showSettingsMenu) {
      setShowSettingsMenu(false);
      return;
    }
    if (controlsVisible) {
      if (hideTimerRef.current) window.clearTimeout(hideTimerRef.current);
      setControlsVisible(false);
    } else {
      scheduleAutoHide();
    }
  };

  const aspectClass =
    aspectMode === 'cover'
      ? 'object-cover'
      : aspectMode === 'fill'
      ? 'object-fill'
      : 'object-contain';

  const zapperChannels = allChannels.filter((c) => {
    if (zapperGroup !== 'ALL' && c.group !== zapperGroup) return false;
    if (zapperSearch.trim()) {
      const q = zapperSearch.toLowerCase();
      return c.name.toLowerCase().includes(q) || c.group.toLowerCase().includes(q);
    }
    return true;
  });

  const isFav = favorites.includes(channel.id);
  const showUi = controlsVisible || !isPlaying || Boolean(errorMsg) || showSettingsMenu;

  return (
    <div
      ref={playerContainerRef}
      onContextMenu={(e) => e.preventDefault()}
      onMouseMove={() => {
        if (!showZapper) scheduleAutoHide();
      }}
      className="fixed inset-0 z-50 bg-black flex flex-col select-none overflow-hidden"
      dir="rtl"
    >
      {/* Pure Full-Bleed Protected Video Canvas */}
      <div
        onClick={handleSurfaceTap}
        onContextMenu={(e) => e.preventDefault()}
        className="relative flex-1 w-full h-full flex items-center justify-center bg-black"
      >
        <video
          ref={videoRef}
          autoPlay
          preload="auto"
          playsInline
          muted={isMuted}
          draggable={false}
          disablePictureInPicture
          controlsList="nodownload noplaybackrate noremoteplayback"
          onContextMenu={(e) => e.preventDefault()}
          onLoadedData={() => {
            setIsBuffering(false);
            if (!userPausedRef.current && videoRef.current?.paused) {
              videoRef.current.play().catch(() => {});
            }
          }}
          onPlaying={() => {
            setIsPlaying(true);
            setIsBuffering(false);
            setErrorMsg(null);
            hasPlayedRef.current = true;
            if (startupTimerRef.current) {
              window.clearTimeout(startupTimerRef.current);
              startupTimerRef.current = null;
            }
            lastProgressRef.current = {
              time: videoRef.current?.currentTime || 0,
              ts: Date.now(),
            };
            if (healthyTimerRef.current) window.clearTimeout(healthyTimerRef.current);
            healthyTimerRef.current = window.setTimeout(() => {
              autoRecoverCountRef.current = 0;
            }, 18000);
          }}
          onTimeUpdate={() => {
            if (videoRef.current) {
              lastProgressRef.current = {
                time: videoRef.current.currentTime,
                ts: Date.now(),
              };
            }
          }}
          onPause={() => {
            setIsPlaying(false);
            if (healthyTimerRef.current) {
              window.clearTimeout(healthyTimerRef.current);
              healthyTimerRef.current = null;
            }
          }}
          onWaiting={() => setIsBuffering(true)}
          className={`w-full h-full ${aspectClass}`}
        />

        {/* Subtle Spinner Only When Buffering */}
        {isBuffering && !errorMsg && (
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
            <div className="w-10 h-10 border-3 border-blue-500/90 border-t-transparent rounded-full animate-spin" />
          </div>
        )}

        {/* Error Recovery Card */}
        {errorMsg && (
          <div
            onClick={(e) => e.stopPropagation()}
            className="absolute inset-0 flex flex-col items-center justify-center bg-black/85 p-6 text-center gap-4 z-30"
          >
            <Tv className="w-10 h-10 text-red-400" />
            <p className="text-sm text-slate-200 max-w-sm leading-relaxed">{errorMsg}</p>
            <div className="flex flex-wrap items-center justify-center gap-2.5">
              <button
                type="button"
                onClick={() => {
                  autoRecoverCountRef.current = 0;
                  forceEdgeRefreshRef.current = true;
                  setEngineMode('auto');
                  setReloadNonce((n) => n + 1);
                }}
                className="min-h-[44px] px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer"
              >
                <RefreshCw className="w-4 h-4" />
                <span>إعادة المحاولة</span>
              </button>
              <button
                type="button"
                onClick={() => {
                  autoRecoverCountRef.current = 0;
                  forceEdgeRefreshRef.current = true;
                  setEngineMode((m) => (m === 'mpegts' ? 'hls' : 'mpegts'));
                }}
                className="min-h-[44px] px-4 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-white text-xs font-semibold cursor-pointer"
              >
                تبديل البروتوكول ({engineMode === 'mpegts' ? 'HLS' : 'MPEG-TS'})
              </button>
              <button
                type="button"
                onClick={onClose}
                className="min-h-[44px] px-4 py-2 rounded-xl bg-white/10 text-slate-300 text-xs font-semibold cursor-pointer"
              >
                رجوع للقنوات
              </button>
            </div>
          </div>
        )}

        {/* =================================================================
            AUTO-HIDING MINIMALIST OVERLAY (Fades out smoothly after 2.8s)
           ================================================================= */}
        <div
          className={`absolute inset-0 flex flex-col justify-between transition-opacity duration-200 ${
            showUi ? 'opacity-100' : 'opacity-0 pointer-events-none'
          }`}
        >
          {/* Slim Top Header with Safe-Area Padding */}
          <div
            onClick={(e) => e.stopPropagation()}
            className="flex items-center justify-between gap-2.5 player-px-safe sm:px-6 player-top-safe sm:pt-4 pb-8 bg-gradient-to-b from-black/85 via-black/40 to-transparent"
          >
            <div className="flex items-center gap-2.5 min-w-0">
              <button
                type="button"
                onClick={async () => {
                  await exitAnyFullscreen();
                  onClose();
                }}
                className="min-h-[44px] min-w-[44px] px-3 sm:px-3.5 rounded-xl bg-black/60 hover:bg-white/15 backdrop-blur-md border border-white/15 text-white text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer shrink-0 active:scale-95 transition-transform"
              >
                <ArrowRight className="w-4 h-4" />
                <span>رجوع</span>
              </button>

              <div className="min-w-0">
                <h2 className="text-xs sm:text-base font-bold text-white truncate">
                  {channel.name}
                </h2>
                <div className="flex items-center gap-2 text-[11px] text-slate-300 truncate">
                  <span className="truncate">{channel.group}</span>
                  <span className="hidden sm:inline-flex items-center gap-1 text-emerald-400 text-[10px]">
                    <ShieldCheck className="w-3 h-3" />
                    <span>بث مشفر</span>
                  </span>
                </div>
              </div>
            </div>

            <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
              <button
                type="button"
                onClick={() => {
                  setShowZapper(true);
                  setShowSettingsMenu(false);
                }}
                className="min-h-[44px] min-w-[44px] px-3 rounded-xl bg-black/55 hover:bg-white/15 backdrop-blur-md border border-white/10 text-white text-xs font-semibold flex items-center justify-center gap-1.5 cursor-pointer active:scale-95 transition-transform"
                title="القنوات"
              >
                <ListVideo className="w-4 h-4" />
                <span className="hidden sm:inline">القنوات</span>
              </button>

              <button
                type="button"
                onClick={() => onToggleFavorite(channel.id)}
                className={`min-h-[44px] min-w-[44px] rounded-xl backdrop-blur-md border flex items-center justify-center cursor-pointer active:scale-95 transition-transform ${
                  isFav
                    ? 'bg-amber-500/25 border-amber-400/50 text-amber-300'
                    : 'bg-black/55 hover:bg-white/15 border-white/10 text-white'
                }`}
                title="المفضلة"
              >
                <Star className={`w-4 h-4 ${isFav ? 'fill-amber-300' : ''}`} />
              </button>

              {isAdminUnlocked && onEditChannel && (
                <button
                  type="button"
                  onClick={async () => {
                    await exitAnyFullscreen();
                    onEditChannel(channel);
                  }}
                  className="min-h-[44px] min-w-[44px] rounded-xl bg-black/55 hover:bg-white/15 backdrop-blur-md border border-white/10 text-white flex items-center justify-center cursor-pointer active:scale-95 transition-transform"
                  title="تعديل القناة"
                >
                  <Edit3 className="w-4 h-4" />
                </button>
              )}
            </div>
          </div>

          {/* Center Tactile Controls: Prev Channel | Play/Pause | Next Channel */}
          <div
            onClick={(e) => e.stopPropagation()}
            className="flex items-center justify-center gap-6 sm:gap-10 pointer-events-auto self-center"
          >
            <button
              type="button"
              onClick={() => stepChannel(-1)}
              className="w-11 h-11 sm:w-12 sm:h-12 rounded-full bg-black/50 hover:bg-black/75 backdrop-blur-md border border-white/15 text-white flex items-center justify-center active:scale-95 transition-transform cursor-pointer"
              title="القناة السابقة"
            >
              <ChevronRight className="w-6 h-6" />
            </button>

            <button
              type="button"
              onClick={togglePlay}
              className="w-14 h-14 sm:w-16 sm:h-16 rounded-full bg-blue-600/90 hover:bg-blue-500 text-white flex items-center justify-center shadow-[0_0_25px_rgba(37,99,235,0.5)] active:scale-95 transition-transform cursor-pointer"
              title={isPlaying ? 'إيقاف مؤقت' : 'تشغيل'}
            >
              {isPlaying ? <Pause className="w-7 h-7" /> : <Play className="w-7 h-7 mr-[-2px]" />}
            </button>

            <button
              type="button"
              onClick={() => stepChannel(1)}
              className="w-11 h-11 sm:w-12 sm:h-12 rounded-full bg-black/50 hover:bg-black/75 backdrop-blur-md border border-white/15 text-white flex items-center justify-center active:scale-95 transition-transform cursor-pointer"
              title="القناة التالية"
            >
              <ChevronLeft className="w-6 h-6" />
            </button>
          </div>

          {/* Slim Single-Row Bottom Bar with Safe-Area Padding */}
          <div
            onClick={(e) => e.stopPropagation()}
            className="relative flex items-center justify-between gap-2.5 player-px-safe sm:px-6 player-bottom-safe sm:pb-5 pt-8 bg-gradient-to-t from-black/90 via-black/45 to-transparent"
          >
            {/* Right side (RTL): Mute, Mobile Aspect Quick-Toggle & Desktop Volume Slider */}
            <div className="flex items-center gap-1.5 sm:gap-2">
              <button
                type="button"
                onClick={toggleMute}
                className="min-h-[44px] min-w-[44px] rounded-xl bg-black/55 hover:bg-white/15 backdrop-blur-md border border-white/10 text-white flex items-center justify-center cursor-pointer active:scale-95 transition-transform"
                title={isMuted ? 'تشغيل الصوت' : 'كتم الصوت'}
              >
                {isMuted ? (
                  <VolumeX className="w-5 h-5 text-red-400" />
                ) : (
                  <Volume2 className="w-5 h-5" />
                )}
              </button>

              {/* Mobile One-Tap Screen Fit / Crop Button for 20:9 Smartphones */}
              <button
                type="button"
                onClick={cycleAspectMode}
                className="sm:hidden min-h-[44px] px-3 rounded-xl bg-black/55 hover:bg-white/15 backdrop-blur-md border border-white/10 text-white text-[11px] font-bold flex items-center gap-1.5 cursor-pointer active:scale-95 transition-transform"
                title="تغيير أبعاد الشاشة"
              >
                <Scan className="w-4 h-4 text-blue-400" />
                <span>
                  {aspectMode === 'contain'
                    ? 'أصلي'
                    : aspectMode === 'cover'
                      ? 'تكبير'
                      : 'تمديد'}
                </span>
              </button>

              <input
                type="range"
                min={0}
                max={1}
                step={0.05}
                value={isMuted ? 0 : volume}
                onChange={(e) => {
                  const val = Number(e.target.value);
                  setVolume(val);
                  setIsMuted(val === 0);
                  if (videoRef.current) {
                    videoRef.current.volume = val;
                    videoRef.current.muted = val === 0;
                  }
                  scheduleAutoHide();
                }}
                className="hidden sm:block w-24 accent-blue-500 cursor-pointer"
              />
            </div>

            {/* Left side (RTL): Reload, Compact Gear Popover, Fullscreen */}
            <div className="flex items-center gap-1.5 sm:gap-2">
              <button
                type="button"
                onClick={() => {
                  autoRecoverCountRef.current = 0;
                  forceEdgeRefreshRef.current = true;
                  setReloadNonce((n) => n + 1);
                  scheduleAutoHide();
                }}
                className="min-h-[44px] min-w-[44px] rounded-xl bg-black/55 hover:bg-white/15 backdrop-blur-md border border-white/10 text-white flex items-center justify-center cursor-pointer active:scale-95 transition-transform"
                title="تحديث البث"
              >
                <RefreshCw className="w-4 h-4" />
              </button>

              {/* Settings Popover Trigger */}
              <div className="relative">
                <button
                  type="button"
                  onClick={() => setShowSettingsMenu((s) => !s)}
                  className={`min-h-[44px] min-w-[44px] rounded-xl backdrop-blur-md border flex items-center justify-center cursor-pointer active:scale-95 transition-transform ${
                    showSettingsMenu
                      ? 'bg-blue-600 border-blue-500 text-white'
                      : 'bg-black/55 hover:bg-white/15 border-white/10 text-white'
                  }`}
                  title="خيارات المشغل والجودة"
                >
                  <Settings2 className="w-4 h-4" />
                </button>

                {showSettingsMenu && (
                  <div className="absolute bottom-14 left-0 w-64 max-w-[85vw] max-h-[68dvh] overflow-y-auto overscroll-contain rounded-2xl bg-[#0B1222]/95 backdrop-blur-xl border border-[#1E325C] p-3.5 shadow-2xl space-y-3 text-xs z-40">
                    <div>
                      <span className="block text-[11px] text-slate-400 mb-1">أبعاد الصورة</span>
                      <div className="grid grid-cols-3 gap-1 bg-[#060B16] p-1 rounded-xl">
                        {(
                          [
                            { id: 'contain', label: 'أصلي' },
                            { id: 'cover', label: 'تكبير' },
                            { id: 'fill', label: 'تمديد' },
                          ] as const
                        ).map((opt) => (
                          <button
                            key={opt.id}
                            type="button"
                            onClick={() => setAspectMode(opt.id)}
                            className={`min-h-[36px] py-1.5 rounded-lg font-semibold cursor-pointer ${
                              aspectMode === opt.id
                                ? 'bg-blue-600 text-white'
                                : 'text-slate-300 hover:text-white'
                            }`}
                          >
                            {opt.label}
                          </button>
                        ))}
                      </div>
                    </div>

                    {levels.length > 0 && (
                      <div>
                        <span className="block text-[11px] text-slate-400 mb-1">الجودة</span>
                        <select
                          value={currentLevel}
                          onChange={(e) => {
                            const idx = Number(e.target.value);
                            setCurrentLevel(idx);
                            if (hlsRef.current) hlsRef.current.currentLevel = idx;
                          }}
                          className="w-full min-h-[42px] px-3 py-2 rounded-xl bg-[#060B16] border border-[#1E2E4F] text-white"
                        >
                          <option value={-1}>تلقائية</option>
                          {levels.map((lvl) => (
                            <option key={lvl.index} value={lvl.index}>
                              {lvl.label}
                            </option>
                          ))}
                        </select>
                      </div>
                    )}

                    <div>
                      <span className="block text-[11px] text-slate-400 mb-1">وضع فك التشفير</span>
                      <select
                        value={engineMode}
                        onChange={(e) => setEngineMode(e.target.value as EngineMode)}
                        className="w-full min-h-[42px] px-3 py-2 rounded-xl bg-[#060B16] border border-[#1E2E4F] text-white"
                      >
                        <option value="auto">تلقائي ذكي</option>
                        <option value="hls">HLS (m3u8)</option>
                        <option value="mpegts">MPEG-TS (ts)</option>
                        <option value="native">مباشر MP4</option>
                      </select>
                    </div>
                  </div>
                )}
              </div>

              <button
                type="button"
                onClick={handleFullscreen}
                className="min-h-[44px] min-w-[44px] px-3 rounded-xl bg-black/55 hover:bg-white/15 backdrop-blur-md border border-white/10 text-white flex items-center justify-center gap-1.5 cursor-pointer active:scale-95 transition-transform"
                title="ملء الشاشة"
              >
                {isNativeFullscreen ? (
                  <Minimize2 className="w-4 h-4" />
                ) : (
                  <Maximize2 className="w-4 h-4" />
                )}
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* =====================================================================
          RESPONSIVE CHANNEL SWITCHER (Bottom Sheet on Portrait Phones, Side Drawer on Landscape/Desktop)
         ===================================================================== */}
      {showZapper && (
        <div
          onClick={() => setShowZapper(false)}
          className="fixed inset-0 z-40 bg-black/60 backdrop-blur-xs flex items-end sm:items-stretch sm:justify-end"
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="w-full h-[72dvh] sm:h-full sm:w-88 lg:w-96 bg-[#0B1222] rounded-t-3xl sm:rounded-none border-t sm:border-t-0 sm:border-r border-[#1E325C] flex flex-col overflow-hidden shadow-2xl pb-safe"
          >
            {/* Mobile Drag Handle */}
            <div className="sm:hidden w-10 h-1.5 bg-slate-600 rounded-full mx-auto mt-2.5 mb-1 shrink-0" />

            <div className="shrink-0 px-4 py-2.5 sm:py-3 border-b border-[#1B2947] flex items-center justify-between player-top-safe">
              <span className="text-sm font-bold text-white">تبديل القناة السريع</span>
              <button
                type="button"
                onClick={() => setShowZapper(false)}
                className="min-h-[44px] min-w-[44px] rounded-xl text-slate-400 hover:text-white flex items-center justify-center cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="shrink-0 p-3 border-b border-[#1B2947] grid grid-cols-1 gap-2">
              <input
                type="text"
                value={zapperSearch}
                onChange={(e) => setZapperSearch(e.target.value)}
                placeholder="ابحث عن قناة..."
                className="w-full min-h-[42px] px-3.5 py-2 rounded-xl bg-[#060B16] border border-[#1B2947] text-xs text-white placeholder-slate-400 focus:outline-none focus:border-blue-500"
              />
              <select
                value={zapperGroup}
                onChange={(e) => setZapperGroup(e.target.value)}
                className="w-full min-h-[42px] px-3.5 py-2 rounded-xl bg-[#060B16] border border-[#1B2947] text-xs text-slate-200 focus:outline-none focus:border-blue-500"
              >
                <option value="ALL">جميع الأقسام ({allChannels.length})</option>
                {categories.map((cat) => (
                  <option key={cat.name} value={cat.name}>
                    {cat.name} ({cat.count})
                  </option>
                ))}
              </select>
            </div>

            <div className="flex-1 min-h-0 overflow-y-auto overscroll-contain divide-y divide-white/5 sheet-pb-safe">
              {zapperChannels.slice(0, 300).map((item, idx) => {
                const active = item.id === channel.id;
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => {
                      onSelectChannel(item);
                      setShowZapper(false);
                    }}
                    className={`w-full min-h-[58px] px-4 py-2.5 flex items-center gap-3 text-right transition-colors cursor-pointer ${
                      active ? 'bg-blue-600/25 text-white' : 'hover:bg-white/5 text-slate-200'
                    }`}
                  >
                    <span className="font-mono tabular-nums text-[11px] text-slate-400 w-6">
                      {idx + 1}
                    </span>
                    <ChannelLogo name={item.name} logo={item.logo} group={item.group} size="sm" />
                    <div className="min-w-0 flex-1">
                      <div className="text-xs sm:text-sm font-bold truncate">{item.name}</div>
                      <div className="text-[11px] text-slate-400 truncate">{item.group}</div>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
