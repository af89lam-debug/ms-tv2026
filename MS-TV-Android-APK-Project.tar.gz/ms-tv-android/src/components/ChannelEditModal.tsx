import React, { useState } from 'react';
import { X, Save, Trash2, FolderInput, Star } from 'lucide-react';
import type { CategorySummary, Channel } from '../types';

interface ChannelEditModalProps {
  channel: Channel;
  categories: CategorySummary[];
  onClose: () => void;
  onSave: (
    channelId: string,
    updates: { name: string; group: string; logo: string; featured: boolean }
  ) => Promise<void>;
  onDelete: (channelId: string) => Promise<void>;
}

export const ChannelEditModal: React.FC<ChannelEditModalProps> = ({
  channel,
  categories,
  onClose,
  onSave,
  onDelete,
}) => {
  const [name, setName] = useState(channel.name);
  const [selectedGroup, setSelectedGroup] = useState(channel.group);
  const [newGroupName, setNewGroupName] = useState('');
  const [useNewGroup, setUseNewGroup] = useState(false);
  const [logo, setLogo] = useState(channel.logo || '');
  const [featured, setFeatured] = useState(channel.featured);
  const [saving, setSaving] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const finalName = name.trim();
    const finalGroup = useNewGroup ? newGroupName.trim() : selectedGroup.trim();
    if (!finalName) {
      setError('يرجى إدخال اسم القناة.');
      return;
    }
    if (!finalGroup) {
      setError('يرجى اختيار القسم أو كتابة اسم قسم جديد.');
      return;
    }

    setSaving(true);
    setError(null);
    try {
      await onSave(channel.id, {
        name: finalName,
        group: finalGroup,
        logo: logo.trim(),
        featured,
      });
      onClose();
    } catch (err: any) {
      setError(err?.message || 'حدث خطأ أثناء حفظ تعديلات القناة.');
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async () => {
    setSaving(true);
    try {
      await onDelete(channel.id);
      onClose();
    } catch (err: any) {
      setError(err?.message || 'تعذر حذف القناة.');
      setSaving(false);
    }
  };

  return (
    <div
      onClick={onClose}
      className="fixed inset-0 z-[80] bg-black/80 backdrop-blur-xs flex items-end sm:items-center justify-center p-0 sm:p-4"
      dir="rtl"
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="bg-[#0B1222] border-t sm:border border-[#1E325C] rounded-t-3xl sm:rounded-2xl w-full sm:max-w-lg max-h-[92dvh] flex flex-col overflow-hidden shadow-2xl"
      >
        <div className="w-10 h-1.5 bg-slate-600 rounded-full mx-auto mt-3 sm:hidden shrink-0" />

        <div className="shrink-0 flex items-center justify-between gap-2 px-5 py-3.5 sm:py-4 border-b border-[#1B2947]">
          <div className="min-w-0">
            <h3 className="text-sm sm:text-base font-bold text-white truncate">
              تعديل القناة أو نقلها لقسم آخر
            </h3>
            <p className="text-xs text-slate-400 mt-0.5 truncate">
              القسم الأصلي في الرابط: {channel.originalGroup}
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="min-h-[44px] min-w-[44px] rounded-xl text-slate-400 hover:text-white hover:bg-white/10 flex items-center justify-center cursor-pointer shrink-0"
            aria-label="إغلاق"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form
          onSubmit={handleSubmit}
          className="flex-1 min-h-0 overflow-y-auto overscroll-contain p-4 sm:p-5 sheet-pb-safe sm:pb-5 space-y-4"
        >
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">
              اسم القناة المعروض
            </label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full min-h-[44px] px-3.5 py-2.5 rounded-xl bg-[#060B16] border border-[#1E2E4F] text-sm text-white focus:outline-none focus:border-blue-500"
            />
          </div>

          <div className="space-y-2">
            <div className="flex items-center justify-between gap-2">
              <label className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                <FolderInput className="w-3.5 h-3.5 text-blue-400" />
                <span>نقل القناة إلى قسم</span>
              </label>
              <button
                type="button"
                onClick={() => setUseNewGroup((v) => !v)}
                className="min-h-[38px] px-2 text-xs font-semibold text-blue-400 hover:text-blue-300 cursor-pointer flex items-center"
              >
                {useNewGroup ? 'اختيار قسم موجود' : '+ إنشاء قسم جديد'}
              </button>
            </div>

            {!useNewGroup ? (
              <select
                value={selectedGroup}
                onChange={(e) => setSelectedGroup(e.target.value)}
                className="w-full min-h-[44px] px-3.5 py-2.5 rounded-xl bg-[#060B16] border border-[#1E2E4F] text-sm text-white focus:outline-none focus:border-blue-500"
              >
                {categories.map((cat) => (
                  <option key={cat.name} value={cat.name}>
                    {cat.name} ({cat.count})
                  </option>
                ))}
              </select>
            ) : (
              <input
                type="text"
                value={newGroupName}
                onChange={(e) => setNewGroupName(e.target.value)}
                placeholder="اكتب اسم القسم الجديد..."
                className="w-full min-h-[44px] px-3.5 py-2.5 rounded-xl bg-[#060B16] border border-blue-500/60 text-sm text-white focus:outline-none focus:border-blue-400"
              />
            )}
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">
              رابط شعار القناة (اختياري)
            </label>
            <input
              type="url"
              dir="ltr"
              value={logo}
              onChange={(e) => setLogo(e.target.value)}
              placeholder="https://..."
              className="w-full min-h-[44px] px-3.5 py-2.5 rounded-xl bg-[#060B16] border border-[#1E2E4F] text-xs text-slate-200 focus:outline-none focus:border-blue-500"
            />
          </div>

          <label className="min-h-[44px] flex items-center gap-2.5 cursor-pointer select-none py-1">
            <input
              type="checkbox"
              checked={featured}
              onChange={(e) => setFeatured(e.target.checked)}
              className="w-4 h-4 accent-blue-600 rounded shrink-0"
            />
            <Star className="w-4 h-4 text-amber-400 shrink-0" />
            <span className="text-xs font-semibold text-slate-200">
              إظهار ضمن القنوات المميزة في الصفحة الرئيسية
            </span>
          </label>

          {error && (
            <div className="p-3 rounded-xl bg-red-500/10 border border-red-500/30 text-xs text-red-300">
              {error}
            </div>
          )}

          <div className="flex flex-wrap items-center justify-between gap-2.5 pt-3 border-t border-[#1B2947]">
            {!confirmDelete ? (
              <button
                type="button"
                onClick={() => setConfirmDelete(true)}
                className="min-h-[44px] px-3.5 py-2 rounded-xl bg-red-500/10 hover:bg-red-500/20 text-red-400 text-xs font-semibold flex items-center gap-1.5 cursor-pointer"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>إخفاء / حذف</span>
              </button>
            ) : (
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={handleDelete}
                  disabled={saving}
                  className="min-h-[44px] px-3.5 py-2 rounded-xl bg-red-600 hover:bg-red-500 text-white text-xs font-bold cursor-pointer"
                >
                  تأكيد الحذف
                </button>
                <button
                  type="button"
                  onClick={() => setConfirmDelete(false)}
                  className="min-h-[44px] px-3 py-2 rounded-xl bg-white/10 text-slate-300 text-xs cursor-pointer"
                >
                  تراجع
                </button>
              </div>
            )}

            <div className="flex items-center gap-2 mr-auto sm:mr-0">
              <button
                type="button"
                onClick={onClose}
                className="min-h-[44px] px-4 py-2 rounded-xl bg-white/5 hover:bg-white/10 text-slate-300 text-xs font-semibold cursor-pointer"
              >
                إلغاء
              </button>
              <button
                type="submit"
                disabled={saving}
                className="min-h-[44px] px-5 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 disabled:opacity-60 text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer"
              >
                <Save className="w-3.5 h-3.5" />
                <span>{saving ? 'جاري الحفظ...' : 'حفظ التعديلات'}</span>
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};
