import React from 'react';
import type { CategorySummary, Channel, NavSection } from '../types';

interface CategoryCardsProps {
  channels: Channel[];
  categories: CategorySummary[];
  onSelectSection: (section: NavSection) => void;
}

const CardSilhouetteTexture: React.FC<{ variant: number }> = ({ variant }) => {
  return (
    <svg
      viewBox="0 0 200 210"
      preserveAspectRatio="xMidYMid slice"
      aria-hidden="true"
      className="absolute inset-0 w-full h-full opacity-[0.14] mix-blend-multiply pointer-events-none select-none"
    >
      {variant % 3 === 0 && (
        <g fill="#050814">
          <ellipse cx="34" cy="74" rx="22" ry="26" />
          <path d="M4 195C6 132 18 104 38 104C58 104 70 132 74 195Z" />
          <ellipse cx="168" cy="82" rx="28" ry="34" />
          <path d="M126 205C132 138 148 116 172 116C192 116 202 140 206 205Z" />
          <rect x="84" y="18" width="38" height="170" rx="8" fillOpacity="0.45" />
        </g>
      )}
      {variant % 3 === 1 && (
        <g fill="#050814">
          <ellipse cx="42" cy="68" rx="24" ry="28" />
          <path d="M8 202C12 130 26 100 46 100C66 100 82 132 88 202Z" />
          <ellipse cx="162" cy="72" rx="30" ry="32" />
          <path d="M118 206C124 132 142 108 166 108C188 108 200 134 204 206Z" />
          <circle cx="104" cy="148" r="44" fillOpacity="0.35" />
        </g>
      )}
      {variant % 3 === 2 && (
        <g fill="#050814">
          <ellipse cx="38" cy="76" rx="20" ry="24" />
          <path d="M6 204C10 136 22 106 40 106C58 106 72 136 78 204Z" />
          <ellipse cx="156" cy="84" rx="25" ry="29" />
          <path d="M116 206C122 140 138 116 158 116C178 116 194 140 198 206Z" />
          <polygon points="95,12 132,36 122,196 82,196" fillOpacity="0.38" />
        </g>
      )}
    </svg>
  );
};

export const CategoryCards: React.FC<CategoryCardsProps> = ({
  channels,
  onSelectSection,
}) => {
  const liveCount = channels.filter((c) => c.contentType === 'live').length || channels.length;

  const moviesCount = channels.filter(
    (c) =>
      c.contentType === 'movie' ||
      ['أفلام', 'افلام', 'movie', 'vod', 'cinema', 'سينما'].some((kw) =>
        c.group.toLowerCase().includes(kw)
      )
  ).length;

  const seriesCount = channels.filter(
    (c) =>
      c.contentType === 'series' ||
      ['مسلسل', 'series', 'دراما', 'drama'].some((kw) => c.group.toLowerCase().includes(kw))
  ).length;

  const sportsCount = channels.filter((c) =>
    ['رياض', 'sport', 'bein', 'ssc', 'كورة', 'كرة'].some((kw) =>
      `${c.group} ${c.name}`.toLowerCase().includes(kw)
    )
  ).length;

  const kidsCount = channels.filter((c) =>
    ['أطفال', 'اطفال', 'kid', 'cartoon', 'كرتون', 'spacetoon'].some((kw) =>
      `${c.group} ${c.name}`.toLowerCase().includes(kw)
    )
  ).length;

  const entCount = channels.filter((c) =>
    ['ترفيه', 'منوعات', 'entertainment', 'mbc', 'osn', 'trt', 'music', 'أغاني'].some((kw) =>
      `${c.group} ${c.name}`.toLowerCase().includes(kw)
    )
  ).length;

  const docCount = channels.filter((c) =>
    ['وثائق', 'doc', 'nat', 'geo', 'nasa', 'discovery', 'علوم'].some((kw) =>
      `${c.group} ${c.name}`.toLowerCase().includes(kw)
    )
  ).length;

  const tiles: Array<{
    id: NavSection;
    title: string;
    count: number;
    unit: string;
    bgClass: string;
    borderClass: string;
    svg: React.ReactNode;
  }> = [
    {
      id: 'live_tv',
      title: 'قنوات التلفاز',
      count: liveCount,
      unit: 'قناة',
      bgClass: 'bg-[linear-gradient(145deg,#4B46FF_0%,#2C26DC_52%,#110E75_100%)]',
      borderClass: 'border-[#7E7BFF]/45 hover:border-[#ABA9FF]/85',
      svg: (
        <svg
          viewBox="0 0 64 64"
          className="w-7 h-7 sm:w-8 sm:h-8 lg:w-9 lg:h-9 xl:w-10 xl:h-10 drop-shadow-[0_4px_10px_rgba(0,0,0,0.32)]"
          fill="none"
          aria-hidden="true"
        >
          <defs>
            <linearGradient id="iptvTvGrad" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#FFFFFF" />
              <stop offset="100%" stopColor="#D7E3FF" />
            </linearGradient>
            <mask id="iptvTvMask">
              <rect width="64" height="64" fill="black" />
              <path
                d="M24 12L32 20.5L40 12"
                stroke="white"
                strokeWidth="3.6"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
              <rect x="13" y="20" width="38" height="30" rx="6.5" fill="white" />
              <rect x="18" y="25" width="21.5" height="20" rx="3" fill="black" />
              <circle cx="45" cy="31" r="2.2" fill="black" />
              <circle cx="45" cy="39" r="2.2" fill="black" />
            </mask>
          </defs>
          <rect width="64" height="64" fill="url(#iptvTvGrad)" mask="url(#iptvTvMask)" />
        </svg>
      ),
    },
    {
      id: 'movies',
      title: 'الأفلام',
      count: moviesCount,
      unit: 'فيلم',
      bgClass: 'bg-[linear-gradient(145deg,#FF3D57_0%,#C81832_52%,#5B0817_100%)]',
      borderClass: 'border-[#FF8697]/45 hover:border-[#FFB4BF]/85',
      svg: (
        <svg
          viewBox="0 0 64 64"
          className="w-7 h-7 sm:w-8 sm:h-8 lg:w-9 lg:h-9 xl:w-10 xl:h-10 drop-shadow-[0_4px_10px_rgba(0,0,0,0.32)]"
          fill="none"
          aria-hidden="true"
        >
          <defs>
            <linearGradient id="iptvMovieGrad" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#FFFFFF" />
              <stop offset="100%" stopColor="#FFE1E6" />
            </linearGradient>
            <mask id="iptvMovieMask">
              <rect width="64" height="64" fill="black" />
              <circle cx="31" cy="32" r="20" fill="white" />
              <path
                d="M44 45.5L50.5 50.5"
                stroke="white"
                strokeWidth="4.8"
                strokeLinecap="round"
              />
              <circle cx="31" cy="20.5" r="4.2" fill="black" />
              <circle cx="31" cy="43.5" r="4.2" fill="black" />
              <circle cx="19.5" cy="32" r="4.2" fill="black" />
              <circle cx="42.5" cy="32" r="4.2" fill="black" />
            </mask>
          </defs>
          <rect width="64" height="64" fill="url(#iptvMovieGrad)" mask="url(#iptvMovieMask)" />
        </svg>
      ),
    },
    {
      id: 'series',
      title: 'المسلسلات',
      count: seriesCount,
      unit: 'مسلسل',
      bgClass: 'bg-[linear-gradient(145deg,#00BD7B_0%,#048255_52%,#033A25_100%)]',
      borderClass: 'border-[#52E8B2]/45 hover:border-[#94F5D1]/85',
      svg: (
        <svg
          viewBox="0 0 64 64"
          className="w-7 h-7 sm:w-8 sm:h-8 lg:w-9 lg:h-9 xl:w-10 xl:h-10 drop-shadow-[0_4px_10px_rgba(0,0,0,0.32)]"
          fill="none"
          aria-hidden="true"
        >
          <defs>
            <linearGradient id="iptvSeriesGrad" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#FFFFFF" />
              <stop offset="100%" stopColor="#D6FAEC" />
            </linearGradient>
            <mask id="iptvSeriesMask">
              <rect width="64" height="64" fill="black" />
              <g transform="rotate(-10 14 23)">
                <rect x="14" y="14" width="36" height="8.5" rx="3" fill="white" />
                <path d="M21 23L25 13M31 23L35 13M41 23L45 13" stroke="black" strokeWidth="3.2" />
              </g>
              <rect x="14" y="26.5" width="36" height="24.5" rx="4.5" fill="white" />
              <polygon points="28.5,33 39.5,38.8 28.5,44.5" fill="black" />
            </mask>
          </defs>
          <rect width="64" height="64" fill="url(#iptvSeriesGrad)" mask="url(#iptvSeriesMask)" />
        </svg>
      ),
    },
    {
      id: 'sports',
      title: 'الرياضة',
      count: sportsCount,
      unit: 'قناة',
      bgClass: 'bg-[linear-gradient(145deg,#FF8B1F_0%,#CC5B08_52%,#612702_100%)]',
      borderClass: 'border-[#FFB86C]/45 hover:border-[#FFD4A6]/85',
      svg: (
        <svg
          viewBox="0 0 64 64"
          className="w-7 h-7 sm:w-8 sm:h-8 lg:w-9 lg:h-9 xl:w-10 xl:h-10 drop-shadow-[0_4px_10px_rgba(0,0,0,0.32)]"
          fill="none"
          aria-hidden="true"
        >
          <defs>
            <linearGradient id="iptvSportGrad" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#FFFFFF" />
              <stop offset="100%" stopColor="#FFEAD5" />
            </linearGradient>
            <mask id="iptvSportMask">
              <rect width="64" height="64" fill="black" />
              <circle cx="32" cy="32" r="21" fill="white" />
              <polygon points="32,22.5 40.5,28.5 37.2,38.5 26.8,38.5 23.5,28.5" fill="black" />
              <polygon points="32,10.5 38,14 35.5,18 28.5,18 26,14" fill="black" />
              <polygon points="51.5,24 53,31.5 48,34 45.5,27.5 48.5,22" fill="black" />
              <polygon points="12.5,24 15.5,22 18.5,27.5 16,34 11,31.5" fill="black" />
              <polygon points="44.5,49 38,52.5 36.5,47.5 41.5,42.5 46.5,44.5" fill="black" />
              <polygon points="19.5,49 17.5,44.5 22.5,42.5 27.5,47.5 26,52.5" fill="black" />
              <path
                d="M32 18V22.5M40.5 28.5L45.5 27.5M37.2 38.5L41.5 42.5M26.8 38.5L22.5 42.5M23.5 28.5L18.5 27.5"
                stroke="black"
                strokeWidth="2.2"
                strokeLinecap="round"
              />
            </mask>
          </defs>
          <rect width="64" height="64" fill="url(#iptvSportGrad)" mask="url(#iptvSportMask)" />
        </svg>
      ),
    },
    {
      id: 'kids',
      title: 'الأطفال',
      count: kidsCount,
      unit: 'قناة',
      bgClass: 'bg-[linear-gradient(145deg,#8A38FF_0%,#5D18C9_52%,#2B0766_100%)]',
      borderClass: 'border-[#B985FF]/45 hover:border-[#D7B8FF]/85',
      svg: (
        <svg
          viewBox="0 0 64 64"
          className="w-7 h-7 sm:w-8 sm:h-8 lg:w-9 lg:h-9 xl:w-10 xl:h-10 drop-shadow-[0_4px_10px_rgba(0,0,0,0.32)]"
          fill="none"
          aria-hidden="true"
        >
          <defs>
            <linearGradient id="iptvKidsGrad" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#FFFFFF" />
              <stop offset="100%" stopColor="#E9D8FF" />
            </linearGradient>
            <mask id="iptvKidsMask">
              <rect width="64" height="64" fill="black" />
              <circle cx="13" cy="35" r="3.8" fill="white" />
              <circle cx="51" cy="35" r="3.8" fill="white" />
              <circle cx="32" cy="34.5" r="18.2" fill="white" />
              <path
                d="M29 16.5C29.5 12 34 11.5 35.5 15.5"
                stroke="white"
                strokeWidth="3.6"
                strokeLinecap="round"
              />
              <path
                d="M33.5 16.5C35.5 13 39 13.5 39.5 17"
                stroke="white"
                strokeWidth="3.2"
                strokeLinecap="round"
              />
              <circle cx="25.5" cy="31.5" r="2.7" fill="black" />
              <circle cx="38.5" cy="31.5" r="2.7" fill="black" />
              <path d="M24.5 38.5H39.5C39.5 44.8 24.5 44.8 24.5 38.5Z" fill="black" />
            </mask>
          </defs>
          <rect width="64" height="64" fill="url(#iptvKidsGrad)" mask="url(#iptvKidsMask)" />
        </svg>
      ),
    },
    {
      id: 'entertainment',
      title: 'الترفيه',
      count: entCount,
      unit: 'قناة',
      bgClass: 'bg-[linear-gradient(145deg,#0DB8EF_0%,#077CA8_52%,#043852_100%)]',
      borderClass: 'border-[#67D8FF]/45 hover:border-[#A6EAFF]/85',
      svg: (
        <svg
          viewBox="0 0 64 64"
          className="w-7 h-7 sm:w-8 sm:h-8 lg:w-9 lg:h-9 xl:w-10 xl:h-10 drop-shadow-[0_4px_10px_rgba(0,0,0,0.32)]"
          fill="none"
          aria-hidden="true"
        >
          <defs>
            <linearGradient id="iptvEntGrad" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#FFFFFF" />
              <stop offset="100%" stopColor="#D4F3FF" />
            </linearGradient>
          </defs>
          <path
            d="M25 18.5L48 13.5V22L29.5 26V44.5C29.5 48.4 25.9 51.5 21.5 51.5C17.1 51.5 13.5 48.4 13.5 44.5C13.5 40.6 17.1 37.5 21.5 37.5C23 37.5 24.4 37.9 25 38.5V18.5ZM48 20V39.5C48 43.4 44.4 46.5 40 46.5C35.6 46.5 32 43.4 32 39.5C32 35.6 35.6 32.5 40 32.5C41.5 32.5 42.8 32.9 43.5 33.5V18.5L48 20Z"
            fill="url(#iptvEntGrad)"
          />
        </svg>
      ),
    },
    {
      id: 'documentary',
      title: 'الوثائقية',
      count: docCount,
      unit: 'قناة',
      bgClass: 'bg-[linear-gradient(145deg,#2185F7_0%,#1158B8_52%,#07275C_100%)]',
      borderClass: 'border-[#6FB1FF]/45 hover:border-[#A8D0FF]/85',
      svg: (
        <svg
          viewBox="0 0 64 64"
          className="w-7 h-7 sm:w-8 sm:h-8 lg:w-9 lg:h-9 xl:w-10 xl:h-10 drop-shadow-[0_4px_10px_rgba(0,0,0,0.32)]"
          fill="none"
          aria-hidden="true"
        >
          <defs>
            <linearGradient id="iptvDocGrad" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#FFFFFF" />
              <stop offset="100%" stopColor="#D6E8FF" />
            </linearGradient>
            <mask id="iptvDocMask">
              <rect width="64" height="64" fill="black" />
              <path
                d="M17 15.5C17 13.3 18.8 11.5 21 11.5H36.5L47 22V48.5C47 50.7 45.2 52.5 43 52.5H21C18.8 52.5 17 50.7 17 48.5V15.5Z"
                fill="white"
              />
              <path
                d="M36.5 11.5V19.5C36.5 21 37.5 22 39 22H47"
                stroke="black"
                strokeWidth="2.6"
                strokeLinejoin="round"
              />
              <rect x="23" y="28" width="10.5" height="3.2" rx="1.6" fill="black" />
              <rect x="23" y="34.5" width="18" height="3.2" rx="1.6" fill="black" />
              <rect x="23" y="41" width="18" height="3.2" rx="1.6" fill="black" />
            </mask>
          </defs>
          <rect width="64" height="64" fill="url(#iptvDocGrad)" mask="url(#iptvDocMask)" />
        </svg>
      ),
    },
  ];

  return (
    <div
      className="grid grid-cols-4 md:grid-cols-7 gap-2 sm:gap-2.5 [direction:rtl] md:[direction:ltr]"
    >
      {tiles.map((tile, index) => {
        const isPrimaryLiveTile = index === 0;
        return (
          <button
            key={tile.id}
            type="button"
            onClick={() => onSelectSection(tile.id)}
            className={`${
              isPrimaryLiveTile ? 'col-span-2 md:col-span-1' : 'col-span-1'
            } w-full h-[86px] sm:h-[98px] md:h-[108px] lg:h-[118px] xl:h-[130px] group relative overflow-hidden rounded-2xl p-2 sm:p-2.5 lg:p-3 ${tile.bgClass} border ${tile.borderClass} shadow-[0_8px_18px_-6px_rgba(0,0,0,0.65),inset_0_1px_1px_rgba(255,255,255,0.32)] hover:-translate-y-0.5 hover:brightness-110 active:scale-[0.97] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white/80 transition-all duration-200 flex flex-col items-center justify-center text-center cursor-pointer select-none`}
          >
            {/* Subtle atmospheric silhouette depth matching reference IPTV cards */}
            <CardSilhouetteTexture variant={index} />

            {/* Top-left glossy light sheen */}
            <div
              aria-hidden="true"
              className="absolute inset-0 bg-[radial-gradient(circle_at_16%_14%,rgba(255,255,255,0.24)_0%,transparent_54%)] pointer-events-none"
            />

            {/* Subtle bottom contrast vignette */}
            <div
              aria-hidden="true"
              className="absolute inset-x-0 bottom-0 h-1/2 bg-gradient-to-t from-black/30 to-transparent pointer-events-none"
            />

            {/* Foreground Content */}
            <div className="relative z-10 flex flex-col items-center justify-center w-full">
              <div className="mb-1 sm:mb-1.5 group-hover:scale-105 transition-transform duration-200">
                {tile.svg}
              </div>

              <div
                className="text-[11px] sm:text-[13px] lg:text-sm xl:text-[15px] font-extrabold text-white leading-tight whitespace-nowrap truncate max-w-full drop-shadow-[0_2px_6px_rgba(0,0,0,0.35)]"
                dir="rtl"
              >
                {tile.title}
              </div>

              <div
                className="mt-0.5 text-[9.5px] sm:text-[10.5px] lg:text-[11px] font-medium text-white/85 flex items-center justify-center gap-0.5 sm:gap-1 whitespace-nowrap truncate max-w-full"
                dir="rtl"
              >
                <span dir="ltr" className="tabular-nums font-semibold">
                  {tile.count > 0 ? `+${tile.count}` : '0'}
                </span>
                <span>{tile.unit}</span>
              </div>
            </div>
          </button>
        );
      })}
    </div>
  );
};

