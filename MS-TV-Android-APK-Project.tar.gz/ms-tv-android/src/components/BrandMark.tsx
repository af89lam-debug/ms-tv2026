import React, { useState } from 'react';

interface BrandMarkProps {
  compact?: boolean;
  size?: 'sm' | 'md' | 'lg';
  className?: string;
}

const PRIMARY_LOGO_SRC = '/assets/ms-tv-logo.png';
const FALLBACK_LOGO_SRC = '/assets/aistudio/821115606_de309fb7.png';

export const BrandMark: React.FC<BrandMarkProps> = ({
  compact = false,
  size,
  className = '',
}) => {
  const [srcIndex, setSrcIndex] = useState<0 | 1 | 2>(0);

  const resolvedSize: 'sm' | 'md' | 'lg' = size ?? (compact ? 'sm' : 'md');

  const sizeClasses = {
    sm: 'h-9 w-auto max-w-[110px]',
    md: 'h-11 lg:h-12 w-auto max-w-[140px]',
    lg: 'h-20 sm:h-24 w-auto max-w-[220px]',
  }[resolvedSize];

  return (
    <div className={`inline-flex items-center justify-center select-none shrink-0 ${className}`} dir="ltr">
      {srcIndex < 2 ? (
        <img
          src={srcIndex === 0 ? PRIMARY_LOGO_SRC : FALLBACK_LOGO_SRC}
          alt="MS TV"
          draggable={false}
          onError={() => setSrcIndex((prev) => (prev === 0 ? 1 : 2))}
          className={`${sizeClasses} object-contain drop-shadow-[0_2px_10px_rgba(255,255,255,0.08)]`}
        />
      ) : (
        <svg
          viewBox="0 0 220 140"
          className={sizeClasses}
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          aria-label="MS TV"
        >
          <circle cx="72" cy="40" r="14" fill="#F59E0B" />
          <circle cx="98" cy="24" r="9" fill="#0EA5E9" />
          <circle cx="122" cy="17" r="6.5" fill="#C026D3" />
          <circle cx="144" cy="18" r="4.5" fill="#EF4444" />
          <text
            x="10"
            y="106"
            fill="#E53924"
            fontFamily="Outfit, sans-serif"
            fontWeight="800"
            fontStyle="italic"
            fontSize="60"
          >
            M
          </text>
          <text
            x="68"
            y="106"
            fill="#F07D22"
            fontFamily="Outfit, sans-serif"
            fontWeight="800"
            fontStyle="italic"
            fontSize="60"
          >
            S
          </text>
          <g transform="rotate(7 166 80)">
            <line x1="164" y1="42" x2="156" y2="20" stroke="#F58220" strokeWidth="4" strokeLinecap="round" />
            <circle cx="155" cy="18" r="4" fill="#F58220" />
            <line x1="170" y1="42" x2="186" y2="10" stroke="#F58220" strokeWidth="4" strokeLinecap="round" />
            <rect x="122" y="40" width="88" height="76" rx="18" fill="#F58220" />
            <text
              x="133"
              y="95"
              fill="#FFFFFF"
              fontFamily="Outfit, sans-serif"
              fontWeight="800"
              fontSize="44"
            >
              TV
            </text>
          </g>
        </svg>
      )}
    </div>
  );
};
