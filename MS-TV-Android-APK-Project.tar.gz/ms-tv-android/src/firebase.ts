import { initializeApp } from 'firebase/app';
import {
  GoogleAuthProvider,
  getAuth,
  onAuthStateChanged,
  signInWithPopup,
  signOut,
  type User,
} from 'firebase/auth';
import {
  deleteDoc,
  doc,
  getDoc,
  getDocFromServer,
  getFirestore,
  serverTimestamp,
  setDoc,
  updateDoc,
} from 'firebase/firestore';
import firebaseConfig from '../firebase-applet-config.json';

const app = initializeApp(firebaseConfig);
export const db = getFirestore(app, firebaseConfig.firestoreDatabaseId);
export const auth = getAuth(app);

const googleProvider = new GoogleAuthProvider();
googleProvider.setCustomParameters({ prompt: 'select_account' });

// Blueprint validation constants synchronized verbatim with firebase-blueprint.json & firestore.rules
const ID_PATTERN = /^[a-zA-Z0-9_\-]+$/;
const MAX_ID_LENGTH = 128;
const MAX_APP_NAME_LENGTH = 64;
const MIN_CIPHER_LENGTH = 16;
const MAX_CIPHER_LENGTH = 750000;

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  };
}

export function handleFirestoreError(
  error: unknown,
  operationType: OperationType,
  path: string | null
): never {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo:
        auth.currentUser?.providerData?.map((provider) => ({
          providerId: provider.providerId,
          email: provider.email,
        })) || [],
    },
    operationType,
    path,
  };
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

async function testConnection(): Promise<void> {
  try {
    await getDocFromServer(doc(db, 'test', 'connection'));
  } catch (error) {
    if (error instanceof Error && error.message.includes('the client is offline')) {
      console.error('Please check your Firebase configuration.');
    }
  }
}

testConnection();

function sanitizeFirestoreId(raw: string): string {
  const cleaned = raw.replace(/[^a-zA-Z0-9_\-]/g, '_').slice(0, MAX_ID_LENGTH);
  if (!cleaned || !ID_PATTERN.test(cleaned)) {
    throw new Error('معرف المستند غير صالح للحفظ السحابي.');
  }
  return cleaned;
}

export function subscribeToFirebaseAdmin(callback: (user: User | null) => void): () => void {
  return onAuthStateChanged(auth, callback);
}

export async function signInAdminForCloudVault(): Promise<User> {
  const credential = await signInWithPopup(auth, googleProvider);
  const user = credential.user;
  if (user && user.email && user.emailVerified) {
    await ensureAdminProfileRegistered(user);
  }
  return user;
}

export async function signOutAdminCloudVault(): Promise<void> {
  await signOut(auth);
}

async function ensureAdminProfileRegistered(user: User): Promise<void> {
  const uid = sanitizeFirestoreId(user.uid);
  const email = (user.email || '').trim().slice(0, 254);
  if (email.length < 5) return;

  const adminPath = `admins/${uid}`;
  const adminRef = doc(db, 'admins', uid);

  let exists = false;
  try {
    const snap = await getDoc(adminRef);
    exists = snap.exists();
  } catch {
    // Bootstrap creation may proceed if doc doesn't exist yet
    exists = false;
  }

  if (!exists) {
    try {
      await setDoc(adminRef, {
        uid,
        email,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, adminPath);
    }
  }
}

export interface EncryptedSnapshotExport {
  appName: string;
  totalChannels: number;
  totalSources: number;
  chunks: string[];
}

export async function saveEncryptedVaultToFirestore(
  snapshot: EncryptedSnapshotExport
): Promise<{ updatedAtIso: string; chunkCount: number }> {
  const user = auth.currentUser;
  if (!user || !user.emailVerified) {
    throw new Error('يرجى تسجيل الدخول بحساب Google الموثق للمزامنة السحابية.');
  }

  await ensureAdminProfileRegistered(user);

  const uid = sanitizeFirestoreId(user.uid);
  const manifestId = sanitizeFirestoreId(`vault_${uid}`);
  const manifestPath = `vault_manifests/${manifestId}`;
  const manifestRef = doc(db, 'vault_manifests', manifestId);

  const appName = (snapshot.appName || 'MS TV').trim().slice(0, MAX_APP_NAME_LENGTH);
  const chunks = snapshot.chunks || [];

  for (let i = 0; i < chunks.length; i++) {
    if (
      typeof chunks[i] !== 'string' ||
      chunks[i].length < MIN_CIPHER_LENGTH ||
      chunks[i].length > MAX_CIPHER_LENGTH
    ) {
      throw new Error(`حجم الجزء المشفر رقم ${i + 1} يتجاوز الحدود المسموحة.`);
    }
  }

  let existingChunkCount = 0;
  let manifestExists = false;
  try {
    const existingSnap = await getDoc(manifestRef);
    if (existingSnap.exists()) {
      manifestExists = true;
      existingChunkCount = Number(existingSnap.data()?.chunkCount || 0);
    }
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, manifestPath);
  }

  if (!manifestExists) {
    try {
      await setDoc(manifestRef, {
        ownerUid: uid,
        appName,
        chunkCount: chunks.length,
        totalChannels: Math.max(0, Math.floor(snapshot.totalChannels)),
        totalSources: Math.max(0, Math.floor(snapshot.totalSources)),
        status: 'active',
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, manifestPath);
    }
  } else {
    try {
      await updateDoc(manifestRef, {
        appName,
        chunkCount: chunks.length,
        totalChannels: Math.max(0, Math.floor(snapshot.totalChannels)),
        totalSources: Math.max(0, Math.floor(snapshot.totalSources)),
        status: 'active',
        updatedAt: serverTimestamp(),
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, manifestPath);
    }
  }

  // Write each bounded encrypted slice to subcollection
  for (let i = 0; i < chunks.length; i++) {
    const chunkId = sanitizeFirestoreId(`chunk_${i}`);
    const chunkPath = `vault_manifests/${manifestId}/chunks/${chunkId}`;
    const chunkRef = doc(db, 'vault_manifests', manifestId, 'chunks', chunkId);

    let chunkExists = false;
    try {
      const cSnap = await getDoc(chunkRef);
      chunkExists = cSnap.exists();
    } catch (error) {
      handleFirestoreError(error, OperationType.GET, chunkPath);
    }

    if (!chunkExists) {
      try {
        await setDoc(chunkRef, {
          manifestId,
          ownerUid: uid,
          chunkIndex: i,
          cipherPayload: chunks[i],
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        });
      } catch (error) {
        handleFirestoreError(error, OperationType.CREATE, chunkPath);
      }
    } else {
      try {
        await updateDoc(chunkRef, {
          chunkIndex: i,
          cipherPayload: chunks[i],
          updatedAt: serverTimestamp(),
        });
      } catch (error) {
        handleFirestoreError(error, OperationType.UPDATE, chunkPath);
      }
    }
  }

  // Clean up any stale trailing chunks if catalog shrank
  for (let i = chunks.length; i < existingChunkCount; i++) {
    const chunkId = sanitizeFirestoreId(`chunk_${i}`);
    const chunkPath = `vault_manifests/${manifestId}/chunks/${chunkId}`;
    const chunkRef = doc(db, 'vault_manifests', manifestId, 'chunks', chunkId);
    try {
      await deleteDoc(chunkRef);
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, chunkPath);
    }
  }

  return {
    updatedAtIso: new Date().toISOString(),
    chunkCount: chunks.length,
  };
}

export async function loadEncryptedVaultFromFirestore(): Promise<{
  totalChannels: number;
  totalSources: number;
  chunks: string[];
} | null> {
  const user = auth.currentUser;
  if (!user || !user.emailVerified) {
    return null;
  }

  const uid = sanitizeFirestoreId(user.uid);
  const manifestId = sanitizeFirestoreId(`vault_${uid}`);
  const manifestPath = `vault_manifests/${manifestId}`;
  const manifestRef = doc(db, 'vault_manifests', manifestId);

  let chunkCount = 0;
  let totalChannels = 0;
  let totalSources = 0;

  try {
    const snap = await getDoc(manifestRef);
    if (!snap.exists()) return null;
    const data = snap.data();
    chunkCount = Number(data?.chunkCount || 0);
    totalChannels = Number(data?.totalChannels || 0);
    totalSources = Number(data?.totalSources || 0);
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, manifestPath);
  }

  if (chunkCount <= 0) return null;

  const chunks: string[] = [];
  for (let i = 0; i < chunkCount; i++) {
    const chunkId = sanitizeFirestoreId(`chunk_${i}`);
    const chunkPath = `vault_manifests/${manifestId}/chunks/${chunkId}`;
    const chunkRef = doc(db, 'vault_manifests', manifestId, 'chunks', chunkId);
    try {
      const cSnap = await getDoc(chunkRef);
      if (!cSnap.exists()) {
        return null;
      }
      chunks.push(String(cSnap.data()?.cipherPayload || ''));
    } catch (error) {
      handleFirestoreError(error, OperationType.GET, chunkPath);
    }
  }

  return { totalChannels, totalSources, chunks };
}
