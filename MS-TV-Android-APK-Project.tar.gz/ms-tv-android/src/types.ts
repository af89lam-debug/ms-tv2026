export type StreamFormat = 'hls' | 'mpegts' | 'mp4' | 'auto';
export type ContentKind = 'live' | 'movie' | 'series';

export interface Channel {
  id: string;
  name: string;
  group: string;
  originalGroup: string;
  logo: string;
  streamFormat: StreamFormat;
  contentType: ContentKind;
  year?: string;
  featured: boolean;
  views: number;
  order: number;
  addedAt: string;
}

export interface CategorySummary {
  name: string;
  count: number;
  isFromSource: boolean;
  logo?: string;
}

export interface CustomPlaylist {
  id: string;
  name: string;
  color: string;
  channelIds: string[];
  isGlobal: boolean;
  ownerCode?: string;
  createdAt: string;
}

export type HeroActionType = 'watch_channel' | 'external_url' | 'category' | 'none';
export type HeroThemePreset = 'default' | 'telegram' | 'promo';

export interface HeroSlide {
  id: string;
  title: string;
  subtitle: string;
  badge: string;
  imageUrl: string;
  actionType?: HeroActionType;
  buttonText?: string;
  externalUrl?: string;
  channelId?: string;
  targetCategory?: string;
  showLiveBadge?: boolean;
  themePreset?: HeroThemePreset;
  order: number;
  active: boolean;
}

export interface SecurityPolicyConfig {
  blockSniffers: boolean;
  blockVpn: boolean;
  blockDevTools: boolean;
  strictStreamBinding: boolean;
}

export type SecurityEventType =
  | 'sniffer_blocked'
  | 'vpn_blocked'
  | 'device_limit'
  | 'devtools_tamper';

export interface SecurityAuditEvent {
  id: string;
  type: SecurityEventType;
  reason: string;
  ip: string;
  deviceName: string;
  subscriberCode?: string;
  userAgent?: string;
  createdAt: string;
}

export interface BoundDeviceInfo {
  deviceId: string;
  deviceName: string;
  ip: string;
  firstSeenAt: string;
  lastSeenAt: string;
}

export interface CatalogResponse {
  channels: Channel[];
  categories: CategorySummary[];
  heroSlides: HeroSlide[];
  customLists: CustomPlaylist[];
  favorites: string[];
  history: string[];
  durationDays: number;
  expiresAt: string | null;
  maxDevices?: number;
  connectedDevicesCount?: number;
  hideAdminEntryForUsers: boolean;
  securityPolicy: SecurityPolicyConfig;
  maintenanceMode?: boolean;
  maintenanceMessage?: string;
  apkDownloadUrl?: string;
  streamSessionToken?: string;
}

export interface PublicStatusResponse {
  appName: string;
  isInitialSetup: boolean;
  hideAdminEntryForUsers: boolean;
  hasRealSources: boolean;
  securityPolicy: SecurityPolicyConfig;
  maintenanceMode?: boolean;
  maintenanceMessage?: string;
  telegramUrl?: string;
  apkDownloadUrl?: string;
  initialHint: {
    defaultUserCode: string;
    defaultAdminCode: string;
  } | null;
}

export interface XtreamAccountInfo {
  status: string;
  expDate: string | null;
  maxConnections: string;
  activeCons: string;
}

export interface AdminSource {
  id: string;
  name: string;
  type: 'm3u_url' | 'm3u_text' | 'xtream' | 'direct' | 'starter';
  m3uUrl?: string;
  xtreamHost?: string;
  xtreamUsername?: string;
  xtreamPassword?: string;
  includeVod?: boolean;
  accountInfo?: XtreamAccountInfo;
  channelCount: number;
  groupsInOrder: string[];
  createdAt: string;
  lastSyncedAt: string;
}

export interface ViewerAccessCode {
  id: string;
  code: string;
  label: string;
  durationDays: number;
  expiresAt: string;
  createdAt: string;
  active: boolean;
  maxDevices: number;
  boundDevices: BoundDeviceInfo[];
  notes?: string;
}

export interface AdminOverviewResponse {
  sources: AdminSource[];
  accessCodes: ViewerAccessCode[];
  heroSlides: HeroSlide[];
  adminCode: string;
  telegramCodeUrl?: string;
  apkServerUrl?: string;
  apkDownloadUrl?: string;
  detectedServerUrl?: string;
  publicUrlStatus?: 'live' | 'not_published_404' | 'blocked_403' | 'unreachable';
  hideAdminEntryForUsers: boolean;
  isInitialSetup: boolean;
  totalChannels: number;
  categories: CategorySummary[];
  excludedCategories?: string[];
  maintenanceMode?: boolean;
  maintenanceMessage?: string;
  securityPolicy: SecurityPolicyConfig;
  securityEvents: SecurityAuditEvent[];
}

export interface StreamTicketResponse {
  ticket: string;
  streamFormat: StreamFormat;
  expiresAtMs: number;
}

export type NavSection =
  | 'home'
  | 'live_tv'
  | 'sports'
  | 'movies'
  | 'series'
  | 'kids'
  | 'entertainment'
  | 'documentary'
  | 'favorites'
  | 'history'
  | 'settings'
  | 'm3u_group'
  | 'custom_list';
