import { Capacitor } from '@capacitor/core';
import type {
  AdminOverviewResponse,
  CatalogResponse,
  CategorySummary,
  Channel,
  CustomPlaylist,
  HeroSlide,
  PublicStatusResponse,
  SecurityAuditEvent,
  SecurityPolicyConfig,
  StreamTicketResponse,
  ViewerAccessCode,
} from './types';

const VIEWER_TOKEN_KEY = 'iptv_max_viewer_token';
const ADMIN_TOKEN_KEY = 'iptv_max_admin_token';
const SESSION_LABEL_KEY = 'iptv_max_session_label';
const DEVICE_ID_KEY = 'mstv_device_id_v1';
const APK_SERVER_URL_KEY = 'ms_tv_apk_server_url';
const FALLBACK_APK_SERVER_URL =
  'https://ais-pre-gwz3v7fp463k2pyv5es5x7-974887104090.europe-west2.run.app';

let memoryDeviceId: string | null = null;
let loadedApkConfigServerUrl = '';

export function isNativeApkRuntime(): boolean {
  if (typeof window === 'undefined') return false;
  try {
    if (Capacitor.isNativePlatform()) return true;
  } catch {
    // ignore
  }
  const proto = window.location.protocol;
  if (proto === 'capacitor:' || proto === 'ionic:') return true;
  if (
    window.location.hostname === 'localhost' &&
    !window.location.port &&
    typeof navigator !== 'undefined' &&
    /MSTVApp\//i.test(navigator.userAgent)
  ) {
    return true;
  }
  return false;
}

export function normalizeServerBaseUrl(raw: string): string {
  const cleaned = String(raw || '')
    .trim()
    .replace(/\/+$/, '')
    .replace(/^https:\/\/ais-dev-/i, 'https://ais-pre-');
  if (!cleaned || !/^https?:\/\//i.test(cleaned)) return '';
  return cleaned;
}

export function getApkServerUrl(): string {
  try {
    const custom = normalizeServerBaseUrl(localStorage.getItem(APK_SERVER_URL_KEY) || '');
    if (custom) return custom;
  } catch {
    // ignore
  }
  const envUrl = normalizeServerBaseUrl(
    (import.meta as unknown as { env?: Record<string, string> }).env?.VITE_API_BASE_URL || ''
  );
  if (envUrl) return envUrl;
  if (loadedApkConfigServerUrl) return loadedApkConfigServerUrl;
  return FALLBACK_APK_SERVER_URL;
}

export function setApkServerUrl(url: string | null): void {
  try {
    const clean = normalizeServerBaseUrl(url || '');
    if (clean) {
      localStorage.setItem(APK_SERVER_URL_KEY, clean);
    } else {
      localStorage.removeItem(APK_SERVER_URL_KEY);
    }
  } catch {
    // ignore
  }
}

export async function initApkRuntimeConfig(): Promise<void> {
  if (!isNativeApkRuntime()) return;
  try {
    const res = await fetch('./apk-config.json', { cache: 'no-store' });
    if (res.ok) {
      const json = (await res.json()) as { serverUrl?: string };
      const parsed = normalizeServerBaseUrl(json?.serverUrl || '');
      if (parsed) {
        loadedApkConfigServerUrl = parsed;
      }
    }
  } catch {
    // ignore missing local config
  }
}

export function getApiOrigin(): string {
  if (isNativeApkRuntime()) {
    return getApkServerUrl();
  }
  return typeof window !== 'undefined' ? window.location.origin : '';
}

export function resolveApiUrl(pathOrUrl: string): string {
  if (/^https?:\/\//i.test(pathOrUrl)) return pathOrUrl;
  if (isNativeApkRuntime()) {
    const base = getApkServerUrl();
    return `${base}${pathOrUrl.startsWith('/') ? pathOrUrl : `/${pathOrUrl}`}`;
  }
  return pathOrUrl;
}

export function getDeviceId(): string {
  try {
    const existing = localStorage.getItem(DEVICE_ID_KEY) || sessionStorage.getItem(DEVICE_ID_KEY);
    if (existing && existing.length >= 12) {
      memoryDeviceId = existing;
      return existing;
    }
  } catch {
    if (memoryDeviceId) return memoryDeviceId;
  }

  let randomHex = '';
  if (typeof window !== 'undefined' && window.crypto?.getRandomValues) {
    const bytes = new Uint8Array(12);
    window.crypto.getRandomValues(bytes);
    randomHex = Array.from(bytes, (b) => b.toString(16).padStart(2, '0')).join('');
  } else {
    randomHex = `${Date.now().toString(16)}${Math.random().toString(16).slice(2, 14)}`;
  }

  const generated = `dev_${randomHex}`;
  memoryDeviceId = generated;
  try {
    localStorage.setItem(DEVICE_ID_KEY, generated);
    sessionStorage.setItem(DEVICE_ID_KEY, generated);
  } catch {
    // ignore storage quota errors
  }
  return generated;
}

export function getDeviceName(): string {
  if (typeof navigator === 'undefined') return 'متصفح ويب';
  const ua = navigator.userAgent || '';

  let os = 'جهاز';
  if (/smart-tv|smarttv|googletv|appletv|hbbtv|pov_tv|netcast|webos|tizen|bravia/i.test(ua)) {
    os = 'شاشة ذكية TV';
  } else if (/android/i.test(ua)) {
    os = 'Android';
  } else if (/ipad/i.test(ua)) {
    os = 'iPad';
  } else if (/iphone|ipod/i.test(ua)) {
    os = 'iPhone';
  } else if (/windows/i.test(ua)) {
    os = 'Windows';
  } else if (/macintosh|mac os x/i.test(ua)) {
    os = 'Mac';
  } else if (/linux/i.test(ua)) {
    os = 'Linux';
  }

  let browser = 'Browser';
  if (isNativeApkRuntime() || /MSTVApp\//i.test(ua)) {
    browser = 'تطبيق MS TV';
  } else if (/edg\//i.test(ua)) {
    browser = 'Edge';
  } else if (/opr\/|opera/i.test(ua)) {
    browser = 'Opera';
  } else if (/samsungbrowser/i.test(ua)) {
    browser = 'Samsung';
  } else if (/chrome\/|crios\//i.test(ua)) {
    browser = 'Chrome';
  } else if (/firefox\/|fxios\//i.test(ua)) {
    browser = 'Firefox';
  } else if (/safari\//i.test(ua)) {
    browser = 'Safari';
  }

  return `${os} · ${browser}`;
}

export function getClientTimezone(): string {
  try {
    return Intl.DateTimeFormat().resolvedOptions().timeZone || '';
  } catch {
    return '';
  }
}

export function getViewerToken(): string | null {
  return localStorage.getItem(VIEWER_TOKEN_KEY);
}

export function setViewerSession(token: string, label: string): void {
  localStorage.setItem(VIEWER_TOKEN_KEY, token);
  localStorage.setItem(SESSION_LABEL_KEY, label);
}

export function getSessionLabel(): string {
  return localStorage.getItem(SESSION_LABEL_KEY) || 'مشترك متصل';
}

export function clearViewerSession(): void {
  localStorage.removeItem(VIEWER_TOKEN_KEY);
  localStorage.removeItem(ADMIN_TOKEN_KEY);
  localStorage.removeItem(SESSION_LABEL_KEY);
}

export function getAdminToken(): string | null {
  return localStorage.getItem(ADMIN_TOKEN_KEY);
}

export function setAdminToken(token: string | null): void {
  if (token) {
    localStorage.setItem(ADMIN_TOKEN_KEY, token);
  } else {
    localStorage.removeItem(ADMIN_TOKEN_KEY);
  }
}

/**
 * Builds an absolute URL for protected stream playback using a short-lived,
 * session-bound encrypted ticket (prevents link theft AND fixes Web Worker relative URL errors).
 */
export function buildProtectedStreamUrl(
  ticket: string,
  engine: 'hls' | 'mpegts' | 'native',
  playId?: string
): string {
  const origin = getApiOrigin();
  const params = new URLSearchParams({
    engine,
    d: getDeviceId(),
  });
  if (playId) {
    params.set('pid', playId);
  }
  return `${origin}/api/stream-play/${encodeURIComponent(ticket)}?${params.toString()}`;
}

/**
 * Builds an instant 0ms single-round-trip protected stream URL using the viewer's
 * encrypted session token so clicking or zapping channels starts immediately without
 * waiting for a separate POST /api/stream-ticket round-trip.
 */
export function buildFastSessionStreamUrl(
  sessionToken: string,
  channelId: string,
  engine: 'hls' | 'mpegts' | 'native',
  options?: { refreshEdge?: boolean; nonce?: number; playId?: string }
): string {
  const origin = getApiOrigin();
  const params = new URLSearchParams({
    engine,
    d: getDeviceId(),
  });
  if (options?.playId) {
    params.set('pid', options.playId);
  }
  if (options?.refreshEdge) {
    params.set('r', '1');
  }
  if (options?.nonce) {
    params.set('n', String(options.nonce));
  }
  return `${origin}/api/stream-play-fast/${encodeURIComponent(sessionToken)}/${encodeURIComponent(
    channelId
  )}?${params.toString()}`;
}

export type ApiError = Error & {
  status?: number;
  code?: string;
};

async function requestJson<T>(url: string, init: RequestInit = {}): Promise<T> {
  const method = (init.method || 'GET').toUpperCase();
  const maxAttempts = method === 'GET' ? 3 : 1;

  for (let attempt = 0; attempt < maxAttempts; attempt++) {
    const headers = new Headers(init.headers || {});
    if (!headers.has('Content-Type') && init.body) {
      headers.set('Content-Type', 'application/json');
    }
    headers.set('X-Device-Id', getDeviceId());
    headers.set('X-Device-Name', encodeURIComponent(getDeviceName()));
    const tz = getClientTimezone();
    if (tz) {
      headers.set('X-Client-Tz', tz);
    }

    const viewerToken = getViewerToken();
    if (viewerToken) {
      headers.set('Authorization', `Bearer ${viewerToken}`);
    }
    const adminToken = getAdminToken();
    if (adminToken) {
      headers.set('X-Admin-Token', adminToken);
    }

    try {
      const res = await fetch(resolveApiUrl(url), { ...init, headers });
      const data = await res.json().catch(() => ({}));
      if (
        [502, 503, 504].includes(res.status) &&
        data?.code !== 'MAINTENANCE_MODE' &&
        attempt < maxAttempts - 1
      ) {
        await new Promise((r) => setTimeout(r, 350 * (attempt + 1)));
        continue;
      }
      if (!res.ok) {
        const fallbackMsg =
          res.status === 403
            ? 'رفض الوصول للرابط (403): تأكد من استخدام الرابط العام للمشتركين وتفعيل المشاركة العامة (Share) أو نشر التطبيق عبر (Deploy).'
            : `خطأ في الطلب (${res.status})`;
        const err = new Error(data?.error || fallbackMsg) as ApiError;
        err.status = res.status;
        err.code = data?.code;
        throw err;
      }
      return data as T;
    } catch (err: any) {
      const isAuthOrPolicyErr =
        err?.code === 'MAINTENANCE_MODE' ||
        (typeof err?.status === 'number' && ![502, 503, 504].includes(err.status));
      if (isAuthOrPolicyErr || attempt >= maxAttempts - 1) {
        throw err;
      }
      await new Promise((r) => setTimeout(r, 350 * (attempt + 1)));
    }
  }

  throw new Error('تعذر الاتصال بالخادم.');
}

export const api = {
  getPublicStatus: () => requestJson<PublicStatusResponse>('/api/auth/public-status'),

  loginWithCode: (code: string) =>
    requestJson<{
      token: string;
      adminToken?: string;
      label: string;
      durationDays: number;
      expiresAt: string | null;
      maxDevices?: number;
      connectedDevicesCount?: number;
      isAdminUnlocked: boolean;
    }>('/api/auth/login', {
      method: 'POST',
      body: JSON.stringify({
        code,
        deviceId: getDeviceId(),
        deviceName: getDeviceName(),
      }),
    }),

  verifyAdminCode: (adminCode: string) =>
    requestJson<{ adminToken: string }>('/api/admin/auth', {
      method: 'POST',
      body: JSON.stringify({ adminCode }),
    }),

  checkSecurityAccess: () =>
    requestJson<{
      ok: boolean;
      securityPolicy: SecurityPolicyConfig;
      maintenanceMode?: boolean;
      maintenanceMessage?: string;
    }>('/api/security/check'),

  reportSecurityTamper: (payload: {
    type: 'sniffer_blocked' | 'devtools_tamper';
    reason: string;
  }) => {
    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
      'X-Device-Id': getDeviceId(),
      'X-Device-Name': encodeURIComponent(getDeviceName()),
    };
    const viewerToken = getViewerToken();
    if (viewerToken) headers['Authorization'] = `Bearer ${viewerToken}`;
    return fetch(resolveApiUrl('/api/security/report'), {
      method: 'POST',
      headers,
      body: JSON.stringify(payload),
      keepalive: true,
    }).catch(() => {});
  },

  getCatalog: (options?: { boot?: boolean }) =>
    requestJson<CatalogResponse>(options?.boot ? '/api/catalog?boot=1' : '/api/catalog'),

  issueStreamTicket: (channelId: string, options?: { refreshEdge?: boolean }) =>
    requestJson<StreamTicketResponse>(`/api/stream-ticket/${encodeURIComponent(channelId)}`, {
      method: 'POST',
      body: JSON.stringify({
        refreshEdge: Boolean(options?.refreshEdge),
        deviceId: getDeviceId(),
      }),
    }),

  sendStreamHeartbeat: (ticketOrSession: string, channelId?: string) =>
    requestJson<{ ok: boolean }>('/api/stream-heartbeat', {
      method: 'POST',
      body: JSON.stringify({
        ticket: ticketOrSession,
        channelId: channelId || '',
        deviceId: getDeviceId(),
      }),
    }),

  releaseStream: (
    ticket?: string | null,
    options?: { playId?: string | null; reason?: 'cleanup' | 'pagehide' }
  ) => {
    const viewerToken = getViewerToken();
    const bodyStr = JSON.stringify({
      ticket: ticket || '',
      playId: options?.playId || '',
      reason: options?.reason || 'cleanup',
      deviceId: getDeviceId(),
      viewerToken: viewerToken || undefined,
    });

    const releaseEndpoint = resolveApiUrl('/api/stream-release');

    if (
      options?.reason === 'pagehide' &&
      typeof navigator !== 'undefined' &&
      typeof navigator.sendBeacon === 'function'
    ) {
      try {
        const queued = navigator.sendBeacon(
          releaseEndpoint,
          new Blob([bodyStr], { type: 'application/json' })
        );
        if (queued) return;
      } catch {
        // fall through to keepalive fetch
      }
    }

    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
      'X-Device-Id': getDeviceId(),
    };
    if (viewerToken) {
      headers['Authorization'] = `Bearer ${viewerToken}`;
    }
    fetch(releaseEndpoint, {
      method: 'POST',
      headers,
      body: bodyStr,
      keepalive: true,
    }).catch(() => {});
  },

  recordChannelView: (channelId: string) =>
    requestJson<{ ok: boolean }>(`/api/channels/${encodeURIComponent(channelId)}/view`, {
      method: 'POST',
    }),

  toggleFavorite: (channelId: string) =>
    requestJson<{ favorites: string[] }>('/api/favorites/toggle', {
      method: 'POST',
      body: JSON.stringify({ channelId }),
    }),

  createCustomList: (payload: {
    name: string;
    color: string;
    channelIds: string[];
    isGlobal?: boolean;
  }) =>
    requestJson<{ list: CustomPlaylist }>('/api/lists', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),

  updateCustomList: (
    listId: string,
    payload: { name?: string; color?: string; channelIds?: string[] }
  ) =>
    requestJson<{ list: CustomPlaylist }>(`/api/lists/${encodeURIComponent(listId)}`, {
      method: 'PUT',
      body: JSON.stringify(payload),
    }),

  deleteCustomList: (listId: string) =>
    requestJson<{ ok: boolean }>(`/api/lists/${encodeURIComponent(listId)}`, {
      method: 'DELETE',
    }),

  // Admin APIs (Require valid X-Admin-Token)
  getAdminOverview: () => requestJson<AdminOverviewResponse>('/api/admin/overview'),

  addM3uSource: (payload: { name: string; m3uUrl?: string; m3uContent?: string }) =>
    requestJson<{ addedCount: number; groupsCount: number }>('/api/admin/sources/m3u', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),

  addXtreamSource: (payload: {
    name: string;
    host: string;
    username: string;
    password: string;
    includeVod: boolean;
  }) =>
    requestJson<{ addedCount: number; groupsCount: number }>('/api/admin/sources/xtream', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),

  addDirectChannel: (payload: {
    name: string;
    streamUrl: string;
    group: string;
    logo?: string;
    contentType?: 'live' | 'movie' | 'series';
  }) =>
    requestJson<{ channel: Channel }>('/api/admin/sources/direct', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),

  refreshSource: (sourceId: string) =>
    requestJson<{ addedCount: number }>(
      `/api/admin/sources/${encodeURIComponent(sourceId)}/refresh`,
      {
        method: 'POST',
      }
    ),

  deleteSource: (sourceId: string) =>
    requestJson<{ ok: boolean }>(`/api/admin/sources/${encodeURIComponent(sourceId)}`, {
      method: 'DELETE',
    }),

  updateChannel: (
    channelId: string,
    payload: {
      name?: string;
      group?: string;
      logo?: string;
      featured?: boolean;
    }
  ) =>
    requestJson<{ channel: Channel }>(`/api/admin/channels/${encodeURIComponent(channelId)}`, {
      method: 'PATCH',
      body: JSON.stringify(payload),
    }),

  deleteChannel: (channelId: string) =>
    requestJson<{ ok: boolean }>(`/api/admin/channels/${encodeURIComponent(channelId)}`, {
      method: 'DELETE',
    }),

  bulkMoveChannels: (channelIds: string[], targetGroup: string) =>
    requestJson<{ movedCount: number; targetGroup: string }>('/api/admin/channels/bulk-move', {
      method: 'POST',
      body: JSON.stringify({ channelIds, targetGroup }),
    }),

  createCategory: (name: string, logo?: string) =>
    requestJson<{ categories: CategorySummary[] }>('/api/admin/categories', {
      method: 'POST',
      body: JSON.stringify({ name, logo }),
    }),

  updateCategoryLogo: (name: string, logo: string) =>
    requestJson<{ categories: CategorySummary[] }>('/api/admin/categories/logo', {
      method: 'PATCH',
      body: JSON.stringify({ name, logo }),
    }),

  renameCategory: (oldName: string, newName: string) =>
    requestJson<{ categories: CategorySummary[] }>('/api/admin/categories/rename', {
      method: 'PATCH',
      body: JSON.stringify({ oldName, newName }),
    }),

  moveCategory: (name: string, direction: 'up' | 'down' | 'top' | 'bottom') =>
    requestJson<{ categories: CategorySummary[] }>('/api/admin/categories/move', {
      method: 'POST',
      body: JSON.stringify({ name, direction }),
    }),

  reorderCategories: (orderedNames: string[]) =>
    requestJson<{ categories: CategorySummary[] }>('/api/admin/categories/reorder', {
      method: 'PUT',
      body: JSON.stringify({ orderedNames }),
    }),

  deleteCategories: (categories: string[], blockFutureSync = true) =>
    requestJson<{
      deletedCategoriesCount: number;
      deletedChannelsCount: number;
      categories: CategorySummary[];
      excludedCategories: string[];
      totalChannels: number;
    }>('/api/admin/categories/delete', {
      method: 'POST',
      body: JSON.stringify({ categories, blockFutureSync }),
    }),

  restoreExcludedCategories: (categories: string[]) =>
    requestJson<{ excludedCategories: string[] }>('/api/admin/categories/excluded/restore', {
      method: 'POST',
      body: JSON.stringify({ categories }),
    }),

  // Hero Banner Slides Admin Management
  createHeroSlide: (payload: {
    title: string;
    subtitle: string;
    badge: string;
    imageUrl: string;
    actionType?: 'watch_channel' | 'external_url' | 'category' | 'none';
    buttonText?: string;
    externalUrl?: string;
    channelId?: string;
    targetCategory?: string;
    showLiveBadge?: boolean;
    themePreset?: 'default' | 'telegram' | 'promo';
    active?: boolean;
  }) =>
    requestJson<{ heroSlides: HeroSlide[] }>('/api/admin/hero-slides', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),

  updateHeroSlide: (
    id: string,
    payload: {
      title?: string;
      subtitle?: string;
      badge?: string;
      imageUrl?: string;
      actionType?: 'watch_channel' | 'external_url' | 'category' | 'none';
      buttonText?: string;
      externalUrl?: string;
      channelId?: string;
      targetCategory?: string;
      showLiveBadge?: boolean;
      themePreset?: 'default' | 'telegram' | 'promo';
      active?: boolean;
    }
  ) =>
    requestJson<{ heroSlides: HeroSlide[] }>(
      `/api/admin/hero-slides/${encodeURIComponent(id)}`,
      {
        method: 'PUT',
        body: JSON.stringify(payload),
      }
    ),

  moveHeroSlide: (id: string, direction: 'up' | 'down') =>
    requestJson<{ heroSlides: HeroSlide[] }>(
      `/api/admin/hero-slides/${encodeURIComponent(id)}/move`,
      {
        method: 'POST',
        body: JSON.stringify({ direction }),
      }
    ),

  deleteHeroSlide: (id: string) =>
    requestJson<{ heroSlides: HeroSlide[] }>(
      `/api/admin/hero-slides/${encodeURIComponent(id)}`,
      {
        method: 'DELETE',
      }
    ),

  // Subscriptions & Access Codes Management (1-Person or Custom Multi-Person)
  createAccessCode: (payload: {
    code: string;
    label: string;
    expiresAt: string;
    maxDevices?: number;
    notes?: string;
  }) =>
    requestJson<{ accessCodes: ViewerAccessCode[] }>('/api/admin/codes', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),

  updateAccessCode: (
    id: string,
    payload: {
      code?: string;
      label?: string;
      expiresAt?: string;
      active?: boolean;
      maxDevices?: number;
      notes?: string;
    }
  ) =>
    requestJson<{ accessCodes: ViewerAccessCode[] }>(`/api/admin/codes/${encodeURIComponent(id)}`, {
      method: 'PATCH',
      body: JSON.stringify(payload),
    }),

  resetAccessCodeDevices: (id: string, deviceId?: string) =>
    requestJson<{ accessCodes: ViewerAccessCode[] }>(
      `/api/admin/codes/${encodeURIComponent(id)}/reset-devices`,
      {
        method: 'POST',
        body: JSON.stringify({ deviceId }),
      }
    ),

  deleteAccessCode: (id: string) =>
    requestJson<{ accessCodes: ViewerAccessCode[] }>(`/api/admin/codes/${encodeURIComponent(id)}`, {
      method: 'DELETE',
    }),

  updateMaintenance: (payload: { maintenanceMode?: boolean; maintenanceMessage?: string }) =>
    requestJson<{
      maintenanceMode: boolean;
      maintenanceMessage: string;
    }>('/api/admin/maintenance', {
      method: 'PATCH',
      body: JSON.stringify(payload),
    }),

  updateApkSettings: (payload: { apkServerUrl?: string; apkDownloadUrl?: string }) =>
    requestJson<{
      apkServerUrl: string;
      apkDownloadUrl: string;
      detectedServerUrl: string;
    }>('/api/admin/apk-settings', {
      method: 'PATCH',
      body: JSON.stringify(payload),
    }),

  getApkProjectDownloadUrl: (): string => {
    const adminToken = getAdminToken() || '';
    const base = resolveApiUrl('/api/admin/apk-project/download');
    return `${base}?at=${encodeURIComponent(adminToken)}`;
  },

  updateSecurityPolicy: (payload: Partial<SecurityPolicyConfig>) =>
    requestJson<{
      securityPolicy: SecurityPolicyConfig;
      securityEvents: SecurityAuditEvent[];
    }>('/api/admin/security-policy', {
      method: 'PATCH',
      body: JSON.stringify(payload),
    }),

  clearSecurityEvents: () =>
    requestJson<{ securityEvents: SecurityAuditEvent[] }>('/api/admin/security-events', {
      method: 'DELETE',
    }),

  updateAdminSecurity: (payload: {
    newAdminCode?: string;
    primaryUserCode?: string;
    telegramCodeUrl?: string;
    hideAdminEntryForUsers?: boolean;
    dismissInitialHint?: boolean;
  }) =>
    requestJson('/api/admin/security', {
      method: 'PATCH',
      body: JSON.stringify(payload),
    }),

  // Cloud Vault Encrypted Backup / Restore
  exportCloudSnapshot: () =>
    requestJson<{
      appName: string;
      totalChannels: number;
      totalSources: number;
      chunks: string[];
    }>('/api/admin/cloud-snapshot'),

  importCloudSnapshot: (chunks: string[]) =>
    requestJson<{ restoredChannels: number; restoredSources: number }>(
      '/api/admin/cloud-restore',
      {
        method: 'POST',
        body: JSON.stringify({ chunks }),
      }
    ),
};
