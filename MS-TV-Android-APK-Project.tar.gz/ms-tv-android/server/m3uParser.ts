import crypto from 'node:crypto';
import http from 'node:http';
import https from 'node:https';
import zlib from 'node:zlib';

export type StreamFormat = 'hls' | 'mpegts' | 'mp4' | 'auto';
export type ContentKind = 'live' | 'movie' | 'series';

export interface ParsedChannelInput {
  signature: string;
  name: string;
  group: string;
  logo: string;
  streamUrl: string;
  fallbackStreamUrl?: string;
  streamFormat: StreamFormat;
  contentType: ContentKind;
  userAgent?: string;
  referrer?: string;
  year?: string;
  order: number;
}

export interface ParsedPlaylistResult {
  channels: ParsedChannelInput[];
  groupsInOrder: string[];
}

export interface XtreamAccountInfo {
  status: string;
  expDate: string | null;
  maxConnections: string;
  activeCons: string;
}

export interface XtreamSyncResult extends ParsedPlaylistResult {
  accountInfo: XtreamAccountInfo;
}

const USER_AGENT_PROFILES = [
  'VLC/3.0.20 LibVLC/3.0.20',
  'IPTVSmartersPro/1.1.1 (iPad; iOS 16.5; Scale/2.00)',
  'TiviMate/4.7.0 (Linux; Android 12)',
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
];

/**
 * Strips invisible Unicode directional marks (common when copying URLs from
 * WhatsApp/Telegram in Arabic RTL chats, e.g. \u200E, \u200F, \u202A-\u202E, \u2066-\u2069),
 * extracts embedded URLs if pasted with label text, and fixes GitHub blob links.
 */
export function cleanIptvUrl(rawInput: string): string {
  let cleaned = rawInput
    .replace(/[\u200B-\u200F\u202A-\u202E\u2060-\u206F\uFEFF\u00A0]/g, '')
    .replace(/&amp;/gi, '&')
    .trim();

  // Extract http(s) URL if user pasted surrounding message text like "رابط البث: http://..."
  const embeddedMatch = cleaned.match(/https?:\/\/[^\s"'<>]+/i);
  if (embeddedMatch) {
    cleaned = embeddedMatch[0];
  } else if (cleaned && !/^[a-z]+:\/\//i.test(cleaned)) {
    cleaned = `http://${cleaned}`;
  }

  // Strip trailing punctuation or quotes accidentally copied from chat messages
  cleaned = cleaned.replace(/[.,;،؛"'`]+$/, '').trim();

  // Auto-convert GitHub /blob/ webpage links to raw playlist URLs
  const ghBlobMatch = cleaned.match(
    /^https?:\/\/github\.com\/([^/]+)\/([^/]+)\/blob\/(.+)$/i
  );
  if (ghBlobMatch) {
    cleaned = `https://raw.githubusercontent.com/${ghBlobMatch[1]}/${ghBlobMatch[2]}/${ghBlobMatch[3]}`;
  }

  // Auto-convert Pastebin share links to raw playlist URLs
  const pastebinMatch = cleaned.match(/^https?:\/\/(?:www\.)?pastebin\.com\/(?!raw\/)([A-Za-z0-9]+)\/?$/i);
  if (pastebinMatch) {
    cleaned = `https://pastebin.com/raw/${pastebinMatch[1]}`;
  }

  // Auto-convert Dropbox ?dl=0 share links to direct download ?dl=1
  if (/dropbox\.com\//i.test(cleaned) && cleaned.includes('dl=0')) {
    cleaned = cleaned.replace('dl=0', 'dl=1');
  }

  // Auto-fix legacy iptv-org URLs that moved paths and otherwise return 404
  cleaned = cleaned
    .replace(
      /^https?:\/\/raw\.githubusercontent\.com\/iptv-org\/iptv\/(master|main)\/channels\//i,
      'https://raw.githubusercontent.com/iptv-org/iptv/master/streams/'
    )
    .replace(
      /^https?:\/\/iptv-org\.github\.io\/iptv\/countries\/arab\.m3u8?$/i,
      'https://iptv-org.github.io/iptv/languages/ara.m3u'
    )
    .replace(
      /^https?:\/\/iptv-org\.github\.io\/iptv\/country\//i,
      'https://iptv-org.github.io/iptv/countries/'
    )
    .replace(
      /^https?:\/\/iptv-org\.github\.io\/iptv\/language\//i,
      'https://iptv-org.github.io/iptv/languages/'
    )
    .replace(
      /^https?:\/\/iptv-org\.github\.io\/iptv\/category\//i,
      'https://iptv-org.github.io/iptv/categories/'
    );

  return cleaned;
}

interface HttpTextResult {
  statusCode: number;
  body: string;
  finalUrl: string;
}

/**
 * Uses Node native http/https with insecureHTTPParser=true and self-signed TLS
 * tolerance so non-standard IPTV/Xtream panels work reliably.
 */
export function requestTextResilient(
  rawUrl: string,
  userAgent: string,
  timeoutMs = 25000,
  redirectCount = 0
): Promise<HttpTextResult> {
  return new Promise((resolve, reject) => {
    if (redirectCount > 6) {
      reject(new Error('عدد عمليات إعادة التوجيه للرابط كبير جداً.'));
      return;
    }

    let parsedUrl: URL;
    try {
      parsedUrl = new URL(rawUrl);
    } catch {
      reject(new Error('صيغة الرابط غير صالحة، تأكد من كتابة الرابط بشكل كامل.'));
      return;
    }

    const isHttps = parsedUrl.protocol === 'https:';
    const transport = isHttps ? https : http;

    const req = transport.request(
      parsedUrl,
      {
        method: 'GET',
        insecureHTTPParser: true,
        rejectUnauthorized: false,
        headers: {
          'User-Agent': userAgent,
          Accept: '*/*',
          'Accept-Encoding': 'gzip, deflate',
          Connection: 'close',
        },
      },
      (res) => {
        const status = res.statusCode || 0;
        const location = res.headers.location;

        if ([301, 302, 303, 307, 308].includes(status) && location) {
          res.resume();
          let nextUrl: string;
          try {
            nextUrl = new URL(location, parsedUrl).toString();
          } catch {
            reject(new Error('فشل تتبع رابط إعادة التوجيه.'));
            return;
          }
          requestTextResilient(nextUrl, userAgent, timeoutMs, redirectCount + 1)
            .then(resolve)
            .catch(reject);
          return;
        }

        const encoding = (res.headers['content-encoding'] || '').toLowerCase();
        let stream: NodeJS.ReadableStream = res;
        if (encoding === 'gzip') {
          stream = res.pipe(zlib.createGunzip());
        } else if (encoding === 'deflate') {
          stream = res.pipe(zlib.createInflate());
        }

        const chunks: Buffer[] = [];
        let totalBytes = 0;
        const MAX_BYTES = 95 * 1024 * 1024; // Up to 95MB M3U playlists

        stream.on('data', (chunk: Buffer) => {
          totalBytes += chunk.length;
          if (totalBytes <= MAX_BYTES) {
            chunks.push(Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk));
          } else {
            req.destroy(new Error('حجم ملف M3U كبير جداً (يتجاوز 95 ميجابايت).'));
          }
        });

        stream.on('end', () => {
          const body = Buffer.concat(chunks).toString('utf-8');
          resolve({ statusCode: status, body, finalUrl: rawUrl });
        });

        stream.on('error', (err) => {
          reject(err);
        });
      }
    );

    req.setTimeout(timeoutMs, () => {
      req.destroy(new Error('انتهت مهلة الاتصال بسيرفر البث.'));
    });

    req.on('error', (err) => {
      reject(err);
    });

    req.end();
  });
}

export function computeStreamSignature(url: string, fallbackName: string): string {
  return crypto
    .createHash('sha1')
    .update(`${url.trim()}|${fallbackName.trim()}`)
    .digest('hex')
    .slice(0, 16);
}

export function isSeparatorBannerName(name: string): boolean {
  const trimmed = (name || '').trim();
  if (!trimmed) return true;
  return /^[#=*\-_~]{3,}.*[#=*\-_~]{3,}$/.test(trimmed);
}

/**
 * Detects Xtream / XUI.one live stream URLs and returns both the continuous MPEG-TS (.ts)
 * and HLS (.m3u8) URLs. Using .ts as primary on MSE-capable browsers prevents Xtream's
 * stateless HLS Redis session lock (which otherwise holds active_cons=1 for minutes on
 * max_connections=1 accounts and causes HTTP 401 channel lockouts).
 */
export function getXtreamLiveProtocolPair(
  url: string
): { tsUrl: string; hlsUrl: string } | null {
  try {
    const u = new URL(url);
    const origin = `${u.protocol}//${u.host}`;
    const segs = u.pathname.split('/').filter(Boolean);

    // Pattern 1: /live/USER/PASS/12345(.m3u8|.ts)?
    if (segs.length === 4 && segs[0].toLowerCase() === 'live') {
      const [, user, pass, file] = segs;
      const match = file.match(/^(\d+)(?:\.(m3u8|ts))?$/i);
      if (match) {
        const streamId = match[1];
        return {
          tsUrl: `${origin}/live/${user}/${pass}/${streamId}.ts`,
          hlsUrl: `${origin}/live/${user}/${pass}/${streamId}.m3u8`,
        };
      }
    }

    // Pattern 2: /USER/PASS/12345(.m3u8|.ts)?
    if (
      segs.length === 3 &&
      !['movie', 'series', 'hls', 'live', 'streams'].includes(segs[0].toLowerCase())
    ) {
      const [user, pass, last] = segs;
      const match = last.match(/^(\d+)(?:\.(m3u8|ts))?$/i);
      if (match) {
        const streamId = match[1];
        return {
          tsUrl: `${origin}/live/${user}/${pass}/${streamId}.ts`,
          hlsUrl: `${origin}/live/${user}/${pass}/${streamId}.m3u8`,
        };
      }
    }
  } catch {
    // ignore non-standard URLs
  }
  return null;
}

export function detectStreamFormat(url: string): StreamFormat {
  const lower = url.toLowerCase().split('?')[0];
  if (lower.endsWith('.mp4') || lower.endsWith('.mkv') || lower.endsWith('.webm')) {
    return 'mp4';
  }
  // Prefer continuous MPEG-TS for Xtream live streams so active_cons releases instantaneously on channel switch
  if (getXtreamLiveProtocolPair(url)) {
    return 'mpegts';
  }
  if (lower.endsWith('.m3u8')) return 'hls';
  if (lower.endsWith('.ts')) return 'mpegts';
  if (lower.includes('/live/')) {
    return 'mpegts';
  }
  return 'auto';
}

/**
 * Automatically derives an alternate HLS (.m3u8) or MPEG-TS (.ts) URL for Xtream-style
 * stream links inside M3U playlists so if one protocol fails, the proxy seamlessly falls back.
 */
export function deriveStreamFallbackUrl(url: string): string | undefined {
  const pair = getXtreamLiveProtocolPair(url);
  if (pair) {
    const cleanNoQuery = url.split('?')[0].toLowerCase();
    return cleanNoQuery.endsWith('.ts') ? pair.hlsUrl : pair.tsUrl;
  }
  return undefined;
}

export function expandStreamUrlCandidates(
  primaryUrl: string,
  fallbackUrl?: string,
  preferredEngine: 'hls' | 'mpegts' | 'native' | 'auto' = 'auto'
): string[] {
  const xtreamPair =
    getXtreamLiveProtocolPair(primaryUrl) ||
    (fallbackUrl ? getXtreamLiveProtocolPair(fallbackUrl) : null);

  if (xtreamPair) {
    if (preferredEngine === 'mpegts') {
      // Strictly use continuous .ts on Xtream live streams when MSE mpegts is active:
      // touching .m3u8 even once on a max_connections=1 Xtream panel creates a 60s HLS Redis lock!
      const list = new Set<string>([xtreamPair.tsUrl]);
      for (const candidate of [primaryUrl, fallbackUrl]) {
        if (!candidate) continue;
        const candPair = getXtreamLiveProtocolPair(candidate);
        if (candPair) {
          list.add(candPair.tsUrl);
        } else if (!candidate.toLowerCase().split('?')[0].endsWith('.m3u8')) {
          list.add(candidate);
        }
      }
      return Array.from(list);
    }
    if (preferredEngine === 'hls') {
      return [xtreamPair.hlsUrl, xtreamPair.tsUrl];
    }
  }

  const set = new Set<string>();
  const derived = deriveStreamFallbackUrl(primaryUrl);
  const all = [primaryUrl, fallbackUrl, derived].filter((v): v is string => Boolean(v && v.trim()));

  const isHlsUrl = (u: string) => u.toLowerCase().split('?')[0].endsWith('.m3u8');

  if (preferredEngine === 'hls') {
    const hlsOnes = all.filter(isHlsUrl);
    const otherOnes = all.filter((u) => !isHlsUrl(u));
    for (const u of [...hlsOnes, ...otherOnes]) set.add(u);
  } else if (preferredEngine === 'mpegts') {
    const tsOnes = all.filter((u) => !isHlsUrl(u));
    if (tsOnes.length > 0) {
      for (const u of tsOnes) set.add(u);
    } else {
      for (const u of all) set.add(u);
    }
  } else {
    for (const u of all) set.add(u);
  }

  return Array.from(set);
}

export function detectContentKind(url: string, groupTitle: string): ContentKind {
  const lowerUrl = url.toLowerCase();
  const lowerGroup = groupTitle.toLowerCase();
  if (
    lowerUrl.includes('/series/') ||
    lowerGroup.includes('series') ||
    lowerGroup.includes('مسلسل')
  ) {
    return 'series';
  }
  if (
    lowerUrl.includes('/movie/') ||
    lowerUrl.endsWith('.mp4') ||
    lowerUrl.endsWith('.mkv') ||
    lowerGroup.includes('movie') ||
    lowerGroup.includes('vod') ||
    lowerGroup.includes('أفلام') ||
    lowerGroup.includes('افلام')
  ) {
    return 'movie';
  }
  return 'live';
}

function extractAttribute(extinfLine: string, attrName: string): string {
  const quotedRegex = new RegExp(`${attrName}\\s*=\\s*"([^"]*)"`, 'i');
  const quotedMatch = extinfLine.match(quotedRegex);
  if (quotedMatch && quotedMatch[1] !== undefined) {
    return quotedMatch[1].trim();
  }
  const singleQuotedRegex = new RegExp(`${attrName}\\s*=\\s*'([^']*)'`, 'i');
  const singleMatch = extinfLine.match(singleQuotedRegex);
  if (singleMatch && singleMatch[1] !== undefined) {
    return singleMatch[1].trim();
  }
  const unquotedRegex = new RegExp(`${attrName}\\s*=\\s*([^\\s,"']+)`, 'i');
  const unquotedMatch = extinfLine.match(unquotedRegex);
  if (unquotedMatch && unquotedMatch[1] !== undefined) {
    return unquotedMatch[1].trim();
  }
  return '';
}

function extractDisplayName(extinfLine: string): string {
  let inQuotes = false;
  let quoteChar = '';
  let lastCommaIndex = -1;

  for (let i = 0; i < extinfLine.length; i++) {
    const ch = extinfLine[i];
    if ((ch === '"' || ch === "'") && (i === 0 || extinfLine[i - 1] !== '\\')) {
      if (!inQuotes) {
        inQuotes = true;
        quoteChar = ch;
      } else if (ch === quoteChar) {
        inQuotes = false;
      }
    } else if (ch === ',' && !inQuotes) {
      lastCommaIndex = i;
    }
  }

  if (lastCommaIndex !== -1) {
    return extinfLine.slice(lastCommaIndex + 1).trim();
  }
  return '';
}

/**
 * Parses an M3U / M3U_PLUS playlist string while strictly preserving the exact
 * group-title names and exact category & channel order from the source file.
 */
export function parseM3uPlaylist(rawText: string): ParsedPlaylistResult {
  const cleaned = rawText.replace(/^\uFEFF/, '');
  const lines = cleaned.split(/\r?\n/);

  const channels: ParsedChannelInput[] = [];
  const groupsSet = new Set<string>();
  const groupsInOrder: string[] = [];

  let pendingName = '';
  let pendingGroup = '';
  let pendingLogo = '';
  let pendingUserAgent = '';
  let pendingReferrer = '';
  let hasExtinf = false;

  const registerGroup = (grp: string) => {
    const normalized = grp.trim() || 'قنوات عامة';
    if (!groupsSet.has(normalized)) {
      groupsSet.add(normalized);
      groupsInOrder.push(normalized);
    }
    return normalized;
  };

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i].trim();
    if (!line) continue;

    if (line.startsWith('#EXTM3U')) {
      continue;
    }

    if (line.startsWith('#EXTINF')) {
      hasExtinf = true;
      const tvgName = extractAttribute(line, 'tvg-name');
      const displayName = extractDisplayName(line);
      pendingName = displayName || tvgName || `قناة ${channels.length + 1}`;
      pendingLogo = extractAttribute(line, 'tvg-logo') || extractAttribute(line, 'logo');
      const groupTitle =
        extractAttribute(line, 'group-title') ||
        extractAttribute(line, 'pltv-subgroup') ||
        '';
      if (groupTitle) {
        pendingGroup = groupTitle;
      }
      const inlineUa =
        extractAttribute(line, 'user-agent') || extractAttribute(line, 'http-user-agent');
      if (inlineUa) pendingUserAgent = inlineUa;
      continue;
    }

    if (line.startsWith('#EXTGRP:')) {
      const grp = line.slice('#EXTGRP:'.length).trim();
      if (grp && !pendingGroup) {
        pendingGroup = grp;
      }
      continue;
    }

    if (line.startsWith('#EXTVLCOPT:')) {
      const opt = line.slice('#EXTVLCOPT:'.length).trim();
      if (opt.toLowerCase().startsWith('http-user-agent=')) {
        pendingUserAgent = opt.slice('http-user-agent='.length).trim();
      } else if (opt.toLowerCase().startsWith('http-referrer=')) {
        pendingReferrer = opt.slice('http-referrer='.length).trim();
      }
      continue;
    }

    if (line.startsWith('#KODIPROP:')) {
      const prop = line.slice('#KODIPROP:'.length).trim();
      if (prop.toLowerCase().includes('user-agent=')) {
        const idx = prop.toLowerCase().indexOf('user-agent=');
        pendingUserAgent = prop.slice(idx + 'user-agent='.length).trim();
      }
      continue;
    }

    if (line.startsWith('#')) {
      continue;
    }

    // Stream URL line
    const cleanedStreamLine = line.replace(/[\u200B-\u200F\u202A-\u202E\u2060-\u206F]/g, '').trim();
    if (
      /^https?:\/\//i.test(cleanedStreamLine) ||
      cleanedStreamLine.startsWith('rtmp://') ||
      cleanedStreamLine.startsWith('mms://')
    ) {
      let streamUrl = cleanedStreamLine;
      if (cleanedStreamLine.includes('|')) {
        const [basePart, headerPart] = cleanedStreamLine.split('|', 2);
        streamUrl = basePart.trim();
        if (headerPart) {
          const params = new URLSearchParams(headerPart);
          const ua = params.get('User-Agent') || params.get('user-agent');
          const ref = params.get('Referer') || params.get('referer');
          if (ua) pendingUserAgent = ua;
          if (ref) pendingReferrer = ref;
        }
      }

      const finalName = hasExtinf
        ? pendingName
        : decodeURIComponent(
            streamUrl.split('/').pop()?.split('?')[0] || `قناة ${channels.length + 1}`
          );
      const finalGroup = registerGroup(pendingGroup || 'قنوات عامة');
      const yearMatch = finalName.match(/\((\d{4})\)|\b(19\d{2}|20\d{2})\b/);

      channels.push({
        signature: computeStreamSignature(streamUrl, finalName),
        name: finalName,
        group: finalGroup,
        logo: pendingLogo,
        streamUrl,
        fallbackStreamUrl: deriveStreamFallbackUrl(streamUrl),
        streamFormat: detectStreamFormat(streamUrl),
        contentType: detectContentKind(streamUrl, finalGroup),
        userAgent: pendingUserAgent || undefined,
        referrer: pendingReferrer || undefined,
        year: yearMatch ? yearMatch[1] || yearMatch[2] : undefined,
        order: channels.length,
      });

      pendingName = '';
      pendingGroup = '';
      pendingLogo = '';
      pendingUserAgent = '';
      pendingReferrer = '';
      hasExtinf = false;
    }
  }

  return { channels, groupsInOrder };
}

/**
 * Extracts Xtream credentials if the user pasted an Xtream M3U URL
 * (e.g. /get.php?username=X&password=Y or /playlist/X/Y/m3u_plus)
 * so we can automatically fall back to player_api.php when /get.php returns 404!
 */
function extractXtreamCredentialsFromUrl(
  rawUrl: string
): { host: string; username: string; password: string } | null {
  try {
    const u = new URL(rawUrl);
    const host = `${u.protocol}//${u.host}`;
    const qUser = u.searchParams.get('username') || u.searchParams.get('user');
    const qPass = u.searchParams.get('password') || u.searchParams.get('pass');
    if (qUser && qPass) {
      return { host, username: qUser, password: qPass };
    }

    // Check /playlist/USER/PASS/... or /live/USER/PASS/... or /USER/PASS patterns
    const pathParts = u.pathname.split('/').filter(Boolean);
    if (
      (pathParts[0]?.toLowerCase() === 'playlist' || pathParts[0]?.toLowerCase() === 'live') &&
      pathParts.length >= 3
    ) {
      return {
        host,
        username: decodeURIComponent(pathParts[1]),
        password: decodeURIComponent(pathParts[2]),
      };
    }
    if (
      pathParts.length === 2 &&
      !pathParts[1].toLowerCase().endsWith('.m3u') &&
      !pathParts[1].toLowerCase().endsWith('.m3u8') &&
      !pathParts[1].toLowerCase().endsWith('.php')
    ) {
      return {
        host,
        username: decodeURIComponent(pathParts[0]),
        password: decodeURIComponent(pathParts[1]),
      };
    }
  } catch {
    // ignore
  }
  return null;
}

export async function fetchM3uFromUrl(rawInputUrl: string): Promise<ParsedPlaylistResult> {
  const cleanedUrl = cleanIptvUrl(rawInputUrl);

  let parsedCheck: URL;
  try {
    parsedCheck = new URL(cleanedUrl);
  } catch {
    throw new Error('صيغة الرابط غير صحيحة. تأكد من نسخ رابط M3U كاملاً.');
  }

  // Warn clearly if user pasted only a bare domain without path/query
  if ((parsedCheck.pathname === '/' || parsedCheck.pathname === '') && !parsedCheck.search) {
    throw new Error(
      'الرابط الذي أدخلته يحتوي على عنوان السيرفر فقط بدون مسار ملف M3U. إذا كان لديك هوست ويوزر وباسورد، استخدم تبويب "إضافة Xtream".'
    );
  }

  let lastStatus = 0;
  let lastErrorMsg = '';

  const tryParseM3uResponse = (body: string, sourceUrl: string): ParsedPlaylistResult | null => {
    if (!body.trim()) return null;
    if (body.includes('#EXT-X-STREAM-INF') || body.includes('#EXT-X-TARGETDURATION')) {
      let pathPart = '';
      try {
        pathPart = new URL(sourceUrl).pathname;
      } catch {
        pathPart = sourceUrl;
      }
      const singleName =
        decodeURIComponent(pathPart.split('/').pop()?.replace(/\.m3u8$/i, '') || '') ||
        'قناة بث مباشر';
      return {
        channels: [
          {
            signature: computeStreamSignature(sourceUrl, singleName),
            name: singleName,
            group: 'بث مباشر',
            logo: '',
            streamUrl: sourceUrl,
            streamFormat: 'hls',
            contentType: 'live',
            order: 0,
          },
        ],
        groupsInOrder: ['بث مباشر'],
      };
    }

    const parsed = parseM3uPlaylist(body);
    return parsed.channels.length > 0 ? parsed : null;
  };

  for (const ua of USER_AGENT_PROFILES) {
    try {
      const res = await requestTextResilient(cleanedUrl, ua, 25000);
      lastStatus = res.statusCode;

      if (res.statusCode >= 200 && res.statusCode < 300) {
        const parsed = tryParseM3uResponse(res.body, cleanedUrl);
        if (parsed) return parsed;
      }
    } catch (err: any) {
      lastErrorMsg = err?.message || '';
    }
  }

  // Automatic Xtream Multi-Endpoint & API Fallback when /get.php or /playlist/ returns 404!
  const xtreamCreds = extractXtreamCredentialsFromUrl(cleanedUrl);
  if (xtreamCreds) {
    const encUser = encodeURIComponent(xtreamCreds.username);
    const encPass = encodeURIComponent(xtreamCreds.password);
    const altM3uUrls = [
      `${xtreamCreds.host}/playlist/${encUser}/${encPass}/m3u_plus`,
      `${xtreamCreds.host}/get.php?username=${encUser}&password=${encPass}&type=m3u_plus&output=ts`,
    ].filter((u) => u !== cleanedUrl);

    for (const altUrl of altM3uUrls) {
      try {
        const res = await requestTextResilient(altUrl, USER_AGENT_PROFILES[0], 20000);
        if (res.statusCode >= 200 && res.statusCode < 300) {
          const parsed = tryParseM3uResponse(res.body, altUrl);
          if (parsed) return parsed;
        }
      } catch {
        // continue to player_api.php fallback
      }
    }

    try {
      const xtreamResult = await fetchXtreamPlaylist(
        xtreamCreds.host,
        xtreamCreds.username,
        xtreamCreds.password,
        { includeLive: true, includeVod: true }
      );
      if (xtreamResult.channels.length > 0) {
        return {
          channels: xtreamResult.channels,
          groupsInOrder: xtreamResult.groupsInOrder,
        };
      }
    } catch {
      // fall through to detailed error message below
    }
  }

  if (lastStatus === 404) {
    throw new Error(
      'السيرفر أعاد (HTTP 404 - الملف غير موجود): تأكد من اكتمال رابط M3U وصلاحيته، أو إذا كان السيرفر مقيداً بدولتك/جهازك يمكنك رفع ملف .m3u أو لصق محتواه النصي مباشرة بالأسفل.'
    );
  }
  if (lastStatus === 401 || lastStatus === 403) {
    throw new Error(
      `رفض السيرفر الاتصال (HTTP ${lastStatus}): قد يكون الاشتراك منتهياً أو مقيداً بجهاز/دولة معينة. يمكنك رفع ملف .m3u أو لصق محتواه النصي بالأسفل.`
    );
  }
  if (lastStatus > 0) {
    throw new Error(`فشل جلب ملف M3U (HTTP ${lastStatus})`);
  }

  throw new Error(lastErrorMsg || 'تعذر الوصول إلى رابط M3U، تحقق من صحة الرابط واتصالك.');
}

function normalizeXtreamHost(host: string): string {
  return cleanIptvUrl(host).replace(/\/+$/, '');
}

async function fetchJsonWithTimeout(url: string, timeoutMs = 25000): Promise<any> {
  let lastErr: Error | null = null;
  for (const ua of USER_AGENT_PROFILES.slice(0, 3)) {
    try {
      const res = await requestTextResilient(url, ua, timeoutMs);
      if (res.statusCode >= 200 && res.statusCode < 300 && res.body.trim()) {
        return JSON.parse(res.body);
      }
      lastErr = new Error(`استجابة غير صالحة من خادم Xtream (HTTP ${res.statusCode})`);
    } catch (err: any) {
      lastErr = err instanceof Error ? err : new Error(String(err));
    }
  }
  throw lastErr || new Error('تعذر الاتصال بخادم Xtream.');
}

export async function fetchXtreamPlaylist(
  host: string,
  username: string,
  password: string,
  options: { includeLive?: boolean; includeVod?: boolean; includeSeries?: boolean } = {
    includeLive: true,
    includeVod: true,
    includeSeries: false,
  }
): Promise<XtreamSyncResult> {
  const baseUrl = normalizeXtreamHost(host);
  const cleanUser = username.replace(/[\u200B-\u200F\u202A-\u202E\u2060-\u206F\uFEFF]/g, '').trim();
  const cleanPass = password.replace(/[\u200B-\u200F\u202A-\u202E\u2060-\u206F\uFEFF]/g, '').trim();
  const encUser = encodeURIComponent(cleanUser);
  const encPass = encodeURIComponent(cleanPass);
  const apiBase = `${baseUrl}/player_api.php?username=${encUser}&password=${encPass}`;

  const authData = await fetchJsonWithTimeout(apiBase, 22000);
  if (!authData || !authData.user_info || Number(authData.user_info.auth) === 0) {
    throw new Error('بيانات دخول Xtream غير صحيحة أو الحساب منتهي الصلاحية.');
  }

  const userInfo = authData.user_info;
  const accountInfo: XtreamAccountInfo = {
    status: String(userInfo.status || 'Active'),
    expDate: userInfo.exp_date ? String(userInfo.exp_date) : null,
    maxConnections: String(userInfo.max_connections || '1'),
    activeCons: String(userInfo.active_cons || '0'),
  };

  const channels: ParsedChannelInput[] = [];
  const groupsSet = new Set<string>();
  const groupsInOrder: string[] = [];

  const registerGroup = (name: string): string => {
    const clean = (name || '').trim() || 'قنوات عامة';
    if (!groupsSet.has(clean)) {
      groupsSet.add(clean);
      groupsInOrder.push(clean);
    }
    return clean;
  };

  if (options.includeLive !== false) {
    const [liveCategories, liveStreams] = await Promise.all([
      fetchJsonWithTimeout(`${apiBase}&action=get_live_categories`).catch(() => []),
      fetchJsonWithTimeout(`${apiBase}&action=get_live_streams`).catch(() => []),
    ]);

    const catMap = new Map<string, string>();
    if (Array.isArray(liveCategories)) {
      for (const cat of liveCategories) {
        if (cat && cat.category_id !== undefined) {
          const catName = registerGroup(String(cat.category_name || 'قنوات مباشرة'));
          catMap.set(String(cat.category_id), catName);
        }
      }
    }

    if (Array.isArray(liveStreams)) {
      for (const item of liveStreams) {
        if (!item || item.stream_id === undefined) continue;
        const streamId = String(item.stream_id);
        const name = String(item.name || `قناة ${streamId}`).trim();
        const groupName = catMap.get(String(item.category_id)) || registerGroup('قنوات مباشرة');
        const hlsUrl = `${baseUrl}/live/${encUser}/${encPass}/${streamId}.m3u8`;
        const tsUrl = `${baseUrl}/live/${encUser}/${encPass}/${streamId}.ts`;

        channels.push({
          signature: computeStreamSignature(hlsUrl, name),
          name,
          group: groupName,
          logo: String(item.stream_icon || '').trim(),
          streamUrl: tsUrl,
          fallbackStreamUrl: hlsUrl,
          streamFormat: 'mpegts',
          contentType: 'live',
          order: channels.length,
        });
      }
    }
  }

  if (options.includeVod) {
    const [vodCategories, vodStreams] = await Promise.all([
      fetchJsonWithTimeout(`${apiBase}&action=get_vod_categories`).catch(() => []),
      fetchJsonWithTimeout(`${apiBase}&action=get_vod_streams`).catch(() => []),
    ]);

    const vodCatMap = new Map<string, string>();
    if (Array.isArray(vodCategories)) {
      for (const cat of vodCategories) {
        if (cat && cat.category_id !== undefined) {
          const catName = registerGroup(String(cat.category_name || 'الأفلام'));
          vodCatMap.set(String(cat.category_id), catName);
        }
      }
    }

    if (Array.isArray(vodStreams)) {
      const limit = Math.min(vodStreams.length, 4000);
      for (let i = 0; i < limit; i++) {
        const item = vodStreams[i];
        if (!item || item.stream_id === undefined) continue;
        const streamId = String(item.stream_id);
        const ext = String(item.container_extension || 'mp4').replace(/^\./, '');
        const name = String(item.name || `فيلم ${streamId}`).trim();
        const groupName = vodCatMap.get(String(item.category_id)) || registerGroup('الأفلام');
        const vodUrl = `${baseUrl}/movie/${encUser}/${encPass}/${streamId}.${ext}`;
        const yearMatch = name.match(/\((\d{4})\)|\b(19\d{2}|20\d{2})\b/);

        channels.push({
          signature: computeStreamSignature(vodUrl, name),
          name,
          group: groupName,
          logo: String(item.stream_icon || '').trim(),
          streamUrl: vodUrl,
          streamFormat: ext === 'm3u8' ? 'hls' : 'mp4',
          contentType: 'movie',
          year: yearMatch ? yearMatch[1] || yearMatch[2] : undefined,
          order: channels.length,
        });
      }
    }
  }

  if (channels.length === 0) {
    throw new Error('تم الاتصال بخادم Xtream بنجاح ولكن لم يتم العثور على قنوات متاحة.');
  }

  return { channels, groupsInOrder, accountInfo };
}
