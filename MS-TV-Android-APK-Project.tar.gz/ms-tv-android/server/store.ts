import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import zlib from 'node:zlib';
import type { ContentKind, ParsedChannelInput, StreamFormat, XtreamAccountInfo } from './m3uParser.ts';
import {
  computeStreamSignature,
  deriveStreamFallbackUrl,
  getXtreamLiveProtocolPair,
  isSeparatorBannerName,
} from './m3uParser.ts';

export type SourceType = 'm3u_url' | 'm3u_text' | 'xtream' | 'direct' | 'starter';

export interface IptvSource {
  id: string;
  name: string;
  type: SourceType;
  /** Secret fields — ONLY exposed to Admin API */
  m3uUrl?: string;
  xtreamHost?: string;
  xtreamUsername?: string;
  xtreamPassword?: string;
  includeVod?: boolean;
  accountInfo?: XtreamAccountInfo;
  channelCount: number;
  groupsInOrder: string[];
  createdAt: string;
  lastSyncedAt: string;
}

export interface StoredChannel {
  id: string;
  sourceId: string;
  signature: string;
  name: string;
  originalName: string;
  group: string;
  originalGroup: string;
  logo: string;
  /** Secret stream URLs — NEVER exposed to regular users */
  streamUrl: string;
  fallbackStreamUrl?: string;
  streamFormat: StreamFormat;
  contentType: ContentKind;
  userAgent?: string;
  referrer?: string;
  year?: string;
  featured: boolean;
  views: number;
  order: number;
  addedAt: string;
}

export interface ChannelOverride {
  customName?: string;
  customGroup?: string;
  customLogo?: string;
  featured?: boolean;
  hidden?: boolean;
}

export interface CustomPlaylist {
  id: string;
  name: string;
  color: string;
  channelIds: string[];
  isGlobal: boolean;
  ownerCode?: string;
  createdAt: string;
}

export interface BoundDeviceInfo {
  deviceId: string;
  deviceName: string;
  ip: string;
  firstSeenAt: string;
  lastSeenAt: string;
}

export interface ViewerAccessCode {
  id: string;
  code: string;
  label: string;
  durationDays: number;
  /** Explicit ISO timestamp when this subscription expires */
  expiresAt: string;
  createdAt: string;
  active: boolean;
  /** Maximum number of distinct devices/people allowed on this code (1 = single person, N = custom multi-person) */
  maxDevices: number;
  boundDevices: BoundDeviceInfo[];
  notes?: string;
}

export interface SecurityPolicyConfig {
  /** Blocks HttpCanary, Reqable, Packet Capture, MITM proxies, external players (VLC/FFmpeg/scrapers), and client fetch hooks */
  blockSniffers: boolean;
  /** Blocks VPNs, proxies, Tor, datacenter tunnels, and proxy headers */
  blockVpn: boolean;
  /** Blocks browser DevTools, network inspector shortcuts, context menu, and debugger tampering */
  blockDevTools: boolean;
  /** Enforces short-lived heartbeat-leased stream tickets cryptographically bound to deviceId + UA + IP subnet */
  strictStreamBinding: boolean;
}

export type SecurityEventType =
  | 'sniffer_blocked'
  | 'vpn_blocked'
  | 'device_limit'
  | 'devtools_tamper';

export interface SecurityAuditEvent {
  id: string;
  type: SecurityEventType;
  reason: string;
  ip: string;
  deviceName: string;
  subscriberCode?: string;
  userAgent?: string;
  createdAt: string;
}

export type HeroActionType = 'watch_channel' | 'external_url' | 'category' | 'none';
export type HeroThemePreset = 'default' | 'telegram' | 'promo';

export interface HeroSlide {
  id: string;
  title: string;
  subtitle: string;
  badge: string;
  imageUrl: string;
  actionType?: HeroActionType;
  buttonText?: string;
  externalUrl?: string;
  channelId?: string;
  targetCategory?: string;
  showLiveBadge?: boolean;
  themePreset?: HeroThemePreset;
  order: number;
  active: boolean;
}

export const DEFAULT_MAINTENANCE_MESSAGE = 'التطبيق في وضع الصيانة يرجى المحاولة لاحقاً';

export interface DatabaseSchema {
  adminCode: string;
  serverSecret: string;
  isInitialSetup: boolean;
  hideAdminEntryForUsers: boolean;
  telegramCodeUrl: string;
  apkServerUrl: string;
  apkDownloadUrl: string;
  maintenanceMode: boolean;
  maintenanceMessage: string;
  excludedCategories: string[];
  accessCodes: ViewerAccessCode[];
  sources: IptvSource[];
  channels: StoredChannel[];
  channelOverrides: Record<string, ChannelOverride>;
  customCategories: string[];
  categoryOrder: string[];
  categoryLogos: Record<string, string>;
  heroSlides: HeroSlide[];
  customLists: CustomPlaylist[];
  favoritesByCode: Record<string, string[]>;
  historyByCode: Record<string, string[]>;
  securityPolicy: SecurityPolicyConfig;
  securityEvents: SecurityAuditEvent[];
}

const SERVER_DIR = path.resolve(process.cwd(), 'server');
const PRIMARY_DB_PATH = path.join(SERVER_DIR, 'ms-tv-db.json');
const LEGACY_DATA_DIR = path.resolve(process.cwd(), 'data');
const LEGACY_DB_PATH = path.join(LEGACY_DATA_DIR, 'iptv-store.json');

function getDeterministicVaultKey(): Buffer {
  const material = process.env.APP_URL || 'mstv-enterprise-vault-98225f82';
  return crypto.scryptSync(material, 'mstv-vault-salt-98225f82', 32);
}

export function computeDaysRemaining(expiresAt?: string): number {
  if (!expiresAt) return 365;
  const ms = Date.parse(expiresAt) - Date.now();
  if (Number.isNaN(ms)) return 365;
  if (ms <= 0) return 0;
  return Math.max(1, Math.ceil(ms / 86400000));
}

export function isAccessCodeValidNow(ac: ViewerAccessCode): boolean {
  if (!ac.active) return false;
  if (!ac.expiresAt) return true;
  const expMs = Date.parse(ac.expiresAt);
  if (Number.isNaN(expMs)) return true;
  return expMs > Date.now();
}

function createDefaultHeroSlides(channels: StoredChannel[]): HeroSlide[] {
  const firstSport = channels[0];
  const secondCh = channels[1] || channels[0];
  return [
    {
      id: 'hero_default_1',
      title: 'دوري أبطال أوروبا وأقوى البطولات',
      subtitle: 'مشاهدة فورية بأعلى جودة وبث مستقر بدون تقطيع على MS TV',
      badge: 'بث مباشر HD',
      imageUrl: '',
      channelId: firstSport?.id,
      order: 0,
      active: true,
    },
    {
      id: 'hero_default_2',
      title: 'باقة القنوات العربية والعالمية',
      subtitle: 'تصفح جميع الأقسام والأفلام والمسلسلات في مكان واحد',
      badge: 'MS TV VIP',
      imageUrl: '',
      channelId: secondCh?.id,
      order: 1,
      active: true,
    },
  ];
}

function createStarterState(): DatabaseSchema {
  const now = new Date().toISOString();
  const oneYearLater = new Date(Date.now() + 365 * 86400000).toISOString();
  const starterSourceId = 'src_starter_fta';

  const starterItems: Array<{
    name: string;
    group: string;
    logo: string;
    streamUrl: string;
    contentType: ContentKind;
    featured?: boolean;
    views: number;
    year?: string;
  }> = [
    {
      name: 'Red Bull TV Sports HD',
      group: 'الرياضة',
      logo: '',
      streamUrl: 'https://rbmn-live.akamaized.net/hls/live/590964/BoRB-AT/master.m3u8',
      contentType: 'live',
      featured: true,
      views: 1420,
    },
    {
      name: 'Al Jazeera الجزيرة مباشر',
      group: 'الأخبار العربية',
      logo: '',
      streamUrl: 'https://live-hls-web-aja.getaj.net/AJA/index.m3u8',
      contentType: 'live',
      featured: true,
      views: 1290,
    },
    {
      name: 'Sky News Arabia سكاي نيوز',
      group: 'الأخبار العربية',
      logo: '',
      streamUrl: 'https://stream.skynewsarabia.com/hls/sna.m3u8',
      contentType: 'live',
      featured: true,
      views: 980,
    },
    {
      name: 'France 24 العربية HD',
      group: 'الأخبار العربية',
      logo: '',
      streamUrl: 'https://live.france24.com/hls/live/2037222-b/F24_AR_HI_HLS/master_5000.m3u8',
      contentType: 'live',
      featured: true,
      views: 840,
    },
    {
      name: 'DW عربية HD',
      group: 'الأخبار العربية',
      logo: '',
      streamUrl: 'https://dwamdstream103.akamaized.net/hls/live/2015526/dwstream103/index.m3u8',
      contentType: 'live',
      featured: true,
      views: 760,
    },
    {
      name: 'TRT عربي HD',
      group: 'الترفيه',
      logo: '',
      streamUrl: 'https://tv-trtarabi.medya.trt.com.tr/master.m3u8',
      contentType: 'live',
      featured: true,
      views: 710,
    },
    {
      name: 'NASA TV UHD الفضائية',
      group: 'الوثائقية',
      logo: '',
      streamUrl: 'https://ntv1.akamaized.net/hls/live/2014075/NASA-NTV1-HLS/master.m3u8',
      contentType: 'live',
      featured: true,
      views: 650,
    },
    {
      name: 'Tears of Steel Sci-Fi 4K',
      group: 'الأفلام',
      logo: '',
      streamUrl: 'https://demo.unified-streaming.com/k8s/features/stable/video/tears-of-steel/tears-of-steel.ism/.m3u8',
      contentType: 'movie',
      featured: false,
      views: 590,
      year: '2024',
    },
    {
      name: 'Sintel المغامرة الأسطورية',
      group: 'الأفلام',
      logo: '',
      streamUrl: 'https://bitdash-a.akamaihd.net/content/sintel/hls/playlist.m3u8',
      contentType: 'movie',
      featured: false,
      views: 540,
      year: '2023',
    },
    {
      name: 'Big Buck Bunny كرتون',
      group: 'الأطفال',
      logo: '',
      streamUrl: 'https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8',
      contentType: 'movie',
      featured: true,
      views: 890,
      year: '2022',
    },
    {
      name: 'Cosmos Laundromat خيال علمي',
      group: 'المسلسلات',
      logo: '',
      streamUrl: 'https://devstreaming-cdn.apple.com/videos/streaming/examples/img_bipbop_adv_example_fmp4/master.m3u8',
      contentType: 'series',
      featured: false,
      views: 430,
      year: '2024',
    },
    {
      name: 'Adventure Action Arena HD',
      group: 'الرياضة',
      logo: '',
      streamUrl: 'https://cph-p2p-msl.akamaized.net/hls/live/2000341/test/master.m3u8',
      contentType: 'live',
      featured: false,
      views: 620,
    },
  ];

  const groupsInOrder: string[] = [];
  const channels: StoredChannel[] = starterItems.map((item, idx) => {
    if (!groupsInOrder.includes(item.group)) {
      groupsInOrder.push(item.group);
    }
    const sig = computeStreamSignature(item.streamUrl, item.name);
    return {
      id: `ch_${sig}`,
      sourceId: starterSourceId,
      signature: sig,
      name: item.name,
      originalName: item.name,
      group: item.group,
      originalGroup: item.group,
      logo: item.logo,
      streamUrl: item.streamUrl,
      streamFormat: 'hls',
      contentType: item.contentType,
      year: item.year,
      featured: Boolean(item.featured),
      views: item.views,
      order: idx,
      addedAt: now,
    };
  });

  return {
    adminCode: '9999',
    serverSecret: crypto
      .createHmac('sha256', getDeterministicVaultKey())
      .update('mstv-server-secret-v1')
      .digest('hex'),
    isInitialSetup: true,
    hideAdminEntryForUsers: true,
    telegramCodeUrl: '',
    apkServerUrl: '',
    apkDownloadUrl: '',
    maintenanceMode: false,
    maintenanceMessage: DEFAULT_MAINTENANCE_MESSAGE,
    excludedCategories: [],
    accessCodes: [
      {
        id: 'code_default_1',
        code: '1111',
        label: 'كود المشتركين الرئيسي',
        durationDays: 365,
        expiresAt: oneYearLater,
        createdAt: now,
        active: true,
        maxDevices: 1,
        boundDevices: [],
      },
    ],
    sources: [
      {
        id: starterSourceId,
        name: 'باقة البث المفتوحة التجريبية (تختفي تلقائياً فور إضافة باقتك)',
        type: 'starter',
        channelCount: channels.length,
        groupsInOrder,
        createdAt: now,
        lastSyncedAt: now,
      },
    ],
    channels,
    channelOverrides: {},
    customCategories: [],
    categoryOrder: [...groupsInOrder],
    categoryLogos: {},
    heroSlides: createDefaultHeroSlides(channels),
    customLists: [
      {
        id: 'list_featured_vip',
        name: 'باقة السهرة المميزة',
        color: '#2563EB',
        channelIds: channels.slice(0, 5).map((c) => c.id),
        isGlobal: true,
        createdAt: now,
      },
    ],
    favoritesByCode: {},
    historyByCode: {},
    securityPolicy: {
      blockSniffers: true,
      blockVpn: true,
      blockDevTools: true,
      strictStreamBinding: true,
    },
    securityEvents: [],
  };
}

function normalizeLoadedDb(raw: Partial<DatabaseSchema>): DatabaseSchema {
  const fallback = createStarterState();
  const channels = Array.isArray(raw.channels)
    ? raw.channels.map((ch) => {
        const xtreamPair =
          ch.contentType === 'live' ? getXtreamLiveProtocolPair(ch.streamUrl) : null;
        return {
          ...ch,
          fallbackStreamUrl:
            ch.fallbackStreamUrl ||
            (xtreamPair
              ? ch.streamUrl.toLowerCase().split('?')[0].endsWith('.ts')
                ? xtreamPair.hlsUrl
                : xtreamPair.tsUrl
              : deriveStreamFallbackUrl(ch.streamUrl)),
          streamFormat: xtreamPair ? ('mpegts' as const) : ch.streamFormat,
        };
      })
    : fallback.channels;

  const accessCodes = Array.isArray(raw.accessCodes)
    ? raw.accessCodes.map((ac) => {
        const createdMs = Date.parse(ac.createdAt || '') || Date.now();
        const durDays = Math.max(1, Number(ac.durationDays) || 365);
        const computedExp = new Date(createdMs + durDays * 86400000).toISOString();
        const maxDevices = Math.min(1000, Math.max(1, Math.floor(Number(ac.maxDevices) || 1)));
        const boundDevices: BoundDeviceInfo[] = Array.isArray(ac.boundDevices)
          ? ac.boundDevices
              .filter((d) => d && typeof d.deviceId === 'string' && d.deviceId.trim().length > 0)
              .map((d) => ({
                deviceId: String(d.deviceId).trim().slice(0, 96),
                deviceName: String(d.deviceName || 'جهاز متصل').trim().slice(0, 80),
                ip: String(d.ip || '').trim().slice(0, 64),
                firstSeenAt: d.firstSeenAt || new Date().toISOString(),
                lastSeenAt: d.lastSeenAt || new Date().toISOString(),
              }))
          : [];
        return {
          ...ac,
          durationDays: durDays,
          expiresAt: ac.expiresAt || computedExp,
          active: ac.active ?? true,
          maxDevices,
          boundDevices,
        };
      })
    : fallback.accessCodes;

  const heroSlides = Array.isArray(raw.heroSlides)
    ? raw.heroSlides
    : createDefaultHeroSlides(channels);

  const rawPolicy = (raw.securityPolicy || {}) as Partial<SecurityPolicyConfig>;
  const securityPolicy: SecurityPolicyConfig = {
    blockSniffers:
      typeof rawPolicy.blockSniffers === 'boolean'
        ? rawPolicy.blockSniffers
        : fallback.securityPolicy.blockSniffers,
    blockVpn:
      typeof rawPolicy.blockVpn === 'boolean'
        ? rawPolicy.blockVpn
        : fallback.securityPolicy.blockVpn,
    blockDevTools:
      typeof rawPolicy.blockDevTools === 'boolean'
        ? rawPolicy.blockDevTools
        : fallback.securityPolicy.blockDevTools,
    strictStreamBinding:
      typeof rawPolicy.strictStreamBinding === 'boolean'
        ? rawPolicy.strictStreamBinding
        : fallback.securityPolicy.strictStreamBinding,
  };

  const securityEvents: SecurityAuditEvent[] = Array.isArray(raw.securityEvents)
    ? raw.securityEvents.slice(0, 80)
    : [];

  const excludedCategories = Array.isArray(raw.excludedCategories)
    ? Array.from(
        new Set(
          raw.excludedCategories
            .map((c) => String(c || '').trim())
            .filter((c) => c.length > 0)
        )
      )
    : [];

  return {
    adminCode: raw.adminCode || fallback.adminCode,
    serverSecret: raw.serverSecret || fallback.serverSecret,
    isInitialSetup: raw.isInitialSetup ?? false,
    hideAdminEntryForUsers: raw.hideAdminEntryForUsers ?? true,
    telegramCodeUrl: typeof raw.telegramCodeUrl === 'string' ? raw.telegramCodeUrl.trim() : '',
    apkServerUrl: typeof raw.apkServerUrl === 'string' ? raw.apkServerUrl.trim() : '',
    apkDownloadUrl: typeof raw.apkDownloadUrl === 'string' ? raw.apkDownloadUrl.trim() : '',
    maintenanceMode: Boolean(raw.maintenanceMode),
    maintenanceMessage:
      typeof raw.maintenanceMessage === 'string' && raw.maintenanceMessage.trim()
        ? raw.maintenanceMessage.trim()
        : DEFAULT_MAINTENANCE_MESSAGE,
    excludedCategories,
    accessCodes,
    sources: Array.isArray(raw.sources) ? raw.sources : fallback.sources,
    channels,
    channelOverrides: raw.channelOverrides || {},
    customCategories: Array.isArray(raw.customCategories) ? raw.customCategories : [],
    categoryOrder: Array.isArray(raw.categoryOrder) ? raw.categoryOrder : [],
    categoryLogos:
      raw.categoryLogos && typeof raw.categoryLogos === 'object' ? raw.categoryLogos : {},
    heroSlides,
    customLists: Array.isArray(raw.customLists) ? raw.customLists : [],
    favoritesByCode: raw.favoritesByCode || {},
    historyByCode: raw.historyByCode || {},
    securityPolicy,
    securityEvents,
  };
}

let cachedDb: DatabaseSchema | null = null;
let saveTimer: NodeJS.Timeout | null = null;
let saveInFlight: Promise<void> = Promise.resolve();
let dbDirty = false;
let dbCatalogRevision = 1;

export function getCatalogRevision(): number {
  return dbCatalogRevision;
}

function writeDbSyncInternal(): void {
  if (!cachedDb) return;
  dbDirty = false;
  const serialized = JSON.stringify(cachedDb);

  if (!fs.existsSync(SERVER_DIR)) {
    fs.mkdirSync(SERVER_DIR, { recursive: true });
  }
  const tmpPrimary = `${PRIMARY_DB_PATH}.tmp`;
  fs.writeFileSync(tmpPrimary, serialized, 'utf-8');
  fs.renameSync(tmpPrimary, PRIMARY_DB_PATH);

  try {
    if (!fs.existsSync(LEGACY_DATA_DIR)) {
      fs.mkdirSync(LEGACY_DATA_DIR, { recursive: true });
    }
    const tmpLegacy = `${LEGACY_DB_PATH}.tmp`;
    fs.writeFileSync(tmpLegacy, serialized, 'utf-8');
    fs.renameSync(tmpLegacy, LEGACY_DB_PATH);
  } catch {
    // ignore secondary mirror errors
  }
}

async function writeDbAsyncInternal(): Promise<void> {
  if (!cachedDb || !dbDirty) return;
  dbDirty = false;
  const serialized = JSON.stringify(cachedDb);

  try {
    await fs.promises.mkdir(SERVER_DIR, { recursive: true });
    const tmpPrimary = `${PRIMARY_DB_PATH}.tmp.${process.pid}`;
    await fs.promises.writeFile(tmpPrimary, serialized, 'utf-8');
    await fs.promises.rename(tmpPrimary, PRIMARY_DB_PATH);
  } catch (err) {
    console.error('Failed to persist primary DB:', err);
  }

  try {
    await fs.promises.mkdir(LEGACY_DATA_DIR, { recursive: true });
    const tmpLegacy = `${LEGACY_DB_PATH}.tmp.${process.pid}`;
    await fs.promises.writeFile(tmpLegacy, serialized, 'utf-8');
    await fs.promises.rename(tmpLegacy, LEGACY_DB_PATH);
  } catch {
    // ignore secondary mirror errors
  }
}

for (const sig of ['SIGINT', 'SIGTERM'] as const) {
  process.once(sig, () => {
    if (dbDirty) {
      try {
        writeDbSyncInternal();
      } catch {
        // ignore
      }
    }
  });
}

export function getDb(): DatabaseSchema {
  if (cachedDb) return cachedDb;

  const candidatePaths = [PRIMARY_DB_PATH, LEGACY_DB_PATH];
  for (const filePath of candidatePaths) {
    if (fs.existsSync(filePath)) {
      try {
        const rawText = fs.readFileSync(filePath, 'utf-8');
        const parsed = JSON.parse(rawText) as Partial<DatabaseSchema>;
        if (parsed && Array.isArray(parsed.channels)) {
          cachedDb = normalizeLoadedDb(parsed);
          saveDb();
          return cachedDb;
        }
      } catch (err) {
        console.error(`Failed to parse store at ${filePath}:`, err);
      }
    }
  }

  cachedDb = createStarterState();
  writeDbSyncInternal();
  return cachedDb;
}

export function saveDb(): void {
  if (!cachedDb) return;
  dbDirty = true;
  dbCatalogRevision += 1;
  if (saveTimer) {
    clearTimeout(saveTimer);
  }
  saveTimer = setTimeout(() => {
    saveTimer = null;
    saveInFlight = saveInFlight.then(() => writeDbAsyncInternal()).catch(() => {});
  }, 350);
}

export function recordSecurityEvent(
  input: Omit<SecurityAuditEvent, 'id' | 'createdAt'>
): void {
  const db = getDb();
  const nowMs = Date.now();
  const recentDuplicate = db.securityEvents.find(
    (ev) =>
      ev.type === input.type &&
      ev.ip === input.ip &&
      (ev.subscriberCode || '') === (input.subscriberCode || '') &&
      nowMs - (Date.parse(ev.createdAt) || 0) < 15000
  );
  if (recentDuplicate) return;

  const entry: SecurityAuditEvent = {
    id: `sec_${crypto.randomBytes(5).toString('hex')}`,
    type: input.type,
    reason: String(input.reason || '').slice(0, 220),
    ip: String(input.ip || 'unknown').slice(0, 64),
    deviceName: String(input.deviceName || 'جهاز غير معروف').slice(0, 80),
    subscriberCode: input.subscriberCode ? String(input.subscriberCode).slice(0, 40) : undefined,
    userAgent: input.userAgent ? String(input.userAgent).slice(0, 140) : undefined,
    createdAt: new Date(nowMs).toISOString(),
  };

  db.securityEvents.unshift(entry);
  if (db.securityEvents.length > 80) {
    db.securityEvents.length = 80;
  }
  saveDb();
}

export function upsertSourceChannels(
  source: IptvSource,
  parsedChannels: ParsedChannelInput[]
): { addedCount: number } {
  const db = getDb();
  const now = new Date().toISOString();

  // Preserve view counts across playlist refreshes
  const prevViewsBySig = new Map<string, number>();
  for (const existing of db.channels) {
    if (existing.sourceId === source.id && existing.views > 0) {
      prevViewsBySig.set(existing.signature, existing.views);
    }
  }

  const excludedSet = new Set(db.excludedCategories || []);
  source.groupsInOrder = (source.groupsInOrder || []).filter((g) => !excludedSet.has(g));

  // Remove old channels from this source while keeping overrides
  db.channels = db.channels.filter((c) => c.sourceId !== source.id);

  const existingIds = new Set(db.channels.map((c) => c.id));
  const baseOrderOffset = db.channels.length;

  const newStored: StoredChannel[] = [];
  let autoFeaturedCount = 0;
  for (let i = 0; i < parsedChannels.length; i++) {
    const item = parsedChannels[i];
    const override = db.channelOverrides[item.signature];
    if (override?.hidden) continue;

    const effectiveGroup = override?.customGroup || item.group;
    if (excludedSet.has(effectiveGroup) || excludedSet.has(item.group)) continue;

    let id = `ch_${source.id.slice(-6)}_${item.signature}`;
    let suffix = 1;
    while (existingIds.has(id)) {
      id = `ch_${source.id.slice(-6)}_${item.signature}_${suffix++}`;
    }
    existingIds.add(id);

    const canAutoFeature = !isSeparatorBannerName(item.name) && autoFeaturedCount < 10;
    if (canAutoFeature && override?.featured === undefined) {
      autoFeaturedCount++;
    }

    newStored.push({
      id,
      sourceId: source.id,
      signature: item.signature,
      name: override?.customName || item.name,
      originalName: item.name,
      group: effectiveGroup,
      originalGroup: item.group,
      logo: override?.customLogo !== undefined ? override.customLogo : item.logo,
      streamUrl: item.streamUrl,
      fallbackStreamUrl: item.fallbackStreamUrl || deriveStreamFallbackUrl(item.streamUrl),
      streamFormat: item.streamFormat,
      contentType: item.contentType,
      userAgent: item.userAgent,
      referrer: item.referrer,
      year: item.year,
      featured: override?.featured ?? canAutoFeature,
      views: prevViewsBySig.get(item.signature) ?? 0,
      order: baseOrderOffset + i,
      addedAt: now,
    });
  }

  db.channels.push(...newStored);
  source.channelCount = newStored.length;
  source.lastSyncedAt = now;

  const existingSourceIdx = db.sources.findIndex((s) => s.id === source.id);
  if (existingSourceIdx >= 0) {
    db.sources[existingSourceIdx] = source;
  } else {
    db.sources.push(source);
  }

  // Append any new M3U groups in exact source order into categoryOrder
  const hadOnlyStarter = db.sources.every((s) => s.type === 'starter' || s.id === source.id);
  if (hadOnlyStarter && source.type !== 'starter') {
    // Clean out starter-only groups from categoryOrder when first real source is imported
    const realGroups = new Set<string>(source.groupsInOrder);
    for (const custom of db.customCategories) realGroups.add(custom);
    db.categoryOrder = db.categoryOrder.filter((g) => realGroups.has(g));
  }
  db.categoryOrder = db.categoryOrder.filter((g) => !excludedSet.has(g));
  for (const grp of source.groupsInOrder) {
    if (!excludedSet.has(grp) && !db.categoryOrder.includes(grp)) {
      db.categoryOrder.push(grp);
    }
  }

  db.isInitialSetup = false;
  saveDb();
  return { addedCount: newStored.length };
}

export function getActiveSourcesAndChannels(): {
  sources: IptvSource[];
  channels: StoredChannel[];
} {
  const db = getDb();
  const hasRealSource = db.sources.some((s) => s.type !== 'starter');
  const activeSources = hasRealSource
    ? db.sources.filter((s) => s.type !== 'starter')
    : db.sources;
  const activeSourceIds = new Set(activeSources.map((s) => s.id));
  const activeChannels = db.channels.filter((c) => activeSourceIds.has(c.sourceId));
  return { sources: activeSources, channels: activeChannels };
}

/**
 * Returns categories strictly ordered according to Admin's custom categoryOrder
 * (preserving Up/Down moves), with any newly discovered M3U/Xtream groups appended in exact source order.
 */
export function getOrderedCategories(): Array<{
  name: string;
  count: number;
  isFromSource: boolean;
  logo: string;
}> {
  const db = getDb();
  const { sources: activeSources, channels: activeChannels } = getActiveSourcesAndChannels();
  const counts = new Map<string, number>();

  for (const ch of activeChannels) {
    counts.set(ch.group, (counts.get(ch.group) || 0) + 1);
  }

  const validSet = new Set<string>();
  const sourceGroupSet = new Set<string>();
  const naturalOrder: string[] = [];

  for (const src of activeSources) {
    for (const grp of src.groupsInOrder) {
      sourceGroupSet.add(grp);
      if ((counts.get(grp) || 0) > 0 && !validSet.has(grp)) {
        validSet.add(grp);
        naturalOrder.push(grp);
      }
    }
  }

  for (const customCat of db.customCategories) {
    if (!validSet.has(customCat)) {
      validSet.add(customCat);
      naturalOrder.push(customCat);
    }
  }

  for (const ch of activeChannels) {
    if (!validSet.has(ch.group)) {
      validSet.add(ch.group);
      naturalOrder.push(ch.group);
    }
  }

  const orderedNames: string[] = [];
  const seen = new Set<string>();

  // 1. Honor Admin's saved categoryOrder first
  for (const savedName of db.categoryOrder) {
    if (validSet.has(savedName) && !seen.has(savedName)) {
      seen.add(savedName);
      orderedNames.push(savedName);
    }
  }

  // 2. Append any remaining categories in their exact M3U/Xtream order
  for (const natName of naturalOrder) {
    if (!seen.has(natName)) {
      seen.add(natName);
      orderedNames.push(natName);
    }
  }

  return orderedNames.map((name) => ({
    name,
    count: counts.get(name) || 0,
    isFromSource: sourceGroupSet.has(name),
    logo: (db.categoryLogos && db.categoryLogos[name]) || '',
  }));
}

export function setCategoryOrder(orderedNames: string[]): void {
  const db = getDb();
  const current = getOrderedCategories().map((c) => c.name);
  const nextOrder: string[] = [];
  const seen = new Set<string>();

  for (const name of orderedNames) {
    const trimmed = name.trim();
    if (trimmed && !seen.has(trimmed)) {
      seen.add(trimmed);
      nextOrder.push(trimmed);
    }
  }
  for (const existing of current) {
    if (!seen.has(existing)) {
      seen.add(existing);
      nextOrder.push(existing);
    }
  }

  db.categoryOrder = nextOrder;
  saveDb();
}

export function moveCategoryInOrder(
  categoryName: string,
  direction: 'up' | 'down' | 'top' | 'bottom'
): void {
  const current = getOrderedCategories().map((c) => c.name);
  const idx = current.indexOf(categoryName);
  if (idx === -1) return;

  const updated = [...current];
  if (direction === 'up' && idx > 0) {
    [updated[idx - 1], updated[idx]] = [updated[idx], updated[idx - 1]];
  } else if (direction === 'down' && idx < updated.length - 1) {
    [updated[idx + 1], updated[idx]] = [updated[idx], updated[idx + 1]];
  } else if (direction === 'top' && idx > 0) {
    const [item] = updated.splice(idx, 1);
    updated.unshift(item);
  } else if (direction === 'bottom' && idx < updated.length - 1) {
    const [item] = updated.splice(idx, 1);
    updated.push(item);
  }

  setCategoryOrder(updated);
}

/**
 * Deletes one or multiple channel categories and all channels belonging to them in O(N) time.
 * Optionally adds the category names to excludedCategories so future M3U/Xtream refreshes skip them.
 */
export function deleteCategoriesFromStore(
  categoryNames: string[],
  blockFutureSync = true
): {
  deletedCategoriesCount: number;
  deletedChannelsCount: number;
  removedChannelIds: Set<string>;
} {
  const db = getDb();
  const targetSet = new Set(
    categoryNames.map((n) => String(n || '').trim()).filter((n) => n.length > 0)
  );
  if (targetSet.size === 0) {
    return {
      deletedCategoriesCount: 0,
      deletedChannelsCount: 0,
      removedChannelIds: new Set<string>(),
    };
  }

  const removedChannelIds = new Set<string>();
  const keptChannels: StoredChannel[] = [];
  const remainingCountsBySource = new Map<string, number>();

  for (const ch of db.channels) {
    if (targetSet.has(ch.group)) {
      removedChannelIds.add(ch.id);
      const prevOverride = db.channelOverrides[ch.signature];
      if (!blockFutureSync || (prevOverride?.customGroup && targetSet.has(prevOverride.customGroup))) {
        const nextOv: ChannelOverride = { ...(prevOverride || {}), hidden: true };
        if (nextOv.customGroup && targetSet.has(nextOv.customGroup)) {
          delete nextOv.customGroup;
        }
        db.channelOverrides[ch.signature] = nextOv;
      }
    } else {
      keptChannels.push(ch);
      remainingCountsBySource.set(ch.sourceId, (remainingCountsBySource.get(ch.sourceId) || 0) + 1);
    }
  }

  db.channels = keptChannels;

  for (const sig of Object.keys(db.channelOverrides)) {
    const ov = db.channelOverrides[sig];
    if (ov?.customGroup && targetSet.has(ov.customGroup)) {
      delete ov.customGroup;
      ov.hidden = true;
    }
  }

  if (blockFutureSync) {
    const mergedExcluded = new Set(db.excludedCategories || []);
    for (const catName of targetSet) {
      mergedExcluded.add(catName);
    }
    db.excludedCategories = Array.from(mergedExcluded);
  }

  db.customCategories = db.customCategories.filter((c) => !targetSet.has(c));
  db.categoryOrder = db.categoryOrder.filter((c) => !targetSet.has(c));
  if (db.categoryLogos) {
    for (const catName of targetSet) {
      delete db.categoryLogos[catName];
    }
  }

  for (const src of db.sources) {
    src.groupsInOrder = (src.groupsInOrder || []).filter((g) => !targetSet.has(g));
    src.channelCount = remainingCountsBySource.get(src.id) || 0;
  }

  if (removedChannelIds.size > 0) {
    for (const lst of db.customLists) {
      lst.channelIds = lst.channelIds.filter((id) => !removedChannelIds.has(id));
    }
    for (const code of Object.keys(db.favoritesByCode)) {
      db.favoritesByCode[code] = (db.favoritesByCode[code] || []).filter(
        (id) => !removedChannelIds.has(id)
      );
    }
    for (const code of Object.keys(db.historyByCode)) {
      db.historyByCode[code] = (db.historyByCode[code] || []).filter(
        (id) => !removedChannelIds.has(id)
      );
    }
  }

  saveDb();
  return {
    deletedCategoriesCount: targetSet.size,
    deletedChannelsCount: removedChannelIds.size,
    removedChannelIds,
  };
}

export function restoreExcludedCategoriesInStore(categoryNames: string[]): string[] {
  const db = getDb();
  if (categoryNames.includes('__ALL__')) {
    db.excludedCategories = [];
  } else {
    const restoreSet = new Set(
      categoryNames.map((n) => String(n || '').trim()).filter((n) => n.length > 0)
    );
    db.excludedCategories = (db.excludedCategories || []).filter((c) => !restoreSet.has(c));
  }
  saveDb();
  return db.excludedCategories;
}

/**
 * Exports the entire server database as gzipped + AES-256-GCM encrypted base64url slices
 * (<= 650KB per slice) for safe, zero-knowledge Cloud Firestore persistence.
 */
export function exportEncryptedSnapshotChunks(): {
  totalChannels: number;
  totalSources: number;
  chunks: string[];
} {
  const db = getDb();
  const key = getDeterministicVaultKey();
  const iv = crypto.randomBytes(12);
  const compressed = zlib.gzipSync(Buffer.from(JSON.stringify(db), 'utf-8'));

  const cipher = crypto.createCipheriv('aes-256-gcm', key, iv);
  const encrypted = Buffer.concat([cipher.update(compressed), cipher.final()]);
  const authTag = cipher.getAuthTag();
  const fullPayload = Buffer.concat([iv, authTag, encrypted]).toString('base64url');

  const SLICE_SIZE = 650000;
  const chunks: string[] = [];
  for (let offset = 0; offset < fullPayload.length; offset += SLICE_SIZE) {
    chunks.push(fullPayload.slice(offset, offset + SLICE_SIZE));
  }

  const realSources = db.sources.filter((s) => s.type !== 'starter');
  const activeCount = getActiveSourcesAndChannels().channels.length;

  return {
    totalChannels: activeCount,
    totalSources: realSources.length,
    chunks,
  };
}

export function importEncryptedSnapshotChunks(chunks: string[]): {
  restoredChannels: number;
  restoredSources: number;
} {
  if (!Array.isArray(chunks) || chunks.length === 0) {
    throw new Error('لا توجد بيانات مشفرة لاستعادتها.');
  }

  const joined = chunks.join('');
  const raw = Buffer.from(joined, 'base64url');
  if (raw.length < 28) {
    throw new Error('بيانات النسخة السحابية غير صالحة.');
  }

  const iv = raw.subarray(0, 12);
  const authTag = raw.subarray(12, 28);
  const encrypted = raw.subarray(28);

  const key = getDeterministicVaultKey();
  const decipher = crypto.createDecipheriv('aes-256-gcm', key, iv);
  decipher.setAuthTag(authTag);

  const compressed = Buffer.concat([decipher.update(encrypted), decipher.final()]);
  const jsonText = zlib.gunzipSync(compressed).toString('utf-8');
  const parsed = JSON.parse(jsonText) as Partial<DatabaseSchema>;

  cachedDb = normalizeLoadedDb(parsed);
  saveDb();

  const { sources, channels } = getActiveSourcesAndChannels();
  return {
    restoredChannels: channels.length,
    restoredSources: sources.filter((s) => s.type !== 'starter').length,
  };
}
